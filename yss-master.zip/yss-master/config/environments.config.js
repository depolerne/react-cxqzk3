// Here is where you can define configuration overrides based on the execution environment.
// Supply a key to the default export matching the NODE_ENV that you wish to target, and
// the base configuration will apply your overrides before exporting itself.
module.exports = {
    // ======================================================
    // Overrides when NODE_ENV === 'development'
    // ======================================================
    development : (config) => ({
        compiler_public_path : `http://${config.server_host_name}:${config.server_port}/`,
        api: 'https://api.soberlistic.com/api', //process.env.API_ENDPOINT,
        googleMapKey: 'AIzaSyCzf8RXQS27SPKYkdq6UMdZV0JctvWNFv0',
        socket_ip:'wss://socket.soberlistic.com',
        image_url:'https://api.soberlistic.com/',
        stripe_client_key:'pk_test_51IVk6mInEL6a47Xw9zdyTxoqhhnMiALVFViJ51rNqyTRCMrvqfXxM7UWJr3DovyacG6W4X4BBMweVPAViNjf0U2z00TMb5IesI',
        stripe_connect_account_key:'ca_JAU2klwuO8yTphEJmczEWLqh8E9imhe1',
        agora_api_key:'001f5384155247f78270016c038de118',
    }),

    // ======================================================
    // Overrides when NODE_ENV === 'staging'
    // ======================================================
    staging: (config) => ({
        compiler_public_path     : '/',
        compiler_fail_on_warning : false,
        compiler_hash_type       : 'hash',
        compiler_devtool         : false,
        compiler_stats           : {
            chunks       : true,
            chunkModules : true,
            colors       : true
        },
        api: '',
        googleMapKey: 'AIzaSyCzf8RXQS27SPKYkdq6UMdZV0JctvWNFv0',
        server_host_name: '',
        server_port: 80
    }),
    // ======================================================
    // Overrides when NODE_ENV === 'production'
    // ======================================================
    production : (config) => ({
        compiler_public_path     : '/',
        compiler_fail_on_warning : false,
        compiler_hash_type       : 'hash',
        compiler_devtool         : false,
        compiler_stats           : {
            chunks       : true,
            chunkModules : true,
            colors       : true
        },
        api: 'https://api.soberlistic.com/api', //process.env.API_ENDPOINT,
        googleMapKey: 'AIzaSyCzf8RXQS27SPKYkdq6UMdZV0JctvWNFv0',
        socket_ip:'wss://socket.soberlistic.com',
        image_url:'https://api.soberlistic.com/',
        stripe_client_key:'pk_test_51IVk6mInEL6a47Xw9zdyTxoqhhnMiALVFViJ51rNqyTRCMrvqfXxM7UWJr3DovyacG6W4X4BBMweVPAViNjf0U2z00TMb5IesI',
        stripe_connect_account_key:'ca_JAU2klwuO8yTphEJmczEWLqh8E9imhe1',
        agora_api_key:'001f5384155247f78270016c038de118',
        server_host_name: '',
        server_port: 80
    })
};
