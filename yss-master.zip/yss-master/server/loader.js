require('babel-register');
require('./../bin/dev-server');
