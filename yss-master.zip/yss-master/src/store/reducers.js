import selectWrapperReducer from "./../routes/selectWrapper/modules/select";
import contactUsReducer from "./../routes/contactUs/modules/contactUs";
import authReducer from "../routes/login/modules/auth";
import error404Reducer from "../routes/Error404/modules/error";
import forgotReducer from "../routes/forgot/modules/forgot";
import SignupReducer from "../routes/Signup/modules/Signup";
import NotificationReducer from "../routes/Notification/modules/Notification";
import { combineReducers } from "redux";
import { routerReducer } from "react-router-redux";
import UserAppointmentReducter from "../routes/UserAppointment/modules/UserAppointment";
import ProfileReducer from "../routes/Profile/modules/Profile";
import CProfileReducer from "../routes/CProfile/modules/CProfile";
import CDashboardReducer from "../routes/CDashboard/modules/CDashboard";
import PackageReducer from "../routes/Packages/modules/Packages";
import AvailabilityReducer from "../routes/Availablity/modules/Availability";
// import CListingReducer from "../routes/CListing/modules/CListing";
import CheckoutReducer from "../routes/Checkout/modules/Checkout";
import CreatePackageReducer from "../routes/CreatePackage/modules/CreatePackage";
import EditPackageReducer from "../routes/EditPackage/modules/EditPackage";
import homeReducer from "../routes/dashboard/modules/dashboard";
import CAppointmentReducer from "../routes/CAppointments/modules/CAppointment";
import VideoReducer from "../routes/VideoSession/modules/VideoSession";
import ProfileReducer1 from "../routes/Profile1/modules/Profile1";
import AddListingReducer from "../routes/AddListings/modules/AddListings";
import siteReducer from "../routes/SiteWrapper/modules/site";
import searchNowReducer from "../routes/SearchNow/modules/SearchNow";
import HomeReducer from "../routes/Home/modules/Home";
import ListingReducer from "../routes/Listing/modules/Listing";
import InsuranceReducer from "../routes/Insurance/modules/Insurance";
import ContactUsReducer from "../routes/Contact/modules/ContactUs";

export const makeRootReducer = (asyncReducers) => {
  return combineReducers({
    router: routerReducer,
    selectState: selectWrapperReducer,
    dashboardState: homeReducer,
    contactUsState: contactUsReducer,
    auth: authReducer,
    page404: error404Reducer,
    forgotState: forgotReducer,
    Signup: SignupReducer,
    NotificationState: NotificationReducer,
    UserAppointmentState: UserAppointmentReducter,
    ProfileState: ProfileReducer,
    CDashboardState: CDashboardReducer,
    PackageState: PackageReducer,
    AvailabilityState: AvailabilityReducer,
    InsuranceState: InsuranceReducer,
    CheckoutState: CheckoutReducer,
    CreatePackageState: CreatePackageReducer,
    EditPackageState: EditPackageReducer,
    CProfileState: CProfileReducer,
    CAppointmentState: CAppointmentReducer,
    AgoraState: VideoReducer,
    Profile1: ProfileReducer1,
    AddListingState: AddListingReducer,
    siteState: siteReducer,
    searchNowState: searchNowReducer,
    homeState: HomeReducer,
    ListingState: ListingReducer,
    ContactUsState:ContactUsReducer,
    ...asyncReducers,
  });
};

export default makeRootReducer;
