import ForgotLayout from './ForgotLayout';

export default ForgotLayout;
