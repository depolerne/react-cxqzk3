import React from 'react';
import PropTypes from 'prop-types';
import { renderRoutes } from 'react-router-config';
import auth from '../../helpers/auth';
import { Redirect } from 'react-router';

export const ForgotLayout = ({ children, route }) => (
    <div className='wrapper-login'>
          <React.Fragment>
                {children}
                {renderRoutes(route.routes)}
          </React.Fragment>
            

    </div>
);

ForgotLayout.propTypes = {
    //children: PropTypes.element,
    //route: PropTypes.object.isRequired
};

export default ForgotLayout;
