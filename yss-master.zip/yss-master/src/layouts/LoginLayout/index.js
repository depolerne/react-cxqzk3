import LoginLayout from './LoginLayout';

export default LoginLayout;
