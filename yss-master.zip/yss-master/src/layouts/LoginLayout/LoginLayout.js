import React, { Fragment } from 'react';
import PropTypes from 'prop-types';
import { renderRoutes } from 'react-router-config';
import auth from '../../helpers/auth';
import { Redirect } from 'react-router';

export const LoginLayout = ({ children, route }) => (
    <div className='login_form--page'>
        {!auth.isAuthenticated
            ? <div className="md:w-4/5 lg:w-8/12 md:flex md:select-none justify-center bg_blue items-end">
                {children}
                {renderRoutes(route.routes)}
                </div>
            : <Redirect to='/dashboard' />}
    </div>
);

LoginLayout.propTypes = {
    children: PropTypes.element,
    route: PropTypes.object.isRequired
};

export default LoginLayout;