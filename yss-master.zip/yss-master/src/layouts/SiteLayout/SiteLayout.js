import React,{Fragment} from "react";
import { renderRoutes } from "react-router-config";
import auth from "../../helpers/auth";
import { Redirect } from "react-router";

function SiteLayout({ children, route }) {
  
  return (
    <Fragment>
      <div className="wrapper">
        {/* {auth.isAuthenticated ? ( */}
          <div className="core-layout__viewport">
            {children}
            {renderRoutes(route.routes)}
          </div>
        {/* ) : (
          <Redirect to="/register" />
        )} */}
      </div>
    </Fragment>
  );
}

export default SiteLayout;