import LandingLayout from './LandingLayout';

export default LandingLayout;
