import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { renderRoutes } from "react-router-config";
import auth from "../../helpers/auth";
import { Redirect } from "react-router";
import Header from "../../components/Header/Header";
import NotificationBar from "../../components/NotificationBar/NotificationBar";

export const LandingLayout = ({ children, route }) => (
  <Fragment>
    <div className="wrapper">
      {auth.isAuthenticated ? 
      <Redirect to='/packages/:id' />
      : 
        <div className="core-layout__viewport">
          <div className="landing-elements">
            <Header />
            <NotificationBar />
          </div>
          {children}
          {renderRoutes(route.routes)}
        </div>
      }
    </div>
  </Fragment>
);

LandingLayout.propTypes = {
  children: PropTypes.element,
  route: PropTypes.object.isRequired,
};

export default LandingLayout;
