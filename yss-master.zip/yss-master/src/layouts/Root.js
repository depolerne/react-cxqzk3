import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { renderRoutes } from "react-router-config";
import { connect } from "react-redux";
import { actions } from "../routes/selectWrapper/modules/select";
import { socket } from "../helpers/socketHelper";
import "../assets/main-web.css"
import "../assets/main.css"

export class Root extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Fragment>
        {this.props.children}
        {renderRoutes(this.props.route.routes)}
      </Fragment>
    );
  }
}

// Root.propTypes = {
//     children: PropTypes.element,
//     route: PropTypes.object.isRequired
// };

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CProfileState: state.CProfileState,
});

export default connect(mapStateToProps, actions)(Root);
