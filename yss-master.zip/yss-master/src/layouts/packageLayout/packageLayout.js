import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { renderRoutes } from "react-router-config";
import auth from "../../helpers/auth";
import { Redirect } from "react-router";
import { actions } from "../../routes/selectWrapper/modules/select";
import { connect } from "react-redux";

export const packageLayout = ({ children, route,CListingState }) => (
  <Fragment>
    <div className="wrapper">
      {!auth.isAuthenticated ? (
        <div className="core-layout__viewport">
          {children}
          {renderRoutes(route.routes)}
        </div>
      ) : auth.getUserType() === "consumer" ? (
        <div className="core-layout__viewport">
          {children}
          {renderRoutes(route.routes)}
        </div>
      ) : (
        <Redirect to={`/`} />
      )}
    </div>
  </Fragment>
);

packageLayout.propTypes = {
  children: PropTypes.element,
  route: PropTypes.object.isRequired,
};

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ProfileState: state.ProfileState,
  CListingState: state.CListingState
});

export default connect(mapStateToProps, actions)(packageLayout);
