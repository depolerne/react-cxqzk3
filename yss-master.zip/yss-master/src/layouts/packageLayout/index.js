import packageLayout from './packageLayout';

export default packageLayout;
