import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { renderRoutes } from "react-router-config";
import auth from "../../helpers/auth";
import { Redirect } from "react-router";

export const CounsellorLayout = ({ children, route }) => (
  <Fragment>
    <div className="wrapper">
      {auth.isAuthenticated ? (
        auth.getUserType() === "counsellor" ? (
          <div className="core-layout__viewport">
            {children}
            {renderRoutes(route.routes)}
          </div>
        ) : (
          <Redirect to="/coach/dashboard" />
        )
      ) : (
        <Redirect to="/coach/login" />
      )}
    </div>
  </Fragment>
);

CounsellorLayout.propTypes = {
  children: PropTypes.element,
  route: PropTypes.object.isRequired,
};

export default CounsellorLayout;
