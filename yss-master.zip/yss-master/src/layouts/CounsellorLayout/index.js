import CounsellorLayout from './CounsellerLayout';

export default CounsellorLayout;
