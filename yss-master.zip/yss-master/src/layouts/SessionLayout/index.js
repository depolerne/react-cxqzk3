import SessionLayout from './SessionLayout';

export default SessionLayout;
