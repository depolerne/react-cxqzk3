import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { renderRoutes } from "react-router-config";
import { Redirect } from "react-router";

export const SessionLayout = ({ children, route }) => (
  <Fragment>
    <div className="wrapper">
      <div className="core-layout__viewport">
        {children}
        {renderRoutes(route.routes)}
      </div>
    </div>
  </Fragment>
);

SessionLayout.propTypes = {
  children: PropTypes.element,
  route: PropTypes.object.isRequired,
};

export default SessionLayout;
