import { NameValidator } from "./NameValidator";

export function FormValidator(data) {
  let err = {};
  let errClass = {};
  let email = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
  let specials = /[!@#$%`^&*()_+\-=\[\]{};':"\\|,~<>\/?]+/;
  let urlRegex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;

  if (!email.test(data.email)) {
    err = {
      message: "Please enter the valid Email Address",
      color: "teal",
    };
    errClass = "email";
  } else if (data.email === "") {
    err = {
      message: "Please enter the Email Address",
      color: "teal",
    };
    errClass = "email";
  } else if (specials.test(data.name)) {
    err = {
      message: "Username should not contain special characters",
      color: "teal",
    };
    errClass = "username";
  } else if (NameValidator(data.name.replace(/ /g, ""))) {
    err = {
      message: "Username must starts with 2 alphabets.",
      color: "teal",
    };
    errClass = "username";
  } else if (data.name.length > 32 || data.name.length < 3) {
    err = {
      message: "Username must contain chracters between 3 and 32",
      color: "teal",
    };
    errClass = "username";
  } else if (data.password === "") {
    err = {
      message: "Please enter the password",
      color: "teal",
    };
    errClass = "password";
  } else if (data.password.length < 8) {
    err = {
      message:
        "Password must contain 8 characters including special character, numbers and Alphabets.",
      coor: "teal",
    };
    errClass = "password";
  } else if (data.password.search(/[a-z]/i) < 0) {
    err = {
      message: "Password must contain at least one Alphabet.",
      color: "teal",
    };
    errClass = "password";
  } else if (data.password.search(/[0-9]/) < 0) {
    err = {
      message: "Password must contain at least one digit.",
      color: "teal",
    };
    errClass = "password";
  } else if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(data.password)) {
    err = {
      message: "Password must contain at least one special character.",
      color: "teal",
    };
    errClass = "password";
  } else if (data.password !== data.c_password) {
    err = {
      message: "Password and Confirm Password should be same",
      color: "teal",
    };
    errClass = "password";
  } else if (data.listing_name === "") {
    err = {
      message: "Please enter the Listing name.",
      color: "teal",
    };
    errClass = "listing_name";
  } else if (/[!#$%`^&*()_+\=\[\]{};:"\\|~<>\/?]+/.test(data.listing_name)) {
    err = {
      message: "Listing name should not contain special characters",
      color: "teal",
    };
    errClass = "listing_name";
  } else if (data.location === "") {
    err = {
      message: "Please enter the Location",
      color: "teal",
    };
    errClass = "location";
  } else if (
    data.contact_email_or_url &&
    !email.test(data.contact_email_or_url)
  ) {
    err = {
      message: "Please enter the valid Contact-Email",
      color: "teal",
    };
    errClass = "contact_email_or_url";
  } else if (data.description.replace(/<[^>]+>/g, "").length < 250) {
    err = {
      message: "Description must contain atleast 250 characters.",
      color: "teal",
    };
    errClass = "description";
  } else if (
    data.listing_category === "select" ||
    data.listing_category === ""
  ) {
    err = {
      message: "Please select the Category",
      color: "teal",
    };
    errClass = "listing_category";
  } else if (data.listing_region === "" || data.listing_region === "select") {
    err = {
      message: "Please select the region.",
      color: "teal",
    };
    errClass = "listing_region";
  } else if (data.timezone === "" || data.timezone === "select") {
    err = {
      message: "Please select the timezone",
      color: "teal",
    };
    errClass = "timezone";
  } else if (data.cover_img === "") {
    err = {
      message: "Please upload the cover image.",
      color: "teal",
    };
    errClass = "cover_img";
  } else if (data.gallery_images.length === 0) {
    err = {
      message: "Please upload atleast 1 gallery image",
      color: "teal",
    };
    errClass = "gallery_images";
  } else if (data.website && !data.website.match(urlRegex)) {
    err = {
      message: "Please enter the website url.",
      color: "teal",
    };
    errClass = "website";
  } else if (data.phone && data.phone.length < 10) {
    err = {
      message: "Phone no. must contain 10 digits.",
      color: "teal",
    };

    errClass = "phone";
  } else if (data.phone && data.phone.length > 10) {
    err = {
      message: "Phone no. must contain 10 digits.",
      color: "teal",
    };
    errClass = "phone";
  } else if (data.video_url && !data.video_url.match(urlRegex)) {
    err = {
      message: "Please enter the valid video URL",
      color: "teal",
    };
    errClass = "video_url";
  } else {
    err = null;
  }
  return { err,errClass };
}
