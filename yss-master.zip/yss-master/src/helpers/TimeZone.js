import moment from "moment-timezone";

export const TimeZone = (time, timeZone) => {
    return moment(time).tz(timeZone).format('hh:mm A');
};

