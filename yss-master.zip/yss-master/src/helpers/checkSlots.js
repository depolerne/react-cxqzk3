import { TimeZone } from "./TimeZone";
import moment from "moment-timezone";
import { ZoneList } from "./ZoneList";

export const checkSlots = (date, slot) => {
  var bookingTime = new Date();
  // let bookingDate = date.split("-");
  var bookingTime = new Date(
    date.year + " " + date.month + " " + date.day + "," + slot
    );
  let currentTime = new Date();
  if (bookingTime.getTime() > currentTime.getTime()) {
    return true;
  }else{
    return false
  }
};

export const showSlots = (date, slots) => {
  let flag;
  let currentTime = new Date();
  Object.keys(slots).map((i) => {
    slots[i].map((j) => {
      var bookingTime = new Date(
        date.split("-")[0] +
          " " +
          date.split("-")[1] +
          " " +
          date.split("-")[2] +
          "," +
          j
      );
      if (bookingTime.getHours() < currentTime.getHours()) {
        flag = true;
      }else{
        flag = false;
      }
    });
  });
  return flag;
};

export const ConvertTime = (date, slot, u_zone, c_zone) => {
  let Offset = ZoneList.find((i) => i.value === c_zone).label.slice(4, 10);
  let bookingDate = date.split("-");
  var bookingTime = new Date(
    bookingDate[0] +
      " " +
      bookingDate[1] +
      " " +
      bookingDate[2] +
      "," +
      slot +
      "," +
      "GMT" +
      Offset
  ).toISOString();
  let newTime = moment(bookingTime).tz(u_zone).format("hh:mm A");
  return newTime;
};

export const setTimeLable = (h, m) => {
  var minutes = +h * 60 + +m;
  if (minutes < 60) {
    return true;
  }
};
