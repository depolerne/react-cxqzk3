export const sortBy=[
    {value:'newest',label:'Newest first'},
    {value:'oldest',label:'Oldest first'},
    {value:'highest',label:'Highest Rating'},
    {value:'lowest',label:'Lowest Rating'},
]