export const NameValidator=(name)=>{
    var test = name.slice(0,2).replace(/[^a-z]/gi, '');
    if(test.length < 2){
      return true;
    }
    return false;
}