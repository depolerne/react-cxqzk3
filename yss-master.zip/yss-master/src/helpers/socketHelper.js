import openSocket from "socket.io-client";

export const socket = openSocket(__SOCKET__IP,{transports: ['polling']});
