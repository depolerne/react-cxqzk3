import auth from "../../../helpers/auth";
import _without from "lodash/without";
import _remove from "lodash/remove";
import _get from "lodash/get";
import fetch from "isomorphic-fetch";

import {
  setAlertMessage,
  setMenuHover,
  setChannelId,
  saveSessionData,
  saveCallHistory,
  setRequestSender,
  setCallDuration,
} from "../../selectWrapper/modules/select";

import {
  setCallStatus,
  setCurrentSession,
} from "../../VideoSession/modules/VideoSession";

//---> Defining types for different actions
export const SET_APPOINTMENTS_ERR_MESSAGE = "SET_APPOINTMENTS_ERR_MESSAGE";
export const SET_APPOINTMENTS_PAST_DATA = "SET_APPOINTMENTS_PAST_DATA";
export const SET_APPOINTMENTS_UPCOMING_DATA = "SET_APPOINTMENTS_UPCOMING_DATA";
export const SET_LOADING_SPINNER_STATUS = "SET_LOADING_SPINNER_STATUS";
export const SET_APPOINTMENTS_TODAY_DATA = "SET_APPOINTMENTS_TODAY_DATA";
export const SET_APPOINTMENTS_BY_WEEK = "SET_APPOINTMENTS_BY_WEEK";
export const SET_SAVE_SESSION_DATA = "SET_SAVE_SESSION_DATA";
export const SET_START_SESSION_SPINNER_STATUS =
  "SET_START_SESSION_SPINNER_STATUS";

export const SET_LEFT_PACKAGE_SESSIONS = "SET_LEFT_PACKAGE_SESSIONS";
export const SET_WAITING_SPINNER_STATUS = "SET_WAITING_SPINNER_STATUS";
export const SET_USER_ONGOING_APPOINTMENTS = "SET_USER_ONGOING_APPOINTMENTS";
export const SET_BOOK_PLANNED_SESSION_MODAL = "SET_BOOK_PLANNED_SESSION_MODAL";
export const SET_PLANNED_SESSIONS_DATA = "SET_PLANNED_SESSIONS_DATA";
export const SET_LEFT_PACKAGE = "SET_LEFT_PACKAGE";
export const SET_LEFT_SELECTED_SLOTS = "SET_LEFT_SELECTED_SLOTS";
export const SET_LEFT_SELECTED_DATE = "SET_LEFT_SELECTED_DATE";
export const SET_LEFT_SLOTS_DATA = "SET_LEFT_SLOTS_DATA";
export const SET_LEFT_SLOTS_SPINNER_STATUS = "SET_LEFT_SLOTS_SPINNER_STATUS";
export const SET_LEFT_CHECKOUT_SPINNER_STATUS =
  "SET_LEFT_CHECKOUT_SPINNER_STATUS";
export const SET_LEFT_PACKAGE_PAYMENT_ID = "SET_LEFT_PACKAGE_PAYMENT_ID";

//---> Defining Actions to set state variables

export const setPastAppointments = (pastData) => {
  return {
    type: SET_APPOINTMENTS_PAST_DATA,
    payload: pastData,
  };
};

export const setUpcomingAppointments = (UpcomingData) => {
  return {
    type: SET_APPOINTMENTS_UPCOMING_DATA,
    payload: UpcomingData,
  };
};

export const setTodayAppointments = (todayData) => {
  return {
    type: SET_APPOINTMENTS_TODAY_DATA,
    payload: todayData,
  };
};

export function setAppointmentErrMessage(message) {
  return {
    type: SET_APPOINTMENTS_ERR_MESSAGE,
    payload: message,
  };
}

export const setLoadingSpinnerStatus = (status) => {
  return {
    type: SET_LOADING_SPINNER_STATUS,
    payload: status,
  };
};

export const setAppointmentsByWeek = (weekData) => {
  return {
    type: SET_APPOINTMENTS_BY_WEEK,
    payload: weekData,
  };
};

export const setStartSessionSpinner = (status) => {
  return {
    type: SET_START_SESSION_SPINNER_STATUS,
    payload: status,
  };
};

export const setWaitingSpinner = (flag) => {
  return {
    type: SET_WAITING_SPINNER_STATUS,
    payload: flag,
  };
};

export const setOngoingAppointments = (data) => {
  return {
    type: SET_USER_ONGOING_APPOINTMENTS,
    payload: data,
  };
};

export const setLeftPackage = (data) => {
  console.log(data);
  return {
    type: SET_LEFT_PACKAGE,
    payload: data,
  };
};

export const setPlannedSesionModal = (flag) => {
  return {
    type: SET_BOOK_PLANNED_SESSION_MODAL,
    payload: flag,
  };
};

export const setPlannedSessions = (data) => {
  return {
    type: SET_PLANNED_SESSIONS_DATA,
    payload: data,
  };
};

export const setLeftSelectedSlots = (data) => {
  return {
    type: SET_LEFT_SELECTED_SLOTS,
    payload: data,
  };
};

export const setLeftSelectedDate = (date) => {
  return {
    type: SET_LEFT_SELECTED_DATE,
    payload: date,
  };
};

export const setLeftSlots = (slots) => {
  return {
    type: SET_LEFT_SLOTS_DATA,
    payload: slots,
  };
};

export const setLeftSlotsSpinner = (flag) => {
  return {
    type: SET_LEFT_SLOTS_SPINNER_STATUS,
    payload: flag,
  };
};

export const setCheckoutSpinner = (flag) => {
  return {
    type: SET_LEFT_CHECKOUT_SPINNER_STATUS,
    payload: flag,
  };
};

export const setleftPaymentId = (id) => {
  return {
    type: SET_LEFT_PACKAGE_PAYMENT_ID,
    payload: id,
  };
};

export const setLeftSession = (no) => {
  return {
    type: SET_LEFT_PACKAGE_SESSIONS,
    payload: no,
  };
};

//---> Cancel Appointment API

export function CancelAppointment(deleteItemId) {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    if (token && deleteItemName) {
      try {
        await fetch(`${__API__}/api/v1.0/Appointment/${deleteItemId}`, {
          method: "DELETE",
          mode: "cors",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            "access-token": token,
          },
        });
        await dispatch(setAppointmentErrMessage(deleteItemId));
      } catch (e) {
        console.log(e);
      }
    }
  };
}

export const fetchPastBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setLoadingSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/past/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();

        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setLoadingSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setPastAppointments(response.past));
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchUpcomingBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setLoadingSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/upcoming/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setLoadingSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setUpcomingAppointments(response.upcoming));
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchTodayBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setLoadingSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/todays/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setLoadingSpinnerStatus(false));
        } else if (response.success) {
          if (current_page > -1) {
            await dispatch(setTodayAppointments(response.todays));
          }
          if (current_page == -1) {
            await dispatch(setOngoingAppointments(response.todays));
          }
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error!",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchWeekBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setLoadingSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/current/week/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setLoadingSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setAppointmentsByWeek(response.current_week));
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchPlannedSessions = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setLoadingSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/left/session?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();

        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setLoadingSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setPlannedSessions(response.leftsession));
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error.Please try after some time",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export function BreakPackage(data) {
  console.log(data);
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setLeftSlotsSpinner(true));

    let { id } = data.leftPackage.user;
    let { userData } = getState().selectState;

    const token = auth.getAccessToken();
    var dateString;
    if (data.date === "" || data.date === undefined) {
      var dateString = new Date().toISOString().slice(0, 10);
    } else {
      dateString = new Date(
        data.date.year + " " + data.date.month + " " + data.date.day
      );
      let month = "" + (dateString.getMonth() + 1);
      let day = "" + dateString.getDate();
      let year = dateString.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;
      dateString = [year, month, day].join("-");
    }
    // await dispatch(setDateAvail(dateString));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/break-packages?user_id=${userData.id}&package_id=${data.leftPackage.id}&date=${dateString}&counsellor_id=${id}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/vnd.api+json; et=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          await dispatch(setLeftSlotsSpinner(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setLeftSlots(response.data));
          // ------------------------------------
          if (response.data.length === 0) {
            // await dispatch(
            //   setNoPackageMessage({
            //     message: "No slots are available",
            //     color: "teal",
            //   })
            // );
          }
          await dispatch(setLeftSlotsSpinner(false));
        }
      } catch (e) {
        console.log(e);
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLeftSlotsSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function BookLeftPackage(data) {
  console.log(data);
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setCheckoutSpinner(true));

    const token = auth.getAccessToken();

    let bodydata = {
      package_id: data.leftPackage.id,
      no_of_slots: data.selected,
      selected_slots: data.leftSelectedSlots,
      payment_id: data.left_payment_id,
    };

    if (token) {
      try {
        let result = await fetch(`${__API__}/book/left/session`, {
          method: "POST",
          headers: {
            "Content-Type": "application/vnd.api+json; et=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
          body: JSON.stringify(bodydata),
        });
        let response = await result.json();
        console.log(response);
        if (!response.success) {
          await dispatch(setCheckoutSpinner(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setCheckoutSpinner(false));
          await dispatch(setPlannedSesionModal(false));
          await dispatch(setPlannedSessions(response.left_session));
          await dispatch(setLeftSelectedSlots({}));
          await dispatch(
            setAlertMessage({
              message: "Your booking is successful",
              color: "green",
            })
          );
        }
      } catch (e) {
        console.log(e);
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setCheckoutSpinner(false));
      }
    } else {
      await dispatch(setCheckoutSpinner(false));
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

//---> exporting multiple functions and actions

export const actions = {
  setUpcomingAppointments,
  setAlertMessage,
  setPastAppointments,
  setChannelId,
  setAlertMessage,
  saveSessionData,
  setWaitingSpinner,
  fetchPastBookings,

  fetchUpcomingBookings,
  fetchTodayBookings,
  fetchWeekBookings,
  setMenuHover,
  saveCallHistory,
  setRequestSender,
  setCallDuration,
  setPlannedSesionModal,
  fetchPlannedSessions,

  BreakPackage,
  setLeftPackage,
  setLeftSelectedDate,
  setLeftSelectedSlots,
  setLeftSlots,
  setLeftSlotsSpinner,
  BookLeftPackage,
  setleftPaymentId,
  setLeftSession,
  setCallStatus,
  setCurrentSession,
};

//---> defining the initialState for state variables

export const initialState = {
  errMessage: "",
  upcomingAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  todayAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  pastAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  weekAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  ongoingAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  plannedSessions: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  spinnerStatus: false,
  channel_id: "",
  sessionSpinner: false,
  waitingSpinner: false,
  reviewModal: false,
  bookPlannedSession: false,

  leftPackage: {},
  leftSelectedDate: "",
  leftSelectedSlots: {},
  leftSlots: {},
  leftSlotSpinner: false,
  review_listing_id: "",
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_APPOINTMENTS_BY_WEEK]: (state, action) => {
    return {
      ...state,
      weekAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },

  [SET_APPOINTMENTS_TODAY_DATA]: (state, action) => {
    return {
      ...state,
      todayAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },

  [SET_APPOINTMENTS_UPCOMING_DATA]: (state, action) => {
    return {
      ...state,
      upcomingAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },

  [SET_APPOINTMENTS_PAST_DATA]: (state, action) => {
    let { data } = action.payload;
    let newdata = data.sort(function (a, b) {
      return (
        new Date(a.booking_date, a.slot).getTime() -
        new Date(b.booking_date, b.slot).getTime()
      );
    });

    return {
      ...state,
      pastAppointments: {
        data: newdata,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },

  [SET_USER_ONGOING_APPOINTMENTS]: (state, action) => {
    let data = action.payload;
    let bookings = [];
    data.map((i) => {
      let startTime = new Date(
        i.booking_date.split("-")[0] +
          " " +
          i.booking_date.split("-")[1] +
          " " +
          i.booking_date.split("-")[2] +
          "," +
          i.counsellor_timezone_slot
      );
      let currentdate = new Date();
      let newStartTime = new Date(startTime.getTime() - 5 * 60000);
      let minutes = +i.package.session_hours * 60 + +i.package.session_minutes;
      let endTime = new Date(startTime.getTime() + minutes * 60000);
      if (
        currentdate.getTime() >= newStartTime.getTime() &&
        currentdate.getTime() <= endTime.getTime()
      ) {
        bookings.push(i);
      }
    });
    return {
      ...state,
      ongoingAppointments: {
        data: bookings,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },

  [SET_START_SESSION_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      sessionSpinner: action.payload,
    };
  },

  [SET_WAITING_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      waitingSpinner: action.payload,
    };
  },
  [SET_LOADING_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      spinnerStatus: action.payload,
    };
  },

  [SET_BOOK_PLANNED_SESSION_MODAL]: (state, action) => {
    return {
      ...state,
      bookPlannedSession: action.payload,
    };
  },
  [SET_PLANNED_SESSIONS_DATA]: (state, action) => {
    return {
      ...state,
      plannedSessions: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },
  [SET_LEFT_PACKAGE]: (state, action) => {
    return {
      ...state,
      leftPackage: action.payload,
    };
  },
  [SET_LEFT_SELECTED_DATE]: (state, action) => {
    return {
      ...state,
      leftSelectedDate: action.payload,
    };
  },
  [SET_LEFT_SELECTED_SLOTS]: (state, action) => {
    return {
      ...state,
      leftSelectedSlots: action.payload,
    };
  },
  [SET_LEFT_SLOTS_DATA]: (state, action) => {
    return {
      ...state,
      leftSlots: action.payload,
    };
  },
  [SET_LEFT_SLOTS_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      leftSlotSpinner: action.payload,
    };
  },
  [SET_LEFT_CHECKOUT_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      checkoutSpinner: action.payload,
    };
  },
  [SET_LEFT_PACKAGE_PAYMENT_ID]: (state, action) => {
    return {
      ...state,
      left_payment_id: action.payload,
    };
  },
  [SET_LEFT_PACKAGE_SESSIONS]: (state, action) => {
    return {
      ...state,
      left_sessions: action.payload,
    };
  },
};

export default function UserAppointmentReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
