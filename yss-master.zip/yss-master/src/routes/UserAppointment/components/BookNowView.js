import React, { Fragment } from "react";
import Spinner from "../../../components/Spinner/Spinner";
import { Link } from "react-router-dom";
import "react-modern-calendar-datepicker/lib/DatePicker.css";
import { Calendar } from "react-modern-calendar-datepicker";
import { checkSlots } from "../../../helpers/checkSlots";
import { setTimeLable } from "../../../helpers/checkSlots";
import { actions } from "../modules/UserAppointment";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import ModalBody from "../../../components/Modals/ModalBody";

import _ from "lodash";

let arr = [];
let selected = 0;

class BookingView extends React.Component {
  constructor(props) {
    super(props);
    let month = new Date().getMonth() + 1;
    let day = new Date().getDate();
    let year = new Date().getFullYear();
    this.state = {
      date_avail: { year: year, month: month, day: day },
      disabledDays: [],
    };
    this.submitHandler = this.submitHandler.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleDate = this.handleDate.bind(this);
    this.isSelected = this.isSelected.bind(this);
  }

  handleChange(e) {
    selected = 0;
    let {
      leftSelectedSlots,
      leftSelectedDate,
    } = this.props.UserAppointmentState;
    let value = e.target.value;
    let { date_avail } = this.state;
    let tempDate;
    if (date_avail === null) {
      tempDate = new Date().toISOString().slice(0, 10);
    } else {
      tempDate =
        date_avail.year + "-" + date_avail.month + "-" + date_avail.day;
    }

    if (Object.keys(leftSelectedSlots).length === 0) {
      leftSelectedSlots[leftSelectedDate] = [];
    }

    if (leftSelectedSlots[tempDate].includes(value)) {
      let index = leftSelectedSlots[tempDate].indexOf(value);
      leftSelectedSlots[tempDate].splice(index, 1);
    } else {
      leftSelectedSlots[tempDate].push(value);
    }

    Object.keys(leftSelectedSlots).map((arr) => {
      selected = selected + leftSelectedSlots[arr].length;
    });

    //this.props.setTimeAvail(arr);
    this.props.setLeftSelectedSlots(leftSelectedSlots);
  }

  handleDate(date) {
    let { leftSelectedSlots, leftPackage } = this.props.UserAppointmentState;
    this.setState({
      date_avail: { day: date.day, month: date.month, year: date.year },
    });

    let tempDate = date.year + "-" + date.month + "-" + date.day;
    this.props.setLeftSelectedDate(tempDate);
    if (!(tempDate in leftSelectedSlots)) {
      leftSelectedSlots[tempDate] = [];
    }
    this.props.setLeftSelectedDate(leftSelectedSlots);
    this.props.BreakPackage({
      ...this.state,
      date,
      ...{ leftPackage },
      history: this.props.history,
    });
  }

  isSelected = (time) => {
    let { date_avail } = this.state;
    let { leftSelectedSlots } = this.props.UserAppointmentState;
    let tempDate;
    if (date_avail === null) {
      tempDate = new Date().toISOString().slice(0, 10);
    } else {
      tempDate =
        date_avail.year + "-" + date_avail.month + "-" + date_avail.day;
    }
    if (tempDate in leftSelectedSlots) {
      if (leftSelectedSlots[tempDate].includes(time)) {
        return true;
      }
    }
  };

  async componentDidMount() {
    let body = document.body;
    body.className = "left_booking dashboard_bookings";

    let { leftSelectedSlots, leftPackage } = this.props.UserAppointmentState;
    this.props.BreakPackage({
      ...this.state,
      ...{ leftPackage },
      history: this.props.history,
    });

    Object.keys(leftSelectedSlots).map((arr) => {
      selected = selected + leftSelectedSlots[arr].length;
    });

    let month = new Date().getMonth() + 1;
    let day = new Date().getDate();
    let year = new Date().getFullYear();

    this.props.setLeftSelectedSlots(leftSelectedSlots);
    this.props.setLeftSelectedDate(year + "-" + month + "-" + day);

    // getting the previous days of the current month
    var date = new Date(),
      y = date.getFullYear(),
      m = date.getMonth();
    var firstDay = new Date(y, m, 1);
    let n = date.getDate() - firstDay.getDate();
    for (let i = 1; i <= n; i++) {
      date.setDate(date.getDate() - 1);
      let tempDate = {
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        day: date.getDate(),
      };
      this.state.disabledDays.push(tempDate);
    }
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
    selected = 0;
  }

  submitHandler() {
    let {
      leftPackage,
      leftSelectedSlots,
      left_payment_id,
      left_sessions,
    } = this.props.UserAppointmentState;
    Object.keys(leftSelectedSlots).map((i) => {
      if (leftSelectedSlots[i].length === 0) {
        delete leftSelectedSlots[i];
      }
    });
    if (Object.keys(leftSelectedSlots).length === 0) {
      this.props.setAlertMessage({
        message: "Please select the slot time!",
        color: "teal",
      });
    } else if (selected > left_sessions) {
      this.props.setAlertMessage({
        message: "Please select only " + left_sessions + " slots.",
        color: "teal",
      });
    } else {
      Object.keys(leftSelectedSlots).map((i) => {
        if (leftSelectedSlots[i].length === 0) {
          this.props.setAlertMessage({
            message: "Please select the slot time!",
            color: "teal",
          });
        } else {
          this.props.BookLeftPackage({
            leftSelectedSlots,
            selected,
            leftPackage,
            left_payment_id,
          });
        }
      });
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 7000);
  }

  render() {
    const {
      leftSlots,
      leftSlotSpinner,
      leftPackage,
      checkoutSpinner,
    } = this.props.UserAppointmentState;
    let { date_avail } = this.state;
    return (
      <Fragment>
        <ModalBody closeEvent={this.props.closeEvent}>
          <div className="main-content">
            <div className="site__content">
              <div className="page__content">
                <div className="w-full md:flex md:select-none justify-center items-center ">
                  <div className="bg-white p-4 w-full book_appointment_popup">
                    <div className="block__info">
                      <div className="block_title">
                        <h3>Selected time slot:</h3>

                        <div className="selected_time">
                          {leftPackage.session_hours}
                          {":"}
                          {leftPackage.session_minutes}{" "}
                          {setTimeLable(
                            leftPackage.session_hours,
                            leftPackage.session_minutes
                          )
                            ? "Minutes"
                            : "Hours"}
                          <span>{leftPackage.package_name}</span>
                        </div>

                        <div className="selected_time ml-1">
                          {leftPackage.no_of_slots == "01"
                            ? " Session"
                            : " Sessions"}
                          <span>
                            {selected}
                            {" selected"}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="block__info mt-10">
                      <div className="booking_blocks">
                        {/* -----------------Calender block------------------- */}
                        <div className="left_block">
                          <div className="block_title">
                            <h3>Select a date and time</h3>
                          </div>
                          <div className="w-full">
                            <Calendar
                              onChange={this.handleDate}
                              value={this.state.date_avail}
                              disabledDays={this.state.disabledDays} // here we pass them
                              onDisabledDayError={this.handleDisabledSelect}
                              shouldHighlightWeekends
                            />
                          </div>
                        </div>
                        {/* ---------------------Slot-time block--------------------*/}
                        <div className="right_block">
                          <div className="block_title">
                            <h3>
                              Availability on{" "}
                              {date_avail.day +
                                "-" +
                                date_avail.month +
                                "-" +
                                date_avail.year}
                            </h3>
                          </div>
                          <div className="time_availability">
                            {leftSlots.length === 0 ? (
                              <p>No slots are available.</p>
                            ) : null}

                            {leftSlotSpinner ? (
                              <Spinner />
                            ) : (
                              <form className="time_availability_form">
                                {Object.keys(leftSlots).map(
                                  (keyName, i) => (
                                    // checkSlots(date_avail,keyName.split("-")[0]) || checkSlots(date_avail,keyName.split("-")[1])
                                    // ? (
                                    <div className="form-item" key={i}>
                                      {/* <label>{keyName}</label> */}
                                      <div
                                        className="form-item-radio-advance"
                                        onChange={this.handleChange}
                                      >
                                        {leftSlots[keyName].map((item) =>
                                          item.slot !== "" &&
                                          checkSlots(date_avail, item.slot) ? (
                                            <span key={item.slot}>
                                              <input
                                                id={item.slot.replace(" ", "-")}
                                                type="checkbox"
                                                name="time_avail"
                                                value={item.slot}
                                              />
                                              <label
                                                className={
                                                  item.enabled === 0
                                                    ? "text-gray-500 pointer-events-none"
                                                    : this.isSelected(item.slot)
                                                    ? "border-blue-800"
                                                    : ""
                                                }
                                                htmlFor={item.slot.replace(
                                                  " ",
                                                  "-"
                                                )}
                                              >
                                                {item.slot}
                                              </label>
                                            </span>
                                          ) : null
                                        )}
                                      </div>
                                    </div>
                                  )
                                  // ) :'No slots are available'
                                )}
                              </form>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="btn text-right float-right">
                      <Link
                        to="#"
                        className="bg_blue text-white"
                        onClick={() => this.submitHandler()}
                      >
                        {checkoutSpinner ? (
                          <LoadingSpinner />
                        ) : (
                          "Proceed For Booking"
                        )}
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </ModalBody>
      </Fragment>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  UserAppointmentState: state.UserAppointmentState,
  ListingState: state.ListingState,
});

export default connect(mapStateToProps, mapDispatchToProps)(BookingView);
