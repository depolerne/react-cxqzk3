import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import Spinner from "../../../components/Spinner/Spinner";
import CancelModal from "../../../components/Modals/cancelModal";
import moment from "moment";
import auth from "../../../helpers/auth";
import { Calendar, momentLocalizer } from "react-big-calendar";
import { setTimeLable } from "../../../helpers/checkSlots";
import ReviewModal from "../../../components/Modals/ReviewModal/ReviewModal";
import BookNowView from "./BookNowView";

const localizer = momentLocalizer(moment);

const modaltext = "Are you sure you want to cancel this Appointment";
var values = [];

var targetData = [];
var last_page = 0;
var currentPage = 1;
var totalPage = [];

export class UserAppointmentView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      startSession: false,
      tab: "upcoming",
      events: [],
      x: false,
    };
    this.setTabState = this.setTabState.bind(this);
    this.cancelBooking = this.cancelBooking.bind(this);
    this.startSession = this.startSession.bind(this);
    this.loadBookings = this.loadBookings.bind(this);
    this.setSessionClass = this.setSessionClass.bind(this);
    this.prevPage = this.prevPage.bind(this);
    this.nextPage = this.nextPage.bind(this);
    this.changePage = this.changePage.bind(this);
    this.setPageClass = this.setPageClass.bind(this);
    this.checkJoinStatus = this.checkJoinStatus.bind(this);
    this.bookAgain = this.bookAgain.bind(this);
    this.isCompleted = this.isCompleted.bind(this);
    this.bookNow = this.bookNow.bind(this);
    // this.checkCompleted=this.checkCompleted.bind(this);
  }

  //--->  setting state for navigation-tabs(PAST and UPCOMING tabs)
  async setTabState(value) {
    let {
      upcomingAppointments,
      pastAppointments,
      todayAppointments,
      weekAppointments,
    } = this.props.UserAppointmentState;

    this.setState({
      tab: value,
    });
    if (value === "upcoming") {
      currentPage = upcomingAppointments.currentPage;
      await this.props.fetchUpcomingBookings(currentPage);
    } else if (value === "past") {
      currentPage = pastAppointments.currentPage;
      await this.props.fetchPastBookings(currentPage);
    } else if (value === "week") {
      currentPage = weekAppointments.currentPage;
      await this.props.fetchWeekBookings(currentPage);
    } else if (value === "today") {
      currentPage = todayAppointments.currentPage;
      await this.props.fetchTodayBookings(currentPage);
    } else if (value === "ongoing") {
      await this.props.fetchTodayBookings(-1);
    } else if (value === "sessions") {
      await this.props.fetchPlannedSessions(currentPage);
    }
  }

  setSessionClass(item) {
    let {
      counsellor_timezone_slot,
      package: { session_hours, session_minutes },
      booking_date,
    } = item;

    var x = false;
    let bookingDate = booking_date.split("-"); // removing dashes from the date
    var d = new Date(
      bookingDate[0] +
        " " +
        bookingDate[1] +
        " " +
        bookingDate[2] +
        "," +
        counsellor_timezone_slot
    );
    var startTime = new Date(d.getTime() - 5 * 60000);
    var startTime1 = new Date(
      bookingDate[0] +
        " " +
        bookingDate[1] +
        " " +
        bookingDate[2] +
        "," +
        counsellor_timezone_slot
    );
    var startTimeHour = startTime.getHours();
    var startTimeMinute = startTime.getMinutes();
    if (startTimeMinute / 2 < 5) {
      var NewStartTime = parseInt(
        startTimeHour + "" + 0 + "" + startTimeMinute
      );
    } else {
      var NewStartTime = parseInt(startTimeHour + "" + startTimeMinute);
    }
    var time = +session_hours * 60 + +session_minutes;
    var endTime = new Date(
      startTime1.setMinutes(startTime1.getMinutes() + time)
    );
    var endTimeHour = endTime.getHours();
    var endTimeMinute = endTime.getMinutes();

    if (endTimeMinute / 2 < 5) {
      var NewEndTime = parseInt(endTimeHour + "" + 0 + "" + endTimeMinute);
    } else {
      var NewEndTime = parseInt(endTimeHour + "" + endTimeMinute);
    }

    var currentDate = new Date();
    var currentDateHour = currentDate.getHours();
    var currentDateMinute = currentDate.getMinutes();
    if (currentDateMinute / 2 < 5) {
      var NewCurrentTime = parseInt(
        currentDateHour + "" + 0 + "" + currentDateMinute
      );
    } else {
      var NewCurrentTime = parseInt(currentDateHour + "" + currentDateMinute);
    }
    if (
      NewCurrentTime >= NewStartTime &&
      NewCurrentTime <= NewEndTime &&
      currentDate.getUTCDate() == startTime.getUTCDate() &&
      currentDate.getFullYear() == startTime.getFullYear()
    ) {
      x = true;
    } else {
      x = false;
    }
    return x;
  }

  startSession(item) {
    let { sessionData } = this.props.selectState;
    sessionData["from_id"] = item.user.id;
    sessionData["to_id"] = item.counsellor.id;
    sessionData["session_hours"] = item.package.session_hours;
    sessionData["session_minutes"] = item.package.session_minutes;
    sessionData["booking_id"] = item.id;
    sessionData["username"] = item.user.name;
    sessionData["slot"] = item.counsellor_timezone_slot;
    this.props.saveSessionData(sessionData);
    if (this.setSessionClass(item)) {
      this.props.history.push("/dashboard/startsession");
    }
  }

  cancelBooking(Id) {
    this.setState({ showModal: true });
    console.log(Id);
  }

  async componentDidMount() {
    await this.props.fetchUpcomingBookings(currentPage);
    await this.props.setMenuHover("bookings");
    let body = await document.body;
    body.className = "dashboard_bookings";
    await this.loadBookings();
    document.addEventListener("keyup", (e) => {
      if (e.keyCode === 27) {
        this.setState({ showModal: false });
        this.props.setPlannedSesionModal(false);
        this.props.setLeftSelectedSlots({});
      }
    });
  }

  componentWillUnmount() {
    this.setState = (state, callback) => {
      return;
    };
  }

  async loadBookings() {
    const token = auth.getAccessToken();
    this.setState({ loadingSpinner: true });
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/all/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          await this.setState({ loadingSpinner: false });
        } else if (response.success) {
          await this.setState({
            bookings: response.bookings,
            loadingSpinner: false,
          });
        }
      } catch (e) {
        console.log(e);
      }
    }

    let { bookings } = await this.state;
    if (bookings) {
      for (let i = 0; i < bookings.length; i++) {
        let temp = {};
        let duration =
          +bookings[i].package.session_hours * 60 +
          +bookings[i].package.session_minutes;
        let bookingDate = bookings[i].booking_date.split("-"); // removing dashes from the date
        let startvalue = new Date(
          bookingDate[0] +
            " " +
            bookingDate[1] +
            " " +
            bookingDate[2] +
            "," +
            bookings[i].counsellor_timezone_slot
        );
        let endvalue = new Date(startvalue.getTime() + duration * 60000);
        temp = Object.assign(
          temp,
          { start: startvalue },
          { end: endvalue },
          { title: `${bookings[i].counsellor.name}` }
        );
        if (
          values.length !== bookings.length &&
          values.length <= bookings.length
        ) {
          values.push(temp);
        }
      }
    }
    this.setState({ events: values });
  }

  async prevPage(e) {
    let num = (await parseInt(currentPage)) - 1;
    let { tab } = this.state;
    if (currentPage > 1) {
      currentPage = num;
      if (tab === "upcoming") {
        await this.props.fetchUpcomingBookings(currentPage);
      } else if (tab === "past") {
        await this.props.fetchPastBookings(currentPage);
      } else if (tab === "week") {
        await this.props.fetchWeekBookings(currentPage);
      } else if (tab === "today") {
        await this.props.fetchTodayBookings(currentPage);
      } else if (tab === "sessions") {
        await this.props.fetchPlannedSessions(currentPage);
      }
    }
  }

  async nextPage() {
    let { tab } = this.state;
    let num = (await parseInt(currentPage)) + 1;
    if (currentPage < last_page) currentPage = num;
    if (tab === "upcoming") {
      await this.props.fetchUpcomingBookings(currentPage);
    } else if (tab === "past") {
      await this.props.fetchPastBookings(currentPage);
    } else if (tab === "week") {
      await this.props.fetchWeekBookings(currentPage);
    } else if (tab === "today") {
      await this.props.fetchTodayBookings(currentPage);
    } else if (tab === "sessions") {
      await this.props.fetchPlannedSessions(currentPage);
    }
  }

  async changePage(e) {
    let { tab } = this.state;
    let value = await e.target.name;
    currentPage = value;
    if (tab === "upcoming") {
      await this.props.fetchUpcomingBookings(currentPage);
    } else if (tab === "past") {
      await this.props.fetchPastBookings(currentPage);
    } else if (tab === "week") {
      await this.props.fetchWeekBookings(currentPage);
    } else if (tab === "today") {
      await this.props.fetchTodayBookings(currentPage);
    } else if (tab === "sessions") {
      await this.props.fetchPlannedSessions(currentPage);
    }
  }

  setPageClass(value) {
    if (value === currentPage) {
      return true;
    } else {
      return false;
    }
  }

  isCompleted(item) {
    let {
      package: { session_hours, session_minutes },
    } = item;
    let minutes = +session_hours * 60 + +session_minutes;
    let startTime = new Date(
      item.booking_date.split("-")[0] +
        " " +
        item.booking_date.split("-")[1] +
        " " +
        item.booking_date.split("-")[2] +
        "," +
        item.counsellor_timezone_slot
    );
    let endTime = new Date(startTime.getTime() + minutes * 60000);
    if (endTime < new Date()) {
      return true;
    } else {
      return false;
    }
  }

  bookAgain(id) {
    this.props.history.push(`/listing/${id}`);
  }

  bookNow(item) {
    this.props.setleftPaymentId(item.payment_id);
    this.props.setLeftPackage(item.package);
    this.props.setLeftSession(item.left_sessions);
    this.props.setPlannedSesionModal(true);
  }

  checkJoinStatus(_id) {
    if (localStorage.getItem("join_status")) {
      let data = JSON.parse(localStorage.getItem("join_status"));
      if (data.id === _id) {
        return true;
      }
    }
  }

  render() {
    let { tab } = this.state;
    let {
      sessionSpinner,
      spinnerStatus,
      upcomingAppointments,
      pastAppointments,
      todayAppointments,
      weekAppointments,
      ongoingAppointments,
      plannedSessions,
      reviewModal,
      bookPlannedSession,
    } = this.props.UserAppointmentState;

    if (tab == "upcoming") {
      targetData = upcomingAppointments.data;
      currentPage = upcomingAppointments.currentPage;
      last_page = upcomingAppointments.last_page;
      totalPage = upcomingAppointments.totalPage;
    } else if (tab === "past") {
      targetData = pastAppointments.data;
      currentPage = pastAppointments.currentPage;
      last_page = pastAppointments.last_page;
      totalPage = pastAppointments.totalPage;
    } else if (tab === "today") {
      targetData = todayAppointments.data;
      currentPage = todayAppointments.currentPage;
      last_page = todayAppointments.last_page;
      totalPage = todayAppointments.totalPage;
    } else if (tab === "week") {
      targetData = weekAppointments.data;
      currentPage = weekAppointments.currentPage;
      last_page = weekAppointments.last_page;
      totalPage = weekAppointments.totalPage;
    } else if (tab === "ongoing") {
      targetData = ongoingAppointments.data;
      currentPage = ongoingAppointments.currentPage;
      last_page = ongoingAppointments.last_page;
      totalPage = ongoingAppointments.totalPage;
    } else if (tab === "sessions") {
      targetData = plannedSessions.data;
      currentPage = plannedSessions.currentPage;
      last_page = plannedSessions.last_page;
      totalPage = plannedSessions.totalPage;
    } else if (tab === "calendar") {
      targetData = [];
      last_page = 0;
      currentPage = 1;
      totalPage = [];
    }

    return (
      <Fragment>
        <div className="main-content planned_sessions">
          <div className="site__content">
            {this.state.showModal ? (
              <CancelModal
                cancelEvent={() => this.setState({ showModal: false })}
                actionEvent={() => this.cancelBooking()}
                warningText={modaltext}
                actionText={"Cancel Appointment"}
                cancelText={"Discard"}
                warningText={
                  "Are you sure you want to cancel this Appointment ?"
                }
              />
            ) : null}
            {/* {reviewModal ? (
              <ReviewModal
                cancelEvent={() => {
                  this.props.openReviewModal(false);
                }}
              />
            ) : null} */}
            {bookPlannedSession ? (
              <BookNowView
                leftSession={true}
                closeEvent={() => {
                  this.props.setPlannedSesionModal(false);
                  this.props.setLeftSelectedSlots({});
                }}
              />
            ) : null}
            {sessionSpinner ? (
              <Spinner />
            ) : (
              <div className="page__content">
                <div className="form__heading">
                  <h3>
                    Booked <span>Appointments</span>
                  </h3>
                </div>
                <div className="middle__content">
                  <div className="tabs__wrapper">
                    {/* ------------------- Setting state for filter tabs -------------- */}
                    <div className="tabs">
                      <ul className="tab_lists">
                        <li
                          className={
                            tab === "upcoming" ? "ui-tabs-active" : "ui-tabs"
                          }
                        >
                          <Link
                            to="#"
                            onClick={() => this.setTabState("upcoming")}
                          >
                            Upcoming Appointments
                          </Link>
                        </li>
                        <li
                          className={
                            tab === "past" ? "ui-tabs-active" : "ui-tabs"
                          }
                        >
                          <Link to="#" onClick={() => this.setTabState("past")}>
                            Past Appointments
                          </Link>
                        </li>
                        <li
                          className={
                            tab === "sessions" ? "ui-tabs-active" : "ui-tabs"
                          }
                        >
                          <Link
                            to="#"
                            onClick={() => this.setTabState("sessions")}
                          >
                            Plan your Sessions
                          </Link>
                        </li>
                      </ul>
                    </div>
                    {tab === "upcoming" ||
                    tab === "today" ||
                    tab === "week" ||
                    tab === "ongoing" ||
                    tab === "calendar" ? (
                      <div className="filter_tabs">
                        <ul className="filter_lists">
                          <li
                            className={
                              tab === "ongoing"
                                ? "active_filter ongoing_filter"
                                : "ongoing_filter"
                            }
                          >
                            <Link
                              to="#"
                              onClick={() => this.setTabState("ongoing")}
                            >
                              On-Going
                            </Link>
                          </li>

                          <li
                            className={
                              tab === "today"
                                ? "active_filter day_filter"
                                : "day_filter"
                            }
                          >
                            <Link
                              to="#"
                              onClick={() => this.setTabState("today")}
                            >
                              Today
                            </Link>
                          </li>
                          <li
                            className={
                              tab === "week"
                                ? "active_filter week_filter"
                                : "week_filter"
                            }
                          >
                            <Link
                              to="#"
                              onClick={() => this.setTabState("week")}
                            >
                              Week
                            </Link>
                          </li>
                          <li
                            className={
                              tab === "calendar"
                                ? "active_filter calendar_filter"
                                : "calendar_filter"
                            }
                          >
                            <Link
                              to="#"
                              onClick={() => this.setTabState("calendar")}
                            >
                              Calendar
                            </Link>
                          </li>
                        </ul>
                      </div>
                    ) : null}
                  </div>

                  {/* ----------------------------------------------------------------------------- */}
                  {tab !== "calendar" && tab !== "sessions" ? (
                    spinnerStatus ? (
                      <Spinner text={"Fetching details..."} />
                    ) : targetData.length === 0 ? (
                      <h3 className="text-center">No Appointments</h3>
                    ) : (
                      <ul className="o-lists">
                        {targetData.map((item, i) => (item.counsellor && item.listing && item.user &&
                          <li className="list-item booking_list" key={i}>
                            {item.listing &&
                              item.counsellor &&
                              item.user &&
                              item.package && (
                                <div className="booking_detail">
                                  <div className="left_detail">
                                    <span className="patient_name">
                                      {item.counsellor.name}
                                    </span>
                                    <span className="booking_day">
                                      Timings: {item.counsellor_timezone_slot.toLowerCase()}
                                    </span>
                                    <span className="booking_counter">
                                      Amount : {"£"}
                                      {item.package.amount}
                                    </span>
                                  </div>
                                  <div className="right_detail">
                                    <span className="last_booking">
                                      Appointment Date:{" "}
                                      <span>{item.booking_date}</span>
                                    </span>
                                    <span className="location">
                                      Package:{" "}
                                      <span>{item.package.package_name}</span>
                                    </span>
                                    <span className="location">
                                      Duration:{" "}
                                      <span>
                                        {item.package.session_hours}
                                        {":"}
                                        {item.package.session_minutes}
                                      </span>{" "}
                                      {setTimeLable(
                                        item.package.session_hours,
                                        item.package.session_minutes
                                      )
                                        ? "Minutes"
                                        : "Hours"}
                                    </span>
                                  </div>
                                </div>
                              )}
                            <div className="booking_options flex md:justify-end">
                              <div className="video_session session_confirmation flex">
                                {this.isCompleted(item) ? (
                                  <Link className="pointer-events-none" to="#">
                                    Completed
                                  </Link>
                                ) : (
                                  <Link
                                    className={
                                      this.setSessionClass(item)
                                        ? "active"
                                        : "pointer-events-none"
                                    }
                                    to="#"
                                    onClick={() => this.startSession(item)}
                                  >
                                    {this.checkJoinStatus(item.id) &&
                                    this.setSessionClass(item)
                                      ? "Join Again"
                                      : "Start Session"}
                                  </Link>
                                )}
                              </div>
                              <div className="session_confirmation flex">
                                <Link
                                  to={`/listing/${item.listing.id}`}
                                  className="bookAgain"
                                >
                                  Book Again
                                </Link>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )
                  ) : null}
                  {/* ------------------------------------------------------------------------------ */}

                  {tab === "calendar" ? (
                    <Fragment>
                      <div className="app_new--section">
                        <div className="help__block">
                          <div className="page_title text-center">
                            <h1 className="text-xl">
                              <span className="text_nav_blue">Information</span>
                            </h1>
                          </div>
                          <div className="help__text">
                          <p>Contrary to popular belief Lorem Ipsum is not simply random.</p>
                          <p>It has roots a piece classical Latin</p>
                          <p>literature from 45 BC, making it over<br /> 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia,</p>
                          <p>looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum.</p>
                          <p>passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32.</p>
                          </div>
                        </div>
                        <div className="app_new--calendar">
                          <Calendar
                            localizer={localizer}
                            defaultDate={new Date()}
                            defaultView="month"
                            events={this.state.events}
                            style={{ height: "100vh" }}
                            views={["month", "day", "week"]}
                            tooltipAccessor={"Ibyte infomatics"}
                          />
                        </div>
                      </div>
                    </Fragment>
                  ) : null}

                  {/* ------------------------------------------------------------------------------ */}
                  {tab === "sessions" &&
                    (spinnerStatus ? (
                      <Spinner />
                    ) : plannedSessions.data.length === 0 ? (
                      <h3 className="text-center">No sessions</h3>
                    ) : (
                      <ul className="o-lists">
                        {plannedSessions.data.map((item) => (
                          <li className="list-item booking_list" key={item.id}>
                            <div className="booking_detail">
                              <div className="left_detail">
                                <span className="patient_name">
                                  {item.package.user.name}
                                </span>
                                <span className="booking_day">
                                  Last session Timings: {item.last_appointment_slot&&item.last_appointment_slot.toLowerCase()}
                                </span>
                                <span className="booking_counter">
                                  Amount : {"£"}
                                  {item.package.amount}
                                </span>
                              </div>
                              <div className="right_detail">
                                <span className="last_booking">
                                  last Appointment Date: <span>{item.last_appointment_date}</span>
                                </span>
                                <span className="location">
                                  Package:{" "}
                                  <span>{item.package.package_name}</span>
                                </span>
                                <span className="location">
                                  Duration:{" "}
                                  <span>
                                    {item.package.session_hours}
                                    {":"}
                                    {item.package.session_minutes}
                                  </span>{" "}
                                  {setTimeLable(
                                        item.package.session_hours,
                                        item.package.session_minutes
                                      )
                                        ? "Minutes"
                                        : "Hours"}
                                </span>
                              </div>
                            </div>
                            <div className="booking_options md:justify-end flex">
                              <div className="video_session session_confirmation flex">
                                <span
                                  className="active bg-white w-full block text-center py-2 px-4 border border-solid border-color-blue"
                                  to="#"
                                >
                                  {item.left_sessions} out of{" "}
                                  {item.package.no_of_slots} Sessions left
                                </span>
                              </div>
                              <div className="session_confirmation flex">
                                <Link
                                  to="#"
                                  className="bookAgain"
                                  onClick={() => this.bookNow(item)}
                                >
                                  Book Now
                                </Link>
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    ))}
                    
                    {/* ------------Paginations---------------------------------------------------- */}
                    {targetData.length == 0 ||
                    last_page == 1 ||
                    tab === "ongoing" ? null : (
                      <div className="site_pagination">
                        <ul>
                          <li className={currentPage > 1 ? "prev" : "disable"}>
                            <Link to="#" onClick={this.prevPage}>
                              &lt; Prev{" "}
                            </Link>
                          </li>
                          {totalPage.map((number, i) => {
                            return (
                              <li className="prev" key={i}>
                                <Link
                                  to="#"
                                  className={
                                    this.setPageClass(number + 1)
                                      ? "bg-blue-900 text-white"
                                      : ""
                                  }
                                  name={number + 1}
                                  onClick={this.changePage}
                                >
                                  {number + 1}
                                </Link>
                              </li>
                            );
                          })}
                          <li
                            className={currentPage < last_page ? "next" : "disable"}
                          >
                            <Link to="#" onClick={this.nextPage}>
                              Next &gt;{" "}
                            </Link>
                          </li>
                        </ul>
                      </div>
                    )}
                </div>                
              </div>
            )}
          </div>
        </div>
      </Fragment>
    );
  }
}

export default UserAppointmentView;
