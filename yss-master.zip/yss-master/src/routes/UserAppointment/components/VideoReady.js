import React, { Fragment } from "react";
import Spinner from "../../../components/Spinner/Spinner";
import { Link } from "react-router-dom";
import { socket } from "../../../helpers/socketHelper";
import { connect } from "react-redux";
import { actions } from "../modules/UserAppointment";
import "../../../assets/video.css";
import Webcam from "react-webcam";

class VideoReady extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      audio: true,
      video: true,
    };
    this.hitSocket = this.hitSocket.bind(this);
    this.declineCall = this.declineCall.bind(this);
    this.toggleAudio = this.toggleAudio.bind(this);
    this.toggleVideo = this.toggleVideo.bind(this);
    const {
      sessionData: { to_id },
    } = this.props.selectState;
    if (to_id === undefined || to_id === "") {
      this.props.history.push("/dashboard/appointments");
    }
  }

  hitSocket() {
    const {
      to_id,
      from_id,
      session_hours,
      session_minutes,
      booking_id,
      username,
      slot,
    } = this.props.selectState.sessionData;
    let {
      userData: { avatar_id, id },
      sessionData,
    } = this.props.selectState;

    let minutes = +session_hours * 60 + +session_minutes;
    const channel = Math.random().toString(36).substring(2, 7);
    let obj = {
      id: booking_id,
      username: username,
      avatar: avatar_id,
      time: minutes,
      channel_id: channel,
      reciever_id: to_id,
      sender_id: from_id,
      slot: slot,
    };
    if (to_id !== undefined || to_id !== "") {
      socket.emit("new-call", obj);
      this.props.setCurrentSession(obj);
      localStorage.setItem("call_status", "ringing");
      this.props.setWaitingSpinner(true);
      this.props.setChannelId(channel);
      this.props.setCallDuration(minutes);
      this.props.setCallStatus("initiator");
      setTimeout(() => {
        if (localStorage.getItem("call_status") === "ringing") {
          if (booking_id) {
            socket.emit("remove", { reciever_id: to_id, id: booking_id });
            localStorage.setItem("call_status", "not_answered");
            this.props.setAlertMessage({
              message: "Call not answered!! Please try again",
              color: "teal",
            });
          }
          this.props.setWaitingSpinner(false);
          this.props.saveCallHistory(
            "0",
            booking_id,
            "0",
            id,
            "0",
            "disconnected"
          );
        }
        setTimeout(() => {
          this.props.setAlertMessage({ message: "", color: "" });
        }, 5000);
      }, 1800000);
    }
  }

  // function to disconncting the call manually
  declineCall() {
    const {
      sessionData: { booking_id, to_id },
      userData: { id },
    } = this.props.selectState;
    if (to_id) {
      socket.emit("remove", { reciever_id: to_id, id: booking_id });
      localStorage.setItem("call_status", "declined");
      this.props.saveCallHistory("0", booking_id, id, "0", id, "disconnected");
    }
    this.props.setWaitingSpinner(false);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "start_session";
    let {
      userData: { id },
      sessionData: { booking_id },
    } = this.props.selectState;
    socket.on("stop_spinner", (data) => {
      if (data.success) {
        this.props.setWaitingSpinner(false);
        localStorage.setItem("call_status", "connected");
        this.props.setRequestSender(data.reciever);
        this.props.history.push("/session/new_session");
        this.props.setAlertMessage({
          message: "connecting...",
          color: "green",
        });
      } else {
        console.log(data);
        this.props.saveCallHistory(
          "0",
          booking_id,
          id,
          "0",
          data.cut_by,
          "declined"
        );
        this.props.setWaitingSpinner(false);
        this.props.setAlertMessage({
          message: "Call declined !!",
          color: "teal",
        });
        localStorage.setItem("call_status", "declined");
      }
      setTimeout(() => {
        this.props.setAlertMessage({ message: "", color: "" });
      }, 5000);
    });
  }

  componentWillUnmount() {
    const { sessionData, userData } = this.props.selectState;
    const { to_id, booking_id } = sessionData;
    if (to_id) {
      socket.emit("remove", {
        ...{ id: booking_id, reciever_id: to_id },
      });
    }
    this.props.setWaitingSpinner(false);
    this.setState({ video: false });
    const video = document.querySelector("video");
    if (video !== null) {
      const mediaStream = video.srcObject;
      if (mediaStream !== null) {
        const tracks = mediaStream.getTracks();
        tracks[0].stop();
        tracks.forEach((track) => track.stop());
      }
    }
    this.setState({ video: false });
  }

  toggleAudio(value) {
    this.setState({ audio: value });
  }

  toggleVideo(value) {
    this.setState({ video: value });
  }

  render() {
    let { waitingSpinner } = this.props.UserAppointmentState;
    return (
      <div className="main-content">
        <div className="site__content">
          <div className="page__content">
            <div className="form__heading">
              <h3>
                Start <span>Session</span>
              </h3>
            </div>
            <div className="middle__content">
              <div className="video-call-join-session">
                <div className="webcam__display">
                  <div className="webcam__view">
                    {this.state.video && <Webcam audio={false} />}
                  </div>
                  <div className="webcam--actions">
                    {this.state.audio ? (
                      <Link
                        to="#"
                        onClick={() => this.toggleAudio(false)}
                        className="mic-on cam-control"
                        title="Turn off Mic"
                      >
                        <img src="images/icons/mic-off.png" />
                      </Link>
                    ) : (
                      <Link
                        to="#"
                        onClick={() => this.toggleAudio(true)}
                        className="mic-off cam-control"
                        title="Turn on Mic"
                      >
                        <img src="images/icons/mic-on.png" />
                      </Link>
                    )}
                    {this.state.video ? (
                      <Fragment>
                        <Link
                          to="#"
                          onClick={() => this.toggleVideo(false)}
                          className="cam-on cam-control"
                          title="Turn off Camera"
                        >
                          <img src="images/icons/web-camera-off.png" />
                        </Link>
                      </Fragment>
                    ) : (
                      <Link
                        to="#"
                        onClick={() => this.toggleVideo(true)}
                        className="cam-off cam-control"
                        title="Turn on Camera"
                      >
                        <img src="images/icons/web-camera-on.png" />
                      </Link>
                    )}
                  </div>
                </div>

                <div className="video-call__actions">
                  {waitingSpinner ? (
                    <Fragment>
                      <Spinner text={"Asking to join..."} />
                      <div className="call-button">
                        <Link
                          className="ml-2 cut-call"
                          onClick={() => this.declineCall()}
                          to="#"
                        >
                          <img src="images/icons/cut_call.png" />
                        </Link>
                      </div>
                    </Fragment>
                  ) : (
                    <Fragment>
                      <div className="call-title">
                        <h3>Ready to Join?</h3>
                      </div>
                      <div className="call-button">
                        <Link to="#" onClick={this.hitSocket}>
                          Ask to join
                        </Link>
                        <Link
                          className="ml-2"
                          to="/dashboard/appointments"
                          onClick={() => this.toggleVideo(false)}
                        >
                          Go back
                        </Link>
                      </div>
                    </Fragment>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  auth: state.auth,
  UserAppointmentState: state.UserAppointmentState,
});

export default connect(mapStateToProps, actions)(VideoReady);
