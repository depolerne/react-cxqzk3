import React from 'react';
import {
    actions,fetchBooking
} from '../modules/UserAppointment';

import { bindActionCreators } from 'redux';
import UserAppointmentView from '../components/UserAppointmentView';
import { connect } from 'react-redux';
import { withJob } from 'react-jobs';
import RedBox from 'redbox-react';

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});

const mapStateToProps = (state) => ({
    selectState:state.selectState,
    UserAppointmentState: state.UserAppointmentState,
    CDashboardState:state.CDashboardState
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => {
        // dispatch(fetchBooking());
    },
    /* eslint-disable */ ErrorComponent: ({ error }) => __DEV__ ? <RedBox error={error} /> : null,
})(UserAppointmentView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
