import fetch from "isomorphic-fetch";
import auth from "../../../helpers/auth";
import { setAuthModal } from "../../Listing/modules/Listing";
import { setUserEmail } from "../../login/modules/auth";

export const SIGNUP_P_SET_ERR_SIGNUP_MESSAGE =
  "SIGNUP_P_SET_ERR_SIGNUP_MESSAGE";
export const SET_SIGNUP_SPINNER_STATUS = "SET_SIGNUP_SPINNER_STATUS";
export const SET_SIGNUP_FIELDS_DATA = "SET_SIGNUP_FIELDS_DATA";

export const setErrSignupMessage = (value) => {
  return {
    type: SIGNUP_P_SET_ERR_SIGNUP_MESSAGE,
    payload: value,
  };
};

export const setSpinnerStatus = (value) => {
  return {
    type: SET_SIGNUP_SPINNER_STATUS,
    payload: value,
  };
};

export const setSignUpData = (value) => {
  return {
    type: SET_SIGNUP_FIELDS_DATA,
    payload: value,
  };
};

export const register = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setErrSignupMessage({}));
    await dispatch(setSpinnerStatus(true));
    await dispatch(setUserEmail(data.email));
    let { name, email, password, c_password, timezone } = data;
    try {
      const result = await fetch(
        `${__API__}/register?name=${name}&email=${email}&password=${password}&c_password=${c_password}&timezone=${timezone}`,
        {
          method: "POST",
          cache: "no-cache",

          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        await dispatch(setSpinnerStatus(false));
        Object.keys(response.errors).map((item) => {
          dispatch(
            setErrSignupMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        if (response.user.account_enabled === "3") {
          await dispatch(
            setErrSignupMessage({
              message:
                "Registered successfully, Now verify your account to login.",
              color: "green",
            })
          );
          await dispatch(setSpinnerStatus(false));
          await dispatch(setAuthModal("OTP"));
        }
        // await data.history.push('/');
        // const { authModal } = getState().CListingState;
        // if (authModal === "signup" || authModal === "login") {
        //   await dispatch(setAuthModal("login"));
        // } else {
        //   window.location.href = "/login";
        // }
      }
    } catch (e) {
      await dispatch(
        setErrSignupMessage({
          message: "Server error occured.Please try again.",
          color: "teal",
        })
      );
      await dispatch(setSpinnerStatus(false));
      console.log(e);
    }
    setTimeout(() => {
      dispatch(setErrSignupMessage({ message: "", color: "" }));
    }, 6000);
  };
};

export const actions = {
  register,
  setErrSignupMessage,
  setAuthModal,
  setSignUpData,
};

const initialState = {
  errSignupMessage: {
    message: "",
    color: "",
  },
  signUpSpinnerStatus: false,
  signUpData: {
    name: "",
    email: "",
    password: "",
    c_password: "",
    timezone: "",
  },
};

const ACTION_HANDLERS = {
  [SIGNUP_P_SET_ERR_SIGNUP_MESSAGE]: (state, action) => {
    return {
      ...state,
      errSignupMessage: action.payload,
    };
  },
  [SET_SIGNUP_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      signUpSpinnerStatus: action.payload,
    };
  },
  [SET_SIGNUP_FIELDS_DATA]: (state, action) => {
    return {
      ...state,
      signUpData: { ...action.payload },
    };
  },
};

const SignupReducer = (state = initialState, action) => {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
};

export default SignupReducer;
