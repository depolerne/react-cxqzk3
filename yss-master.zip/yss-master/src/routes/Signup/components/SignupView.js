import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import LoadingSpinner from "./../../../components/LoadingSpinner/LoadingSpinner";
import AlertBox from "../../../components/AlertBox/AlertBox";
import { NameValidator } from "../../../helpers/NameValidator";
import AuthOTPModal from "../../Listing/components/AuthOTPModal";
import { ZoneList } from "../../../helpers/ZoneList";
import Select from "react-select";

export class SignupView extends React.Component {
  constructor(props) {
    super(props);
    this.handlechange = this.handlechange.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.state = {
      errClass: "",
    };
  }

  handleSelect(selected, event) {
    let { signUpData } = this.props.Signup;
    signUpData[event.name] = selected.value;
    this.props.setSignUpData(signUpData);
  }

  handlechange(event) {
    let { signUpData } = this.props.Signup;
    const name = event.target.name;
    const value = event.target.value;
    if (value === "select") {
      signUpData[name] = "";
    } else {
      signUpData[name] = value;
    }
    this.props.setSignUpData(signUpData);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "user_signup";
    if (this.props.ListingState.authModal !== "signup") {
      this.props.setAuthModal("");
    }
  }

  componentWillUnmount() {
    this.props.setSignUpData({
      name: "",
      email: "",
      password: "",
      c_password: "",
    });
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  submitHandler(event) {
    event.preventDefault();
    let specials = /[!@#$%^&*()_+\-=\[\]{};':"`~\\|,.<>\/?]+/;
    let regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    let myRegEx = /[^a-z \d]/i;
    let { signUpData } = this.props.Signup;
    if (signUpData.name.length < 3) {
      this.props.setErrSignupMessage({
        message: "Name must contain 3 characters.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (NameValidator(signUpData.name.replace(/ /g, ""))) {
      this.props.setErrSignupMessage({
        message: "Name must start with 3 alphabets.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (signUpData.name.length > 32) {
      this.props.setErrSignupMessage({
        message: "Name should not more than 32 characters.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (specials.test(signUpData.name)) {
      this.props.setErrSignupMessage({
        message: "Name should not contain special characters.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (myRegEx.test(signUpData.name)) {
      this.props.setErrSignupMessage({
        message: "Name must contain alphabets.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (!signUpData.email.length) {
      this.props.setErrSignupMessage({
        message: "Email field is required.",
        color: "teal",
      });
      this.setState({ errClass: "email" });
    } else if (!regex.test(signUpData.email)) {
      this.props.setErrSignupMessage({
        message: "Enter a valid Email Address.",
        color: "teal",
      });
      this.setState({ errClass: "email" });
    } else if (signUpData.password.length < 8) {
      this.props.setErrSignupMessage({
        message: "Password must contain 8 characters",
        color: "teal",
      });
      this.setState({ errClass: "password" });
    } else if (signUpData.password.search(/[a-z]/i) < 0) {
      this.props.setErrSignupMessage({
        message: "Password must contain at least one letter.",
        color: "teal",
      });
    } else if (signUpData.password.search(/[0-9]/) < 0) {
      this.props.setErrSignupMessage({
        message: "Password must contain at least one digit.",
        color: "teal",
      });
    } else if (
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(signUpData.password)
    ) {
      this.props.setErrSignupMessage({
        message: "Password must contain at least one special character.",
        color: "teal",
      });
    } else if (signUpData.password !== signUpData.c_password) {
      this.props.setErrSignupMessage({
        message: "Password and Confirm password should be same",
        color: "teal",
      });
      this.setState({ errClass: "password" });
    } else if (signUpData.timezone == "") {
      this.props.setErrSignupMessage({
        message: "Please select the timezone!!",
        color: "teal",
      });
    } else {
      this.props.register({ ...signUpData, history: this.props.history });
    }
    setTimeout(() => {
      this.setState({ errClass: "" });
      this.props.setErrSignupMessage({ message: "", color: "" });
    }, 5000);
  }

  render() {
    const {
      errSignupMessage,
      signUpSpinnerStatus,
      signUpData,
    } = this.props.Signup;
    let { errClass } = this.state;
    const { authModal } = this.props.ListingState;
    const { errLoginMessage } = this.props.auth;
    return (
      <Fragment>
          <div className="md:flex md:select-none justify-center items-end">
            <div
              className={
                authModal === "signup"
                  ? "login_form bg-white p-4 text-center"
                  : "login_form md:w-1/2 bg-white p-4 text-center"
              }
            >
              {errSignupMessage.message ? (
                <AlertBox
                  AlertText={errSignupMessage.message}
                  color={errSignupMessage.color}
                />
              ) : null}
              {errLoginMessage.message ? (
                <AlertBox
                  AlertText={errLoginMessage.message}
                  color={errLoginMessage.color}
                />
              ) : null}
              {authModal === "OTP" ? (
                <AuthOTPModal
                  cancelEvent={() => this.props.setAuthModal("")}
                  history={this.props.history}
                />
              ) : null}
              <div className="site__logo w-24 m-auto">
                <Link to="/">
                  <img
                    className="w-full"
                    src="images/soberlistic_small_logo.png"
                    alt="Site Logo"
                  />
                  <span>Soberlistic</span>
                </Link>
              </div>
              <div className="main_forms">
                <form className="login_form" onSubmit={this.submitHandler}>
                  <div className="form_title font-bold">
                    <h3>Sign Up</h3>
                  </div>
                  <div className="form-item">
                    <label>Name</label>
                    <input
                      className={errClass == "name" ? "border-red-500" : ""}
                      type="text"
                      name="name"
                      value={signUpData.name}
                      onChange={this.handlechange}
                    />
                  </div>
                  <div className="form-item">
                    <label>Email Address</label>
                    <input
                      className={errClass == "email" ? "border-red-500" : ""}
                      type="text"
                      name="email"
                      value={signUpData.email}
                      onChange={this.handlechange}
                    />
                  </div>
                  <div className="form-item">
                    <label>Password</label>
                    <input
                      className={errClass == "password" ? "border-red-500" : ""}
                      type="password"
                      name="password"
                      value={signUpData.password}
                      onChange={this.handlechange}
                    />
                  </div>
                  <div className="form-item">
                    <label>Confirm Password</label>
                    <input
                      type="password"
                      name="c_password"
                      value={signUpData.c_password}
                      onChange={this.handlechange}
                    />
                  </div>
                  <div className="form-item">
                    <label>Time Zone</label>

                    {/* --------------country code------------ */}
                    {/* <select
                        name="timezone"
                        onChange={this.handlechange}
                        value={signUpData.timezone}
                        className='timezone-select'
                      >
                        <option>Select</option>
                        {ZoneList.map((item,i) => (
                          <option key={i} value={item.value}>
                            {item.label}
                          </option>
                        ))}
                      </select> */}
                    <Select
                      name={"timezone"}
                      className="new_select"
                      options={ZoneList}
                      value={ZoneList.filter((option) => {
                        return option.value === signUpData.timezone;
                      })}
                      onChange={this.handleSelect}
                      searchable={true}
                    />
                    {/* -------------------------------------- */}
                  </div>
                  <div className="form-actions">
                    <button type="submit">
                      {signUpSpinnerStatus ? <LoadingSpinner /> : "Submit"}
                    </button>
                  </div>
                  {authModal !== "signup" ? (
                    <div className="forget_pwd">
                      <p>
                        Already have a account{" "}
                        <Link className="text_nav_blue" to="/login">
                          Login!
                        </Link>
                      </p>
                    </div>
                  ) : null}
                </form>
              </div>
            </div>
            {authModal !== "signup" ? (
              <div className="welcome_note text-white text-center md:mb-8 md:w-1/2 p-6 md:px-8 lg:px-16 md:pb-5">
                <div className="form_text--title">
                  <h3>Heading</h3>
                </div>
                <div className="login__text">
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </p>
                  <p>
                    Quis ipsum suspendisse ultrices gravida. Risus commodo
                    viverra maecenas accumsan lacus vel facilisis. ommodo
                    viverra maecenas accumsan lacus vel facilisis. ommodo
                    viverra maecenas
                  </p>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
                  </p>
                  <p>
                    Quis ipsum suspendisse ultrices gravida. Risus commodo
                    viverra maecenas accumsan lacus vel facilisis. Quis ipsum suspendisse ultrices gravida.
                  </p>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                    do eiusmod.
                  </p>
                </div>
                <div className="btn login_text--btn">
                  <Link to="">Button</Link>
                </div>
              </div>
            ) : null}
          </div>
      </Fragment>
    );
  }
}

// SignupView.propTypes = {
//   history: PropTypes.object.isRequired,
//   register: PropTypes.func.isRequired,
//   Signup: PropTypes.object.isRequired,
//   setErrSignupMessage: PropTypes.func.isRequired,
// };

export default SignupView;
