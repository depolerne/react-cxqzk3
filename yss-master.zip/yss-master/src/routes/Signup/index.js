import Signup from './containers/SignupContainer';
export { Signup };
export * from './modules/Signup';

export default Signup;
