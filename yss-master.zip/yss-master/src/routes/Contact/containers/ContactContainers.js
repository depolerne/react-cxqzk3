import { actions } from "../modules/ContactUs";
import { withJob } from "react-jobs";
import { bindActionCreators } from "redux";
import ContactView from "../components/ContactView";
import { connect } from "react-redux";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),  
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ContactUsState: state.ContactUsState
});

export default connect(mapStateToProps, mapDispatchToProps)(ContactView);
