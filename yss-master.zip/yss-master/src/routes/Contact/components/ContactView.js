import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import { actions } from "../modules/ContactUs";
import { connect } from "react-redux";
import AlertBox from "../../../components/AlertBox/AlertBox";

export class ContactView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.submitHandler = this.submitHandler.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "contact_page";
  }

  handleChange(event) {
    const name = event.target.name;
    const value = event.target.value;
    let { setContactUsData } = this.props.ContactUsState;
    setContactUsData[name] = value;
    this.props.setContactUsData(setContactUsData);
  }

  submitHandler(event) {
    event.preventDefault();
    let { setContactUsData } = this.props.ContactUsState;
    
    if (!setContactUsData.name.length) {
      this.props.setAlertMessage({
        message: "Name can't be empty",
        color: "teal",
      });
    }else if (!setContactUsData.email.length) {
      this.props.setAlertMessage({
        message: "Email can't be empty",
        color: "teal",
      });
    }else if (!setContactUsData.subject.length) {
      this.props.setAlertMessage({
        message: "Subject can't be empty",
        color: "teal",
      });
    }else if (!setContactUsData.message.length) {
      this.props.setAlertMessage({
        message: "Message can't be empty",
        color: "teal",
      });
    }else{
      this.props.sendContactUsFormData({ ...setContactUsData, history: this.props.history });
    }

    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
      this.setState({ errorClass: "" });
    }, 3000);
  }

  render() {
    return (
      <Fragment>
      {this.props.selectState.alertMessage.message && 
              <AlertBox
                AlertText={this.props.selectState.alertMessage.message}
                color={this.props.selectState.alertMessage.color}
              />
      }
      <div className="main-content yss-site--main__content content__homepage">
        <div className="main-site__content">
          <div className="site__top-banner md:flex md:flex-wrap w-full relative items-center"
          style={{
            backgroundImage: 'url(/images/new_yss/home-banner-bg.jpg)',
          }}>
            <div className="banner__contents relative z-20 w-11/12 mx-auto md:w-2/3">
              <div className="section__title banner__title mb-6">
                <h1 className="text-white">Contact Us</h1>
              </div>
              <div className="site__text">
                <p>Online coaching for mental health, fitness, nutrition, addiction & much more…</p> 
                <p>All online, via your webcam, in soberlistic.</p>
              </div>
              <div className="btn banner__btn site__btn">
                <a className="btn-blue" href="/find-your-coach">
                  Search Now
                </a>
              </div>
            </div>
          </div>   

          <div className="section--wrapper wrapper--2column-section">
            <div className="section--width">
              <div className="section--content lg:flex lg:items-start lg:justify-between">
                <div className="w-full mb-10 flex items-start lg:w-1/2 lg:pr-3 lg:mb-0">
                  <div className="pr-3 address__details">
                    <div className="addrTitle">WELLNESS TECH LTD</div>
                    <p className="location__address">
                      <svg enable-background="new 0 0 48 48" height="48px" version="1.1" viewBox="0 0 48 48" width="48px" xmlns="http://www.w3.org/2000/svg"><g id="Expanded"><g><g><path d="M24,47.759l-0.823-1.191C22.558,45.671,8,24.499,8,16C8,7.178,15.178,0,24,0s16,7.178,16,16     c0,8.499-14.558,29.671-15.177,30.568L24,47.759z M24,2c-7.72,0-14,6.28-14,14c0,6.787,10.885,23.555,14,28.214     C27.115,39.555,38,22.787,38,16C38,8.28,31.72,2,24,2z"/></g><g><path d="M24,23c-3.859,0-7-3.14-7-7s3.141-7,7-7s7,3.14,7,7S27.859,23,24,23z M24,11c-2.757,0-5,2.243-5,5s2.243,5,5,5     s5-2.243,5-5S26.757,11,24,11z"/></g></g></g></svg> 
                      <span className="ml-3">Flat 20, Manor Glade Court, Higher Warberry Road, Torquay, Devon, United Kingdom, TQ1 1SL</span>
                    </p>
                    <p>
                      <svg id="Layer_1" enable-background="new 0 0 512.021 512.021" height="512" viewBox="0 0 512.021 512.021" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m367.988 512.021c-16.528 0-32.916-2.922-48.941-8.744-70.598-25.646-136.128-67.416-189.508-120.795s-95.15-118.91-120.795-189.508c-8.241-22.688-10.673-46.108-7.226-69.612 3.229-22.016 11.757-43.389 24.663-61.809 12.963-18.501 30.245-33.889 49.977-44.5 21.042-11.315 44.009-17.053 68.265-17.053 7.544 0 14.064 5.271 15.645 12.647l25.114 117.199c1.137 5.307-.494 10.829-4.331 14.667l-42.913 42.912c40.482 80.486 106.17 146.174 186.656 186.656l42.912-42.913c3.838-3.837 9.361-5.466 14.667-4.331l117.199 25.114c7.377 1.581 12.647 8.101 12.647 15.645 0 24.256-5.738 47.224-17.054 68.266-10.611 19.732-25.999 37.014-44.5 49.977-18.419 12.906-39.792 21.434-61.809 24.663-6.899 1.013-13.797 1.518-20.668 1.519zm-236.349-479.321c-31.995 3.532-60.393 20.302-79.251 47.217-21.206 30.265-26.151 67.49-13.567 102.132 49.304 135.726 155.425 241.847 291.151 291.151 34.641 12.584 71.866 7.64 102.132-13.567 26.915-18.858 43.685-47.256 47.217-79.251l-95.341-20.43-44.816 44.816c-4.769 4.769-12.015 6.036-18.117 3.168-95.19-44.72-172.242-121.772-216.962-216.962-2.867-6.103-1.601-13.349 3.168-18.117l44.816-44.816z"/></g></svg>
                      <span className="ml-3">+1 234 567 890</span>
                    </p>
                    <p>
                      <svg enable-background="new 0 0 64 64" height="64px" id="Icons" version="1.1" viewBox="0 0 64 64" width="64px" xmlns="http://www.w3.org/2000/svg"><g id="emailer_2_"><rect fill="#37474F" height="1" width="14" x="28" y="15"/><rect fill="#37474F" height="1" width="20" x="28" y="19"/><rect fill="#37474F" height="1" width="32" x="16" y="31"/><rect fill="#37474F" height="1" width="32" x="16" y="27"/><rect fill="#37474F" height="1" width="32" x="16" y="23"/><rect fill="#37474F" height="1" width="14" x="28" y="11"/><path d="M54,23.61V16L43,5H10v18.74L5,28v8.891V59h54V39.05V28L54,23.61z M44,7.414L51.586,15H44V7.414z M7.811,58   l22.495-18.33c0.435-0.354,1.052-0.557,1.694-0.557s1.26,0.203,1.694,0.557L56.189,58H7.811z M58,28.556L37.319,40.045l0.835,0.68   L58,29.699v9.342v19.145L34.326,38.895c-0.64-0.521-1.482-0.781-2.326-0.781s-1.687,0.261-2.326,0.781L6,58.186V36.864v-7.165   l19.846,11.025l0.834-0.68L6,28.556v-0.094l4-3.407v4.724l1,0.556V6h31.586H43v10h10v14.333l1-0.556v-4.723l4,3.407V28.556z" fill="#37474F"/><path d="M25,11h-9v9h9V11z M24,19h-7v-7h7V19z" fill="#37474F"/></g></svg>
                      <span className="ml-3">anymail@mail.com</span>
                    </p>
                    <p>
                      <svg id="Capa_1" enable-background="new 0 0 443.294 443.294" height="512" viewBox="0 0 443.294 443.294" width="512" xmlns="http://www.w3.org/2000/svg" fill="#34558b"><path d="m221.647 0c-122.214 0-221.647 99.433-221.647 221.647s99.433 221.647 221.647 221.647 221.647-99.433 221.647-221.647-99.433-221.647-221.647-221.647zm0 415.588c-106.941 0-193.941-87-193.941-193.941s87-193.941 193.941-193.941 193.941 87 193.941 193.941-87 193.941-193.941 193.941z"/><path d="m235.5 83.118h-27.706v144.265l87.176 87.176 19.589-19.589-79.059-79.059z"/></svg>
                      <span className="ml-3">09.00 - 17.00</span>
                    </p>
                  </div>
                  {/* <div className="w-1/2 pl-3 address__details">
                    <div className="addrTitle">Kansas</div>
                    <p>
                      <svg enable-background="new 0 0 48 48" height="48px" version="1.1" viewBox="0 0 48 48" width="48px" xmlns="http://www.w3.org/2000/svg"><g id="Expanded"><g><g><path d="M24,47.759l-0.823-1.191C22.558,45.671,8,24.499,8,16C8,7.178,15.178,0,24,0s16,7.178,16,16     c0,8.499-14.558,29.671-15.177,30.568L24,47.759z M24,2c-7.72,0-14,6.28-14,14c0,6.787,10.885,23.555,14,28.214     C27.115,39.555,38,22.787,38,16C38,8.28,31.72,2,24,2z"/></g><g><path d="M24,23c-3.859,0-7-3.14-7-7s3.141-7,7-7s7,3.14,7,7S27.859,23,24,23z M24,11c-2.757,0-5,2.243-5,5s2.243,5,5,5     s5-2.243,5-5S26.757,11,24,11z"/></g></g></g></svg> 
                      <span className="ml-3">732 Despard St, Atlanta</span>
                    </p>
                    <p>
                      <svg id="Layer_1" enable-background="new 0 0 512.021 512.021" height="512" viewBox="0 0 512.021 512.021" width="512" xmlns="http://www.w3.org/2000/svg"><g><path d="m367.988 512.021c-16.528 0-32.916-2.922-48.941-8.744-70.598-25.646-136.128-67.416-189.508-120.795s-95.15-118.91-120.795-189.508c-8.241-22.688-10.673-46.108-7.226-69.612 3.229-22.016 11.757-43.389 24.663-61.809 12.963-18.501 30.245-33.889 49.977-44.5 21.042-11.315 44.009-17.053 68.265-17.053 7.544 0 14.064 5.271 15.645 12.647l25.114 117.199c1.137 5.307-.494 10.829-4.331 14.667l-42.913 42.912c40.482 80.486 106.17 146.174 186.656 186.656l42.912-42.913c3.838-3.837 9.361-5.466 14.667-4.331l117.199 25.114c7.377 1.581 12.647 8.101 12.647 15.645 0 24.256-5.738 47.224-17.054 68.266-10.611 19.732-25.999 37.014-44.5 49.977-18.419 12.906-39.792 21.434-61.809 24.663-6.899 1.013-13.797 1.518-20.668 1.519zm-236.349-479.321c-31.995 3.532-60.393 20.302-79.251 47.217-21.206 30.265-26.151 67.49-13.567 102.132 49.304 135.726 155.425 241.847 291.151 291.151 34.641 12.584 71.866 7.64 102.132-13.567 26.915-18.858 43.685-47.256 47.217-79.251l-95.341-20.43-44.816 44.816c-4.769 4.769-12.015 6.036-18.117 3.168-95.19-44.72-172.242-121.772-216.962-216.962-2.867-6.103-1.601-13.349 3.168-18.117l44.816-44.816z"/></g></svg>
                      <span className="ml-3">+1 234 567 890</span>
                    </p>
                    <p>
                      <svg enable-background="new 0 0 64 64" height="64px" id="Icons" version="1.1" viewBox="0 0 64 64" width="64px" xmlns="http://www.w3.org/2000/svg"><g id="emailer_2_"><rect fill="#37474F" height="1" width="14" x="28" y="15"/><rect fill="#37474F" height="1" width="20" x="28" y="19"/><rect fill="#37474F" height="1" width="32" x="16" y="31"/><rect fill="#37474F" height="1" width="32" x="16" y="27"/><rect fill="#37474F" height="1" width="32" x="16" y="23"/><rect fill="#37474F" height="1" width="14" x="28" y="11"/><path d="M54,23.61V16L43,5H10v18.74L5,28v8.891V59h54V39.05V28L54,23.61z M44,7.414L51.586,15H44V7.414z M7.811,58   l22.495-18.33c0.435-0.354,1.052-0.557,1.694-0.557s1.26,0.203,1.694,0.557L56.189,58H7.811z M58,28.556L37.319,40.045l0.835,0.68   L58,29.699v9.342v19.145L34.326,38.895c-0.64-0.521-1.482-0.781-2.326-0.781s-1.687,0.261-2.326,0.781L6,58.186V36.864v-7.165   l19.846,11.025l0.834-0.68L6,28.556v-0.094l4-3.407v4.724l1,0.556V6h31.586H43v10h10v14.333l1-0.556v-4.723l4,3.407V28.556z" fill="#37474F"/><path d="M25,11h-9v9h9V11z M24,19h-7v-7h7V19z" fill="#37474F"/></g></svg>
                      <span className="ml-3">anymail@mail.com</span>
                    </p>
                    <p>
                      <svg id="Capa_1" enable-background="new 0 0 443.294 443.294" height="512" viewBox="0 0 443.294 443.294" width="512" xmlns="http://www.w3.org/2000/svg" fill="#34558b"><path d="m221.647 0c-122.214 0-221.647 99.433-221.647 221.647s99.433 221.647 221.647 221.647 221.647-99.433 221.647-221.647-99.433-221.647-221.647-221.647zm0 415.588c-106.941 0-193.941-87-193.941-193.941s87-193.941 193.941-193.941 193.941 87 193.941 193.941-87 193.941-193.941 193.941z"/><path d="m235.5 83.118h-27.706v144.265l87.176 87.176 19.589-19.589-79.059-79.059z"/></svg>
                      <span className="ml-3">09.00 - 17.00</span>
                    </p>
                  </div> */}
                </div>
                <div className="w-full lg:w-1/2 lg:pl-3">
                  <div className="bg-white section--bg-style">
                    <form className="contact__form" onSubmit={this.submitHandler}>
                      <div className="form-item">
                        <input type="text" name="name" placeholder="Name" onChange={this.handleChange} value={this.props.ContactUsState.setContactUsData.name} />
                      </div>
                      <div className="form-item">
                        <input type="email" name="email" placeholder="Email Address" onChange={this.handleChange}  value={this.props.ContactUsState.setContactUsData.email} />
                      </div>
                      <div className="form-item">
                        <input type="text" name="subject" placeholder="Subject" onChange={this.handleChange} value={this.props.ContactUsState.setContactUsData.subject} />
                      </div>
                      <div className="form-item">
                        <textarea name="message" placeholder="Your Message" onChange={this.handleChange} value={this.props.ContactUsState.setContactUsData.message}>
                          
                        </textarea>
                      </div>
                      <div className="form-actions">
                        <button type="submit">Send Message</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>  
          </div> 

        </div>
      </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ContactUsState: state.ContactUsState,
});

export default connect(mapStateToProps, actions)(ContactView);
