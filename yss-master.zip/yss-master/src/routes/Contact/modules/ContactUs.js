//import { setAuthModal } from "../../CListing/modules/CListing";
import { setAlertMessage } from "../../selectWrapper/modules/select";
//---> Defining types for different actions

export const SET_CONTACT_US_DATA = "SET_CONTACT_US_DATA";
export const SET_SUBMIT_FORM_LOADING_SPINNER='SET_SUBMIT_FORM_LOADING_SPINNER';
//---> Defining Actions to set state variables

export function setContactUsData(params) {
  return {
    type: SET_CONTACT_US_DATA,
    payload: params,
  };
}

export const submitFormSpinner=(flag)=>{
  return {
    type:SET_SUBMIT_FORM_LOADING_SPINNER,
    payload:flag
  }
}

export const sendContactUsFormData = (data) => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(submitFormSpinner(true));
    
    try {
      let result = await fetch(
        `${__API__}/contact-us`,
        {
          method: "POST",
          cache: "no-cache",
          body: JSON.stringify(data),
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();

      if (!response.success) {
        Object.keys(response.errors).map(item=>{
          dispatch(setAlertMessage({message: response.errors[item][0],color: "teal"}))
        })
        await dispatch(submitFormSpinner(false));
      } else if (response.success) {
            // await ;
             dispatch(
                  setContactUsData({
                    name: "",
                    subject: "",
                    message: "",
                    email: "",
                  })
                );
        
        await dispatch(
          setAlertMessage({
            message: "Thank you for contacting us. We will get back to you soon.",
            color: "green",
          })
        );
        await dispatch(submitFormSpinner(false));
      }
    } catch (e) {
      dispatch(
        setAlertMessage({ message: "Something went wrong", color: "teal" })
      );
      await dispatch(submitFormSpinner(false));
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};


export const actions = {
  setContactUsData,
  setAlertMessage,
  submitFormSpinner,
  sendContactUsFormData
};

//---> defining the initialState for state variables

const initialState = {
  setContactUsData: {
    name:"",
    subject:"",
    email:"",
    message:""
  }
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_CONTACT_US_DATA]: (state, action) => {
    return {
      ...state,
      setContactUsData: action.payload,
    };
  }
};



export default function ContactUsReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
