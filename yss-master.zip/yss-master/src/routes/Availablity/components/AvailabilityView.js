import React, { Fragment } from "react";
import $ from "jquery";
import HourRow from "../../../components/HourRow/HourRow";
import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import Spinner from "../../../components/Spinner/Spinner";
import Select from "react-select";
let tempDay = {};
var timeValidate = true;

const TimeBreak = [
    {value:'0',label:'No Break Time'},
    {value:'10',label:'10'},
    {value:'15',label:'15'},
    {value:'20',label:'20'},
];

export class AvailabilitytView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      timings: {
        monday: [],
        tuesday: [],
        wednesday: [],
        thursday: [],
        friday: [],
        saturday: [],
        sunday: [],
      },
      hourRows: [],
      _id: 1,
      loadingSpinner: false,
      errMsg: { message: "", color: "" },
      timeValidate: true,
      breaks:10
    };
    this.handleChange = this.handleChange.bind(this);
    this.addHourRow = this.addHourRow.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.isCheck = this.isCheck.bind(this);
    this.handleSelect=this.handleSelect.bind(this);
  }

  componentDidMount() {
    this.props.setMenuHover('avail')
    var currentThis = this;
    let body=document.body;
    body.className="dashboard_avail"; 
    // --------------------------------------------

    function modify_time(start_time, end_time) {
      var startTime = new Date();
      var parts = start_time.match(/(\d+):(\d+) (AM|PM)/);
      if (parts) {
        var hours = parseInt(parts[1]),
          minutes = parseInt(parts[2]),
          tt = parts[3];
        if (tt === "PM" && hours < 12) hours += 12;
        startTime.setHours(hours, minutes, 0, 0);
        if (tt === "AM" && hours == 12) hours -= 12;
        startTime.setHours(hours, minutes, 0, 0);
      }
      var endTime = new Date();
      parts = end_time.match(/(\d+):(\d+) (AM|PM)/);
      if (parts) {
        var hours = parseInt(parts[1]),
          minutes = parseInt(parts[2]),
          tt = parts[3];
        if (tt === "PM" && hours < 12) hours += 12;
        endTime.setHours(hours, minutes, 0, 0);
        if (tt === "AM" && hours == 12) hours += 12;
        endTime.setHours(hours, minutes, 0, 0);
      }
      if (startTime >= endTime) {
        timeValidate = false;
        return false;
      }
      timeValidate = true;
      return true;
    }

    $("body").on("change", ".first_slot select", function () {
      debugger
      var currentValue = $(this).val();
      var parallelValue = $(this)
        .parent()
        .parent()
        .find(".second_slot.slots select")
        .val();

      if (currentValue !== "-1" && parallelValue !== "-1") {
        var response = modify_time(currentValue, parallelValue);
        if (!response) {
          $(this).parent().addClass("error_slots");
          currentThis.props.setAlertMessage({
            message: "Please select a valid time",
            color: "teal",
          });
          setTimeout(() => {
            currentThis.props.setAlertMessage({ message: "", color: "" });
          }, 3000);

          $(this).val("-1");
        } else {
          $(this).parent().removeClass("error_slots");
        }
      }

      var index = $(this).parent().parent().parent().index();
      var length = $(this).parent().parent().parent().parent().children()
        .length;
      var parent = $(this).parent().parent().parent().parent();
      if (length > 1 && index > 0) {
        var compareIndex = index - 1;
        var diagonalValue = $(this)
          .parent()
          .parent()
          .parent()
          .parent()
          .children()
          .eq(compareIndex)
          .find(".second_slot select")
          .val();
        if (currentValue !== "-1" && diagonalValue !== "-1") {
          var response = modify_time(diagonalValue, currentValue);
          if (!response) {
            $(this).parent().addClass("error_slots");
            currentThis.props.setAlertMessage({
              message: "Please select a valid time",
              color: "teal",
            });
            setTimeout(() => {
              currentThis.props.setAlertMessage({ message: "", color: "" });
            }, 3000);

            $(this).val("-1");
          } else {
            $(this).parent().removeClass("error_slots");
          }
        }
      }

    });

    $("body").on("change", ".second_slot select", function () {
      var currentValue = $(this).val();
      var parallelValue = $(this)
        .parent()
        .parent()
        .find(".first_slot.slots select")
        .val();
      if (parallelValue !== "-1" && currentValue !== "-1") {
        var response = modify_time(parallelValue, currentValue);
        if (!response) {
          $(this).parent().addClass("error_slots");
          currentThis.props.setAlertMessage({
            message: "Please select a valid time",
            color: "teal",
          });
          setTimeout(() => {
            currentThis.props.setAlertMessage({ message: "", color: "" });
          }, 3000);
          // alert("Please select a valid time");
          $(this).val("-1");
        } else {
          $(this).parent().removeClass("error_slots");
        }
      }

      var index = $(this).parent().parent().parent().index();
      var length = $(this).parent().parent().parent().parent().children()
        .length;
      var parent = $(this).parent().parent().parent().parent();
      if (length > 1 && length !== index + 1) {
        var compareIndex = index + 1;
        var diagonalValue = $(this)
          .parent()
          .parent()
          .parent()
          .parent()
          .children()
          .eq(compareIndex)
          .find(".first_slot select")
          .val();
        if (diagonalValue !== "-1" && currentValue !== "-1") {
          var response = modify_time(currentValue, diagonalValue);
          if (!response) {
            $(this).parent().addClass("error_slots");
            currentThis.props.setAlertMessage({
              message: "Please select a valid time",
              color: "teal",
            });
            setTimeout(() => {
              currentThis.props.setAlertMessage({ message: "", color: "" });
            }, 3000);
            // alert("Please select a valid time");
            $(this).val("-1");
          } else {
            $(this).parent().removeClass("error_slots");
          }
        }
      }
    });

    // -----------------------------------------
    $("body").on("change", "#chakboxAll", function () {
      $("input[type=checkbox]").prop("checked", $(this).prop("checked"));
      if ($(this).is(":checked")) {
        $(this).parent().parent().parent().parent().addClass("selectedAll");

        $('input[type="checkbox"]').each(function () {
          if ($(this).attr("name") != "all") {
            if (
              $(this).parent().parent().parent().find(".time_slots .first_slot")
                .length == 0
            ) {
              currentThis.addHourRow($(this).attr("name"));
            }
          }
        });

        $(".form-field").addClass("selected");
      } else {
        $(this).parent().parent().parent().parent().removeClass("selectedAll");
        $(".form-field").removeClass("selected");
      }
    });

    $("body").on("change", ".day_detail input", function () {
      var cheeckCheckedCheckbox = 0;
      $('input[type="checkbox"]').each(function () {
        if ($(this).attr("name") != "all") {
          if ($(this).prop("checked") == true) {
            cheeckCheckedCheckbox = cheeckCheckedCheckbox + 1;
          }
        }
      });

      if (cheeckCheckedCheckbox == 7) {
        $("#chakboxAll").prop("checked", true);
      } else {
        $("#chakboxAll").prop("checked", false);
      }

      if ($(this).is(":checked")) {
        if (
          $(this).parent().parent().parent().find(".time_slots .first_slot")
            .length == 0
        ) {
          currentThis.addHourRow($(this).attr("name"));
        }
        $(this).parent().parent().parent().addClass("selected");
      } else {
        $(this).parent().parent().parent().removeClass("selected");
      }
    });
    setTimeout(() => {
      currentThis.props.setAlertMessage({ message: "", color: "" });
    }, 3000);

    $(document).ready(function () {
      $("body").on("click", ".time_delete", function () {
        $(this).parent().remove();
      });

      $(".timings_update").click(function (e) {
        e.preventDefault();
        var submitForm = true;
        $("select > option:selected").each(function () {
          if ($(this).val() == -1) {
            if ($(this).parents().eq(5).hasClass("selected")) {
              submitForm = false;
              currentThis.props.setAlertMessage({
                message:
                  "Selected timings are not correct!!. Please check your selected timings",
                color: "teal",
              });
              return false;
            }
            setTimeout(() => {
              currentThis.props.setAlertMessage({ message: "", color: "" });
            }, 5000);
          }
        });

        if (submitForm) {
          currentThis.submitHandler();
        }
      });
    });

    this.getAvailabilityData();
  }

  handleSelect(selected, event) {
    this.setState({breaks: selected.value});
  }
  // ------------ handle change function for set availablity ----------
  async handleChange(event) {
    var id = event.target.className;
    let name = event.target.name;
    let value = event.target.value;
    let elementIdString = event.target.id.toString();
    let elementId;
    if (!elementId) {
      let splitArr = elementIdString.split("-");
      elementId = parseInt(splitArr[1]);
    }

    if (name === "open") {
      var day = id;
      if (Object.keys(this.state.timings).length == 0) {
        await this.setState({
          timings: {
            monday: [],
            tuesday: [],
            wednesday: [],
            thursday: [],
            friday: [],
            saturday: [],
            sunday: [],
          },
        });
      }
      day = this.state.timings[day];
      tempDay = Object.assign(tempDay, { id: elementId, open: value });
      if (day.length > 0) {
        let temp = [];
        for (let i of day) {
          temp.push(i.id);
        }
        if (temp.indexOf(elementId) === -1) {
          tempDay = Object.assign(tempDay, { id: elementId, open: value });
          day.push(tempDay);
          this.setState({ day: day });
          tempDay = {};
        }
        day.map((obj) => {
          if (obj.id === elementId) {
            if (tempDay.close == undefined) {
              tempDay = Object.assign(tempDay, {
                id: elementId,
                close: obj.close,
                open: value,
              });
            } else {
              tempDay = Object.assign(tempDay, { id: elementId, open: value });
            }
            const newDay = {
              ...tempDay,
              open: value,
            };
            const index = day.indexOf(obj);
            day[index] = newDay;
            tempDay = {};
          }
        });
      } else {
        tempDay = Object.assign(tempDay, { id: elementId, open: value });
        day.push(tempDay);
        this.setState({ day: day });
        tempDay = {};
      }
    } else if (name === "close") {
      var day = id;
      if (Object.keys(this.state.timings).length == 0) {
        await this.setState({
          timings: {
            monday: [],
            tuesday: [],
            wednesday: [],
            thursday: [],
            friday: [],
            saturday: [],
            sunday: [],
          },
        });
      }
      day = this.state.timings[day];

      // var minusDays = 1;
      // if(day.length > 1){
      //   minusDays = 2;
      // }

      // if (day[day.length - 1].open) {
      // debugger;
      // var response = this.modifyClose_time(day[day.length -1].open,value)
      // console.log(response,'response');
      // if (!response) {
      //   alert("Please select a valid time");
      //   document.getElementById(elementIdString).value = -1;
      //   return true;
      // }
      // }

      tempDay = Object.assign(tempDay, { id: elementId, close: value });
      if (day.length) {
        let temp = [];
        for (let i of day) {
          temp.push(i.id);
        }
        if (temp.indexOf(elementId) === -1) {
          tempDay = Object.assign(tempDay, { id: elementId, close: value });
          day.push(tempDay);
          this.setState({ day: day });
          tempDay = {};
        }
        day.map((obj) => {
          if (obj.id === elementId) {
            if (tempDay.open == undefined) {
              tempDay = Object.assign(tempDay, {
                id: elementId,
                open: obj.open,
                close: value,
              });
            } else {
              tempDay = Object.assign(tempDay, { id: elementId, close: value });
            }
            const newDay = {
              ...tempDay,
              close: value,
            };
            const index = day.indexOf(obj);
            day[index] = newDay;
            tempDay = {};
          }
        });

        } else {
        tempDay = Object.assign(tempDay, { id: this.state._id, close: value });
        day.push(tempDay);
        this.setState({ day: day });
        tempDay = {};
      }
    }
  }

  async isCheck(event) {
    var checked = event.target.checked;
    let dayname = event.target.name;
    if (checked == false) {
      if (dayname === "all") {
        await this.setState({
          hourRows: [],
          timings: {
            monday: [],
            tuesday: [],
            wednesday: [],
            thursday: [],
            friday: [],
            saturday: [],
            sunday: [],
          },
        });
      }
      let day = this.state.hourRows;
      let Hours = [];
      for (let i = 0; i < day.length; i++) {
        if (day[i].props.dayname !== dayname) {
          Hours.push(day[i]);
        }
      }
      //this.state.hourRows = Hours;
      this.state.timings[dayname] = [];
      await this.setState({
        hourRows: day,
      });
    }
    // else{
    //     this.state.timings[dayname]=[{"open":undefined}]
    //   }
  }

  // --------------Adding slots value to the array using addhours--------------
  addHourRow(dayname) {
    let day = this.state.hourRows;
    let randomId = Math.floor((Math.random() * 10000) + 1);
    day.push(
      <HourRow
        dayname={dayname}
        openid={`${dayname}Open-${randomId}`}
        closeid={`${dayname}Close-${randomId}`}
      />
    );
    this.setState({
      hourRows: day,
    });
    let day_id = this.state._id;
    this.setState({
      _id: day_id + 1,
    });
    // this.state.timings[dayname]=[{"open":undefined}]
  }

  //------------------removing perticular slots by id from above array---------------
  removeHourRow(dayname, id) {
    let day = this.state.timings[dayname];
    let day_id = this.state._id;
    let elementIdString = id.toString();
    let elementId = "";

    if (!elementId) {
      let splitArr = elementIdString.split("-");
      elementId = parseInt(splitArr[1]);
    }
    day.map((data) => {
      if (data.id === elementId) {
        var index = day.indexOf(data);
      }
      if (index > -1) {
        day.splice(index, 1);
      }
    });

    this.setState({
      day: day,
      _id: day_id - 1,
    });
  }

  // -------------------submit handler fuction for sending data in APIs------------------
  submitHandler() {
    //event.preventDefault();
    let { timings } = this.state;
    Object.keys(timings).map((key) => {
      // if (timings[key].length === 0) {
      //   timeValidate = false;
      // }
      for (let j = 0; j < timings[key].length; j++) {
        if (timings[key][j].close === "-1") {
          timeValidate = false;
        }
        if (timings[key][j].open === "-1") {
          timeValidate = false;
        }
        if (!timings[key][j].close) {
          timeValidate = false;
        }
        if (
          timings[key][j].close === undefined ||
          timings[key][j].open === undefined
        ) {
          timeValidate = false;
        }
      }
    });

    if (timeValidate) {
      this.props.saveAvailability({
        ...this.state,
        history: this.props.history,
      });
    } else if (!timeValidate) {
      this.props.setAlertMessage({
        message:
          "Selected timings are not correct!!. Please check your selected timings",
        color: "teal",
      });
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  // -------------------getAvailability handler fuction for get data in APIs------------------
  getAvailabilityData() {
    const token = auth.getAccessToken();
    this.setState({ loadingSpinner: true });
    fetch(`${__API__}/get/availability`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        Accept: "application/json",
        Authorization: `Bearer ` + token,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          this.setState({breaks:data.breaks})
          var obj = data.data;

          $.each(obj, function (k, v) {
            if (v.length !== 0) {
              $("." + k).prop("checked", true);
              $("." + k)
                .parent()
                .parent()
                .parent()
                .addClass("selected");
            }

            var cheeckCheckedCheckbox = 0;
            $('input[type="checkbox"]').each(function () {
              if ($(this).attr("name") != "all") {
                if ($(this).prop("checked") == true) {
                  cheeckCheckedCheckbox = cheeckCheckedCheckbox + 1;
                }
              }
            });

            if (cheeckCheckedCheckbox == 7) {
              $("#chakboxAll").prop("checked", true);
            } else {
              $("#chakboxAll").prop("checked", false);
            }
          });

          this.setState({
            timings: obj,
            loadingSpinner: false,
          });

          let {
            monday,
            tuesday,
            wednesday,
            thursday,
            friday,
            saturday,
            sunday,
          } = obj; //... populate day hours states
          let day = this.state.hourRows;
          //...............monday..................//
          if (monday) {
            monday.length
              ? monday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="monday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`mondayOpen-${item.id}`}
                      closeid={`mondayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="monday"
                    handleChange={this.handleChange}
                    openid={`mondayOpen-${this.state._id}`}
                    closeid={`mondayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }
          //...........Tuesday.....................//'Update'
          if (tuesday) {
            tuesday.length
              ? tuesday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="tuesday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`tuesdayOpen-${item.id}`}
                      closeid={`tuesdayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="tuesday"
                    handleChange={this.handleChange}
                    openid={`tuesdayOpen-${this.state._id}`}
                    closeid={`tuesdayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }

          //...........Wednesday......................//
          if (wednesday) {
            wednesday.length
              ? wednesday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="wednesday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`wednesdayOpen-${item.id}`}
                      closeid={`wednesdayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="wednesday"
                    handleChange={this.handleChange}
                    openid={`wednesdayOpen-${this.state._id}`}
                    closeid={`wednesdayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }

          //................thursday.............//
          if (thursday) {
            thursday.length
              ? thursday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="thursday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`thursdayOpen-${item.id}`}
                      closeid={`thursdayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="thursday"
                    handleChange={this.handleChange}
                    openid={`thursdayOpen-${this.state._id}`}
                    closeid={`thursdayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }

          //................friday.............//
          if (friday) {
            friday.length
              ? friday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="friday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`fridayOpen-${item.id}`}
                      closeid={`fridayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="friday"
                    handleChange={this.handleChange}
                    openid={`fridayOpen-${this.state._id}`}
                    closeid={`fridayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }

          //................saturday.............//
          if (saturday) {
            saturday.length
              ? saturday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="saturday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`saturdayOpen-${item.id}`}
                      closeid={`saturdayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="saturday"
                    handleChange={this.handleChange}
                    openid={`saturdayOpen-${this.state._id}`}
                    closeid={`saturdayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }

          //................sunday.............//
          if (sunday) {
            sunday.length
              ? sunday.map((item) => {
                  day.push(
                    <HourRow
                      dayname="sunday"
                      key={item.id}
                      handleChange={this.handleChange}
                      openid={`sundayOpen-${item.id}`}
                      closeid={`sundayClose-${item.id}`}
                      from={item.open}
                      to={item.close}
                    />
                  );
                  this.setState({
                    _id: item.id,
                  });
                })
              : day.push(
                  <HourRow
                    dayname="sunday"
                    handleChange={this.handleChange}
                    openid={`sundayOpen-${this.state._id}`}
                    closeid={`sundayClose-${this.state._id}`}
                  />
                );
            this.setState({
              _id: this.state._id + 1,
            });
          }
          this.setState({
            hourRows: day,
          });
        }
      });
  }

  render() {
    const { spinnerStatus } = this.props.AvailabilityState;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  <span>Availability</span>
                </h3>
              </div>
              {/* {this.state.loadingSpinner ? <Spinner/> :  */}
              <div className="middle__content">
                <div className="app_new--section">
                  <form
                    className="availability_form"
                    id="form_timings"
                    onSubmit={this.submitHandler}
                  >

                    {/* ------------------------------------------------ */}
                    <div className="availability_fields">
                      {/*<div className="form-field all-fields">
                        {/* -----------Availability slots------------------- 
                        <div className="day_title">All Days</div>
                        <div className="day_detail">
                          <label>
                            <input
                              id="chakboxAll"
                              className="checkBoxClass"
                              type="checkbox"
                              name="all"
                              onChange={(e) => this.isCheck(e)}
                            />
                            Select All
                          </label>
                        </div>
                      </div>*/}
                      {/* -----------------------Monday Open---------------------- */}

                      <div className="form-field timebreak__options">
                        <div className="day_title">Select Break Time</div>
                        <div className="day_detail">
                            <Select
                                name={'timezone'}
                                className="new_select"
                                options={TimeBreak}
                                value={TimeBreak.filter((option) => {
                                  return option.value === this.state.breaks;
                                })}
                                onChange={this.handleSelect}
                                searchable={true}
                              />
                        </div>
                      </div>

                      <div className="form-field">
                        <div className="day_title">Monday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass monday"
                              name="monday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "monday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another">
                          <span onClick={() => this.addHourRow("monday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>

                      {/* -----------------------Tuesday Open---------------------- */}
                      <div className="form-field">
                        <div className="day_title">Tuesday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass tuesday"
                              name="tuesday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "tuesday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another tuesday-time">
                          <span onClick={() => this.addHourRow("tuesday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>
                      {/* -----------------------Wednesday Open---------------------- */}
                      <div className="form-field">
                        <div className="day_title">Wednesday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass wednesday"
                              name="wednesday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "wednesday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another">
                          <span onClick={() => this.addHourRow("wednesday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>
                      {/* -----------------------Thursday open---------------------- */}
                      <div className="form-field">
                        <div className="day_title">Thursday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass thursday"
                              name="thursday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "thursday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another">
                          <span onClick={() => this.addHourRow("thursday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>
                      {/* -----------------------Friday Open---------------------- */}

                      <div className="form-field">
                        <div className="day_title">Friday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass friday"
                              name="friday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "friday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another">
                          <span onClick={() => this.addHourRow("friday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>
                      {/* ------------------------------Saturday open---------------------------- */}
                      <div className="form-field">
                        <div className="day_title">Saturday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass saturday"
                              name="saturday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "saturday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another">
                          <span onClick={() => this.addHourRow("saturday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>
                      {/* ------------------------------Sunday Open---------------------------- */}
                      <div className="form-field">
                        <div className="day_title">Sunday</div>
                        <div className="day_detail">
                          <label>
                            <input
                              type="checkbox"
                              className="checkboxClass sunday"
                              name="sunday"
                              onChange={(e) => this.isCheck(e)}
                            />
                            <span className="open">Open</span>
                            <span className="close">Closed</span>
                          </label>
                        </div>
                        <div className="time_slots">
                          {this.state.hourRows.length
                            ? this.state.hourRows.map((item, i) => {
                                if (item.props.dayname === "sunday") {
                                  return (
                                    <span key={i}>
                                      <HourRow
                                        dayname={item.props.dayname}
                                        key={i}
                                        handleChange={this.handleChange}
                                        openid={item.props.openid}
                                        closeid={item.props.closeid}
                                        from={item.props.from}
                                        to={item.props.to}
                                      />
                                      <span
                                        className="time_delete"
                                        onClick={() =>
                                          this.removeHourRow(
                                            item.props.dayname,
                                            item.props.openid
                                          )
                                        }
                                      ></span>
                                    </span>
                                  );
                                }
                              })
                            : null}
                        </div>
                        <div className="add_another">
                          <span onClick={() => this.addHourRow("sunday")}>
                            Add Hours
                          </span>
                        </div>
                      </div>
                      <div className="update_btn btn mobile__update-button">
                        <button
                          style={{ cursor: "pointer" }}
                          className="btn-blue timings_update"
                          type="submit"
                        >
                          {spinnerStatus ? <LoadingSpinner /> : "Update"}
                        </button>
                      </div>
                    </div>
                    <div className="help__block">
                      <div className="page_title text-center">
                        <h1 className="text-xl">
                          <span className="text_nav_blue">Information</span>
                        </h1>
                      </div>
                      <div className="help__text">
                        <p>Contrary to popular belief Lorem Ipsum is not simply random.</p>
                        <p>It has roots a piece classical Latin</p>
                        <p>literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, literature from 45 BC, making it over 2000 years old. Richard McClintock</p>
                        <p>looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum.</p>
                        <p>passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32. Lorem Ipsum comes from sections 1.10.32. Lorem Ipsum comes from sections 1.10.32. Lorem Ipsum comes from sections 1.10.32. Lorem Ipsum comes from sections 1.10.32. Lorem Ipsum comes from sections 1.10.32.</p>
                        <p>literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, literature from 45 BC, making it over 2000 years old. Richard McClintock. A Latin professor at Hampden-Sydney College in Virginia, literature from 45 BC, making it over 2000 years old. Richard McClintock.</p>
                      </div>
                    </div>
                    <div className="update_btn btn desktop__update-button">
                      <button
                        style={{ cursor: "pointer" }}
                        className="btn-blue timings_update"
                        type="submit"
                      >
                        {spinnerStatus ? <LoadingSpinner /> : "Update"}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default AvailabilitytView;
