import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import { disable } from "debug";
import {setAlertMessage,setUserDataInState,setMenuHover} from '../../selectWrapper/modules/select';
//---> defining types for different Actions

export const SET_AVAILABILITY_DATA = "SET_AVAILABILITY_DATA";
export const SET_AVAILABILITY_ERR_MESSAGE = "SET_AVAILABILITY_ERR_MESSAGE";
export const SET_AVAILABILITY_SPINNER_STATUS =
  "SET_AVAILABILITY_SPINNER_STATUS";

//---> Defining Actions to set state variables

export const setSpinnerStatus = (status) => {
  return {
    type: SET_AVAILABILITY_SPINNER_STATUS,
    payload: status,
  };
};

// ---> API to Save updated availability Data into the Database

export function saveAvailability(data) {
  let timingData = JSON.stringify(data.timings);
  let breaks = data.breaks;
  return async (dispatch) => {
    await dispatch(setSpinnerStatus(true));
    const token = auth.getAccessToken();
    let availaible_days={availaible_days:timingData,breaks:breaks}
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/add-availability`,
          {
            method: "POST",
            body:JSON.stringify(availaible_days),
            headers: {
              "Content-Type": "application/json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          await dispatch(setSpinnerStatus(false));
          await dispatch(
            setAlertMessage({
              message: "an error! occured",
              color: "teal",
            })
          );
        } else if (response.success) {
          await dispatch(setSpinnerStatus(false));
          await dispatch(
            setAlertMessage({
              message: "Timing hours successfully updated.",
              color: "green",
            })
          );
        }
        await dispatch(setUserDataInState(response.user));
      } catch (e) {
        await dispatch(setSpinnerStatus(false));
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
      }
    } else {
      await dispatch(setSpinnerStatus(false));
    }
  };
}

//---> exporting multiple functions and actions

export const actions = {
  saveAvailability,
  setSpinnerStatus,
  setAlertMessage,
  setMenuHover
};

//---> defining the initialState for state variables

const initialState = {
  saveErrMessage: { message: "", color: "" },
  spinnerStatus: false,
  
};

//--->  setting the values to the state variables by actions dispatched 

const ACTION_HANDLERS = {
  // ADMIN_REDUCERS
  
  [SET_AVAILABILITY_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      spinnerStatus: action.payload,
    };
  },
};

export default function AvailabilityReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
