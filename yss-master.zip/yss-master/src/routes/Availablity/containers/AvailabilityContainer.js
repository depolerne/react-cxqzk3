import React from 'react';
import {
    actions,getAvailability
} from '../modules/Availability';

import { bindActionCreators } from 'redux';
import AvailabilityView from '../components/AvailabilityView';
import { connect } from 'react-redux';
import { withJob } from 'react-jobs';
import RedBox from 'redbox-react';

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});
const mapStateToProps = (state) => ({
    selectState: {
        isMobile: state.selectState.isMobile
    },
    AvailabilityState: state.AvailabilityState,
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => {
        // dispatch(getAvailability());
    },
    /* eslint-disable */ ErrorComponent: ({ error }) => __DEV__ ? <RedBox error={error} /> : null,
})(AvailabilityView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
