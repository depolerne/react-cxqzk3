import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import TechnicalSupportMessage from '../../../components/TechnicalSupportMessage/TechnicalSupportMessage';
import PropTypes from "prop-types";

export class ContactUsView extends React.PureComponent {
    constructor (props) {
        super(props);
        this.state = {
            hasError: false
        };
    }
    componentDidCatch () {
        this.setState({ hasError: true });
    }

    render () {
        const {
          accountInfo
        } = this.props.accountState;
        return (
                 <Fragment></Fragment>   );
    }
}

ContactUsView.propTypes = {
  accountState: PropTypes.object.isRequired,
};

export default ContactUsView;
