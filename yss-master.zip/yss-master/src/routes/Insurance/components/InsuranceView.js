import React, { Fragment } from "react";
import { actions } from "../modules/Insurance";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import Select from "react-select";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";

export class InsuranceView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleChange = this.handleChange.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
  }

  componentDidMount() {
    this.props.fetchCountries();
  }

  handleChange = (e) => {
    let { inData } = this.props.InsuranceState;
    let name = e.target.name;
    let value = e.target.value;
    inData[name] = value;
    this.props.setInsuranceData(inData);
  };

  handleSelect(selected, event) {
    let { inData } = this.props.InsuranceState;
    inData[event.name] = selected.value;
    this.props.setInsuranceData(inData);
  }

  submitHandler = (e) => {
    let { inData } = this.props.InsuranceState;
    e.preventDefault();
   };

  render() {
    let { errClass } = this.state;
    let { inData, inSpinner, countries } = this.props.InsuranceState;
    return (
      <Fragment>
        <div className="main-content yss-site--main__content max-w-5xl m-auto">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Claim Your <span>Insurance</span>
                </h3>
              </div>
              <div className="site__form middle__content add-listing--form">
                <form className="clearfix" onSubmit={(e) => this.submitData(e)}>
                  <div className="form-item">
                    <div className="form-label">Email:</div>
                    <input
                      className={
                        errClass == "email"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="email"
                      placeholder="you@yourdomain.com"
                      onChange={this.handleChange}
                      value={inData.email}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item w-2/4">
                    <div className="form-label">First Name:</div>
                    <input
                      className={
                        errClass == "username"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="username"
                      onChange={this.handleChange}
                      value={inData.name}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Last Name:</div>
                    <input
                      className={
                        errClass == "username"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="username"
                      onChange={this.handleChange}
                      value={inData.name}
                      autoComplete="off"
                    />
                  </div>

                  <div className="form-item">
                    <div className="form-label">Phone Number</div>
                    <input
                      className={
                        errClass == "listing_name"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="phone"
                      placeholder="phone"
                      onChange={this.handleChange}
                      value={inData.phone}
                      autoComplete="off"
                      className={
                        errClass == "phone"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Insurance Provider</div>
                    <input
                      className={
                        errClass == "listing_name"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="provider"
                      placeholder="Insurance provider"
                      onChange={this.handleChange}
                      value={inData.phone}
                      autoComplete="off"
                      className={
                        errClass == "phone"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Country</div>

                    <Select
                      name={"country"}
                      options={countries}
                      className="new_select"
                      value={countries.filter((option) => {
                        return option.value === inData.country;
                      })}
                      onChange={this.handleSelect}
                    />
                  </div>
                  <div className="form-item w-2/4">
                    <div className="form-label">State:</div>
                    <input
                      className={
                        errClass == "state"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="state"
                      onChange={this.handleChange}
                      value={inData.name}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item w-2/4">
                    <div className="form-label">City:</div>
                    <input
                      className={
                        errClass == "city"
                          ? "border-red-500"
                          : "border-blue-800"
                      }
                      type="text"
                      name="city"
                      onChange={this.handleChange}
                      value={inData.name}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-grid">
                    <div className="form-actions">
                      <button type="submit">
                        {inSpinner ? <LoadingSpinner /> : "Submit"}
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  InsuranceState: state.InsuranceState,
});

export default connect(mapStateToProps, mapDispatchToProps)(InsuranceView);
