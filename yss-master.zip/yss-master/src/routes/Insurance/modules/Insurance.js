import {setSiteAlertMessage} from "../../SiteWrapper/modules/site"

export const SET_INSURANCE_FORM_DATA = "SET_INSURANCE_FORM_DATA";
export const SET_COUNTRIES_DATA="SET_COUNTRIES_DATA";

export function setInsuranceData(data) {
  return {
    type: SET_INSURANCE_FORM_DATA,
    payload: data,
  };
}

export function setCountries(data){
  return {
    type: SET_COUNTRIES_DATA,
    payload: data,
  };
}

export function saveInsurance(data) {
  return async (dispatch) => {};
}


export const fetchCountries = () => {
  return async (dispatch) => {
    try {
      let result = await fetch(`${__API__}/get/countries`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });
      let response = await result.json();
      if (!response.success) {
        await dispatch(
          setSiteAlertMessage({
            message: response.errors.exception,
            color: "teal",
          })
        );
      } else if (response.success) {
        await dispatch(setCountries(response.countries));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

const initialState = {
  inData: {},
  inSpinner: false,
  countries:[]
};

export const actions = {
  saveInsurance,
  setInsuranceData,
  setCountries,
  fetchCountries,
  setSiteAlertMessage
};

const ACTION_HANDLERS = {
  [SET_INSURANCE_FORM_DATA]: (state, action) => {
    return {
      ...state,
      inData: action.payload,
    };
  },
  [SET_COUNTRIES_DATA]:(state,action)=>{
    for(var i = 0; i < action.payload.length; i++){
      action.payload[i].label = action.payload[i]['name'];
      action.payload[i].value = action.payload[i]['phonecode'];
      delete action.payload[i].name;
      delete action.payload[i].phonecode;
    }
    return {
      ...state,
      countries: action.payload,
    };
  }
};

export default function InsuranceReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
