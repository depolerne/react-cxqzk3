import React, { Fragment } from "react";
import Spinner from "../../../components/Spinner/Spinner";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import { NameValidator } from "../../../helpers/NameValidator";
import { setTimeLable } from "../../../helpers/checkSlots";
import CancelModal from "../../../components/Modals/cancelModal";
import Select from "react-select";
import PackageTime from "../../../helpers/PackageSlot";

export class EditPackageView extends React.Component {
  constructor(props) {
    super(props);
    const { editPackageId } = this.props.PackageState;

    this.state = {
      Alert: false,
      showDeleteModal: false,
      errClass: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.changeSession = this.changeSession.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.setAlertState = this.setAlertState.bind(this);
    this.handleSelect = this.handleSelect.bind(this);

    this.state.id = this.props.PackageState.editPackageId;
  }

  handleChange(event) {
    let { packageData } = this.props.EditPackageState;
    const name = event.target.name;
    const value = event.target.value;
    if (packageData) {
      packageData[name] = value;
      this.props.setPackage(packageData);
    }
  }

  handleSelect(selected, event) {
    let { packageData } = this.props.EditPackageState;
    packageData[event.name] = selected.value;
    this.props.setPackage(packageData);
  }

  setAlertState(value) {
    this.setState({ Alert: value });
  }

  changeSession(event) {
    let { packageData } = this.props.EditPackageState;
    let name = event.target.name;
    let value = event.target.value;
    if (event.target.value === "select") {
      packageData[name] = "";
      this.props.setPackage(packageData);
    } else {
      packageData[name] = value;
      this.props.setPackage(packageData);
    }
  }

  componentDidMount() {

    let body=document.body;
    body.className="edit_package";
    this.props.fetchPackage(this.props.match.params.package_id);
    document.addEventListener("keyup", (e) => {
      if (e.keyCode === 27) {
        this.props.setDeleteModal(false)
      }
    });
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  submitHandler(event) {
    event.preventDefault();
    const { packageData } = this.props.EditPackageState;
    let format = /[!#$%^&*()_+\=\[\]{};':"\\|,`~<>\/?]+/;
    var amtFormat = /[a-zA-Z]$/;
    if (packageData.package_name.length < 3) {
      this.props.setAlertMessage({
        message: "Package name must contain 3 characters.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (NameValidator(packageData.package_name)) {
      this.props.setAlertMessage({
        message: "Package name should starts with 3 alphabets",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (format.test(packageData.package_name)) {
      this.props.setAlertMessage({
        message: "Package name should not contain special characters.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (packageData.package_description.length < 250) {
      this.props.setAlertMessage({
        message: "Please enter the Package Description atleast 250 words long.",
        color: "teal",
      });
      this.setState({ errClass: "desc" });
    } else if (packageData.session_minutes.length === 0) {
      this.props.setAlertMessage({
        message: "Please select the session minutes",
        color: "teal",
      });
      this.setState({ errClass: "minutes" });
    } else if (packageData.session_hours.length === 0) {
      this.props.setAlertMessage({
        message: "Please select the session hours",
        color: "teal",
      });
      this.setState({ errClass: "hours" });
    } else if (
      amtFormat.test(packageData.amount) ||
      packageData.amount > 999 ||
      packageData.amount < 1
    ) {
      this.props.setAlertMessage({
        message: "Enter the valid Package amount.",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else if (packageData.amount.length > 6 && packageData.amount < 999) {
      this.props.setAlertMessage({
        message: "Enter the valid Package amount.",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else if (!parseFloat(packageData.amount)) {
      this.props.setAlertMessage({
        message: "Package amount must be greater than zero",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else if (
      packageData.session_hours == "00" &&
      packageData.session_minutes == "00"
    ) {
      this.props.setAlertMessage({
        message: "Session timings can't be empty.",
        color: "teal",
      });
      this.setState({ errClass: "hours" });
    } else {
      this.props.updatePackage({ ...packageData, history: this.props.history });
    }
    setTimeout(() => {
      this.setState({ errClass: "" });
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  render() {
    const {
      openDeleteModal,
      packageData,
      submitSpinner,
      spinnerStatus,
    } = this.props.EditPackageState;
    let { errClass } = this.state;
    const { Hours, Mins,Counts } = PackageTime;

    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            {openDeleteModal ? (
              <CancelModal
                actionText={"delete Package"}
                cancelText={"Cancel"}
                warningText={"Are you sure you want to delete this Package ?"}
                actionEvent={() =>
                  this.props.deletePackage({
                    ...packageData,
                    history: this.props.history,
                  })
                }
                cancelEvent={() => this.props.setDeleteModal(false)}
              />
            ) : null}
            <div className="page__content">
              {/* ---------------------------------- */}
              <div className="form__heading">
                <h3>
                  Edit <span>Package</span>
                </h3>
              </div>
              {spinnerStatus ? (
                <Spinner text={"Fetching package details..."} />
              ) : (
                <div className="site__form middle__content">
                  <div className="edit_package--form create_package--form">
                    <form className="clearfix" onSubmit={this.submitHandler}>
                      <div className="form-item">
                        <div className="form-label">Package Name</div>
                        <input
                          className={errClass == "name" ? "border-red-500" : ""}
                          type="text"
                          name="package_name"
                          onChange={(e) => this.handleChange(e)}
                          value={
                            this.props.EditPackageState.packageData.package_name
                          }
                        />
                      </div>
                      <div className="form-item">
                        <label className="form-label">Package Description</label>
                        <textarea
                          type="text"
                          className={errClass == "desc" ? "border-red-500" : ""}
                          name="package_description"
                          value={packageData && packageData.package_description}
                          onChange={(e) => this.handleChange(e)}
                        />
                      </div>

                      <div className="form-grid timeslot">
                        <div className="form-label">Session: </div>
                        <div className="timeslot__slot--row-pack">
                          <div className="slots_row">
                            <div className="f_slot slots">
                            <Select
                              name={"session_hours"}
                              className="new_select"
                              options={Hours}
                              value={Hours.filter((option) => {
                                return option.value === packageData.session_hours;
                              })}
                              onChange={this.handleSelect}
                              searchable={true}
                            />
                            </div>
                            <div className="s_slot slots">
                            <Select
                              name={"session_minutes"}
                              className="new_select"
                              options={Mins}
                              value={Mins.filter((option) => {
                                return option.value === packageData.session_minutes;
                              })}
                              onChange={this.handleSelect}
                              searchable={true}
                            />
                            </div>
                          </div>
                          <div className="form-label">
                            {" "}
                            {setTimeLable(
                              packageData.session_hours,
                              packageData.session_minutes
                            )
                              ? "minutes"
                              : "hours"}
                          </div>
                        </div>
                      </div>

                      <div className="form-grid timeslot">
                        <div className="form-label">No. of Sessions: </div>
                        <div className="slots_row">
                          <div className="first_slot slots">
                          <Select
                            name={"no_of_slots"}
                            className="new_select"
                            options={Counts}
                            value={Counts.filter((option) => {
                              return option.value === packageData.no_of_slots;
                            })}
                            onChange={this.handleSelect}
                            searchable={true}
                          />
                          </div>
                        </div>
                      </div>      

                      <div className="form-item">
                        <div className="form-label">Package Amount:</div>
                        <input
                          className={
                            errClass == "amount" ? "border-red-500" : ""
                          }
                          type="text"
                          placeholder="Enter the amount"
                          name="amount"
                          value={packageData && packageData.amount}
                          onChange={(e) => this.handleChange(e)}
                        />
                      </div>
                      
                      <div className="form-actions">
                        <button type="submit">
                          {submitSpinner ? <LoadingSpinner /> : "Update"}
                        </button>
                        <button
                          type="button"
                          onClick={() => this.props.setDeleteModal(true)}
                        >
                          Delete
                        </button>
                      </div>
                    </form>
                    <div className="help__block">
                      <div className="page_title text-center">
                        <h1 className="text-xl">
                          <span className="text_nav_blue">How This Works</span>
                        </h1>
                      </div>
                      <div className="help__text">
                        <p>
                          Contrary to popular belief Lorem Ipsum is not simply
                          random.
                        </p>
                        <p>It has roots a piece classical Latin</p>
                        <p>
                          literature from 45 BC, making it over
                          <br /> 2000 years old. Richard McClintock, a Latin
                          professor at Hampden-Sydney College in Virginia,
                        </p>
                        <p>
                          looked up one of the more obscure
                          <br /> Latin words, consectetur, from a Lorem Ipsum <br />
                          passage, and going through the cites of the word in
                          classical literature, discovered the undoubtable source.
                          Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de
                          Finibus Bonorum et Malorum.
                        </p>
                        <p>
                          literature from 45 BC, making it over
                          <br /> 2000 years old. Richard McClintock, a Latin
                          professor at Hampden-Sydney College in Virginia,
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default EditPackageView;

// this.props.deletePackage(this.state.id)
