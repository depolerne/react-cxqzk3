import EditPackage from './containers/EditPackageContainer';
export { EditPackage };
export * from './modules/EditPackage';

export default EditPackage;
