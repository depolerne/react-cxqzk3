import fetch from "isomorphic-fetch";
import auth from "../../../helpers/auth";
import { setAlertMessage,setUserDataInState } from "../../selectWrapper/modules/select";

//---> Defining types for different actions

export const FETCH_PACKAGE_SET_UPDATED_DATA = "FETCH_PACKAGE_SET_UPDATED_DATA";
export const SET_SPINNER_STATUS = "SET_SPINNER_STATUS";
export const SET_FETCH_PACKAGE_DATA = "SET_FETCH_PACKAGE_DATA";
export const SET_DELETE_MODAL_STATUS = "SET_DELETE_MODAL_STATUS";
export const SET_SUBMIT_FORM_LOADING_SPINNER='SET_SUBMIT_FORM_LOADING_SPINNER';

//---> Defining Actions to set state variables
export const setPackage = (data) => {
  return {
    type: SET_FETCH_PACKAGE_DATA,
    payload: data,
  };
};

export const setSpinnerStatus = (status) => {
  return {
    type: SET_SPINNER_STATUS,
    payload: status,
  };
};

export const setDeleteModal = (flag) => {
  return {
    type: SET_DELETE_MODAL_STATUS,
    payload: flag,
  };
};

export const submitFormSpinner=(flag)=>{
  return {
    type:SET_SUBMIT_FORM_LOADING_SPINNER,
    payload:flag
  }
}

//---> API to fetch individual Package Data by Id

export const fetchPackage = (package_id) => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setSpinnerStatus(true));
    await dispatch(setPackage(""));
    const token = auth.getAccessToken();
    try {
      let result = await fetch(
        `${__API__}/view/package?package_id=${package_id}`,
        {
          method: "GET",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map(item=>{
          dispatch(setAlertMessage({message: response.errors[item][0],color: "teal"}))
        })
        await dispatch(setSpinnerStatus(false));
      } else if (response.success) {
        await dispatch(setPackage(response.package));
        await dispatch(setSpinnerStatus(false));
      }
    } catch (e) {
      dispatch(
        setAlertMessage({ message: "You need to login first", color: "teal" })
      );
      await dispatch(setSpinnerStatus(false));
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const updatePackage = (data) => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(submitFormSpinner(true));
    const token = auth.getAccessToken();
    try {
      let result = await fetch(
        `${__API__}/edit-package?package_id=${data.id}`,
        {
          method: "POST",
          cache: "no-cache",
          body: JSON.stringify(data),
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map(item=>{
          dispatch(setAlertMessage({message: response.errors[item][0],color: "teal"}))
        })
        await dispatch(submitFormSpinner(false));
      } else if (response.success) {
        await dispatch(
          setAlertMessage({
            message: "Package updated Successfully",
            color: "green",
          })
        );
        await dispatch(submitFormSpinner(false));
      }
    } catch (e) {
      dispatch(
        setAlertMessage({ message: "You need to login first", color: "teal" })
      );
      await dispatch(submitFormSpinner(false));
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

//--------Deleting Package API----------

export const deletePackage = (data) => {
  return async (dispatch) => {
    await dispatch(setSpinnerStatus(true));
    const token = auth.getAccessToken();
    try {
      let result = await fetch(
        `${__API__}/delete-package?package_id=${data.id}`,
        {
          method: "POST",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map(item=>{
          dispatch(setAlertMessage({message: response.errors[item][0],color: "teal"}))
        })
        await dispatch(setSpinnerStatus(false));
        await dispatch(setDeleteModal(false));
      } else if (response.success) {
        await dispatch(
          setAlertMessage({
            message: "package deleted Successfully",
            color: "green",
          })
        );
        await dispatch(setUserDataInState(response.user));
        await dispatch(setSpinnerStatus(false));
        await dispatch(setDeleteModal(false));
        data.history.push("/coach/dashboard/package_lists");
      }
    } catch (e) {
      dispatch(
        setAlertMessage({
          message: "You need to login first",
          color: "teal",
        })
      );
      await dispatch(setSpinnerStatus(false));
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

//---> exporting multiple functions and actions

export const actions = {
  updatePackage,
  deletePackage,
  fetchPackage,
  setDeleteModal,
  setPackage,
  setAlertMessage,
  submitFormSpinner
};

//---> defining the initialState for state variables

const initialState = {
  spinnerStatus: false,
  submitSpinner:false,
  openDeleteModal: false,
  packageData: {},
};

const ACTION_HANDLERS = {
  [SET_FETCH_PACKAGE_DATA]: (state, action) => {
    return {
      ...state,
      packageData: action.payload,
    };
  },
  [SET_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      spinnerStatus: action.payload,
    };
  },
  [SET_DELETE_MODAL_STATUS]: (state, action) => {
    return {
      ...state,
      openDeleteModal: action.payload,
    };
  },
  [SET_SUBMIT_FORM_LOADING_SPINNER]:(state,action)=>{
    return {
      ...state,
      submitSpinner: action.payload,
    };
  }
};

export default function EditPackageReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
