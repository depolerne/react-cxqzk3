import React from 'react';
import {
    actions, fetchPackage
} from '../modules/EditPackage';
import * as Cookies from 'js-cookie'
import { bindActionCreators } from 'redux';
import EditPackageView from '../components/EditPackageView';
import { connect } from 'react-redux';
import { withJob } from 'react-jobs';
import RedBox from 'redbox-react';

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});

const mapStateToProps = (state) => ({
    EditPackageState: state.EditPackageState,
    PackageState:state.PackageState
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => {

        //await dispatch(fetchPackage())    
    },
    /* eslint-disable */ ErrorComponent: ({ error }) =>
      __DEV__ ? <RedBox error={error} /> : null,
  })(EditPackageView);
  

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
