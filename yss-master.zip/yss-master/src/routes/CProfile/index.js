import CProfile from './containers/CProfileContainer';
export { CProfile };
export * from './modules/CProfile';

export default CProfile;
