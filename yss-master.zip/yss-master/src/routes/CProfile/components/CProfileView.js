import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import _get from "lodash/get";
import queryString from "query-string";
import Spinner from "../../../components/Spinner/Spinner";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import ChangePassword from "./ChangePassword";
import { NameValidator } from "../../../helpers/NameValidator";
import { ZoneList } from "../../../helpers/ZoneList";
import InsightBlock from "../../../components/InsightBlock/InsightBlock";
import CancelModal from "../../../components/Modals/cancelModal";
import ManageListing from "./ManageListing";
import Select from "react-select";

export class CProfileView extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      spinner: false,
      tab: "myprofile",
      events: [],
    };
    this.handlechange = this.handlechange.bind(this);
    this.setTabState = this.setTabState.bind(this);
    this.changeAvatar = this.changeAvatar.bind(this);
    this.profileHandler = this.profileHandler.bind(this);
    this.connectWithStripe = this.connectWithStripe.bind(this);
    this.handleGoogle = this.handleGoogle.bind(this);
    this.removeAvatar = this.removeAvatar.bind(this);
    this.handleSelect=this.handleSelect.bind(this)
  }

  componentDidMount() {
    // ------> base Url for Image load
    let body = document.body;
    body.className = "dashboard_profile cons__profile";
    this.props.setMenuHover("profile");
    this.props.getBookingsLength();
    this.props.getUpcomingAppointments();
    
    let params = queryString.parse(this.props.location.search);
    if (params.code && params.scope) {
      this.props.connectWithStripe(params);
    }
    document.addEventListener("keyup", (e) => {
      if (e.keyCode === 27) {
        this.props.setStripeModal(false);
      }
    });
    this.props.fetchCategory();
    this.props.fetchLables();
    this.props.fetchRegions();
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  async handleGoogle(e) {
    e.preventDefault();
    await this.props.connectGoogleCalendar({ ...this.state, history: this.props.history });
  }

  handleSelect(selected, event) {
    let { userData } = this.props.selectState;
    userData[event.name] = selected.value;
    this.props.setUserDataInState(userData);
  }

  handlechange(event) {
    let { userData } = this.props.selectState;
    const name = event.target.name;
    const value = event.target.value;
    userData[name] = value;
    this.props.setUserDataInState(userData);
  }

  // -----> on Change and Validations function for updating profile picture
  async changeAvatar(event) {
    let type = event.target.files[0];
    if (!type.name.match(/\.(jpg|jpeg|png)$/)) {
      jQuery("input[type='file']").val("");
      this.props.setAlertMessage({
        message: "The Image type must be JPEG, JPG, PNG",
        color: "teal",
      });
    } else if (event.target.files[0].size > 12400000) {
      this.props.setAlertMessage({
        message: "The Image size must be less than 10 MB",
        color: "teal",
      });
    } else {
      let fd = new FormData();
      fd.append("image", event.target.files[0]);
      this.props.updateAvatar(fd);
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  // -----> state for header tabs
  setTabState(tab = "myprofile") {
    this.setState({
      tab: tab,
    });
  }

  //-----> Validations for Profile section
  profileHandler(event) {
    event.preventDefault();
    let { userData } = this.props.selectState;
    var regex = /[!@#$%`^&*()_+\-=\[\]{};':"\\|,~.<>\/?]+/;
    let locationregex = /[!@#$%`^&*()_+\=\[\]{};':"\\|~<>\?]+/;
    if (userData.name.length > 32) {
      this.props.setAlertMessage({
        message: "Name can't be larger than 32 characters.",
        color: "teal",
      });
    } else if (userData.name.length < 3) {
      this.props.setAlertMessage({
        message: "Name must contain 3 characters",
        color: "teal",
      });
    } else if (NameValidator(userData.name.replace(/ /g, ""))) {
      this.props.setAlertMessage({
        message: "Name must starts with 3 alphabets",
        color: "teal",
      });
    } else if (regex.test(userData.name)) {
      this.props.setAlertMessage({
        message: "Name should not contain special characters.",
        color: "teal",
      });
    }else if (
      userData.timezone === "select" ||
      userData.timezone === null ||
      userData.timezone === "null"
    ) {
      this.props.setAlertMessage({
        message: "Please select the timezone!!",
        color: "teal",
      });
    } else {
      this.props.updateProfile({ ...userData, history: this.props.history });
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  // ----------------Stripe connect API---------------
  connectWithStripe() {
    let params = queryString.parse(this.props.location.search);
    if (params.code && params.scope) {
      this.props.connectWithStripe(params);
    }
  }

  removeAvatar() {
    this.props.deleteuserAvatar();
  }

  render() {
    const {
      isErrMessage,
      profileSpinner,
      avatarSpinner,
      topHeader,
      allBookings,
      upcomingBookings,
      removeStripeModal,
    } = this.props.CProfileState;

    let { errClass } = this.state;
    let { userData, revenue, c_location } = this.props.selectState;

    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            {removeStripeModal ? (
              <CancelModal
                cancelEvent={() => this.props.setStripeModal(false)}
                actionEvent={() => this.props.disconnectStripe()}
                actionText={"Remove Account"}
                cancelText={"Discard"}
                warningText={
                  "Are you sure you want to remove your Stripe Account"
                }
              />
            ) : null}
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  {topHeader[0]} <span>{topHeader[1]}</span>
                </h3>
              </div>

              {/* -----------------------------Header Tabs--------------------------- */}
              <div className="site__form middle__content">
                <div className="tabs__wrapper">
                  <div id="tabs" className="tabs">
                    <ul className="tab_lists">
                      <li
                        className={
                          this.state.tab === "myprofile"
                            ? "ui-tabs-active"
                            : "ui-tabs"
                        }
                      >
                        <Link
                          to="#"
                          onClick={() => {
                            this.setTabState("myprofile");
                            this.props.setHeader(["MY", "Profile"]);
                          }}
                        >
                          My Profile
                        </Link>
                      </li>
                      <li
                        className={
                          this.state.tab === "manageList"
                            ? "ui-tabs-active"
                            : "ui-tabs"
                        }
                      >
                        <Link
                          to="#"
                          onClick={() => {
                            this.setTabState("manageList");
                            this.props.setHeader(["", "Manage Listing"]);
                          }}
                        >
                          Manage Listing
                        </Link>
                      </li>
                      <li
                        className={
                          this.state.tab === "payments"
                            ? "ui-tabs-active"
                            : "ui-tabs"
                        }
                      >
                        <Link
                          to="#"
                          onClick={() => {
                            this.setTabState("payments");
                            this.props.setHeader(["", "Integrations"]);
                          }}
                        >
                          Payment
                        </Link>
                      </li>
                      <li
                        className={
                          this.state.tab === "changepwd"
                            ? "ui-tabs-active"
                            : "ui-tabs"
                        }
                      >
                        <Link
                          to="#"
                          onClick={() => {
                            this.setTabState("changepwd");
                            this.props.setHeader(["Change", "Password"]);
                          }}
                        >
                          Change Password
                        </Link>
                      </li>
                    </ul>
                    {/* ----------------------Profile section ---------------------- */}
                    {(() => {
                      if (this.state.tab === "myprofile") {
                        return (
                          <Fragment>
                            <div id="tabs-1">
                              {errClass == "avatar" ? (
                                <p className="err-message">
                                  {isErrMessage.message}
                                </p>
                              ) : (
                                ""
                              )}

                              {userData ? <form
                                className="clearfix profile_form"
                                onSubmit={this.profileHandler}
                              >
                                {/* ---------- Profile Photo----------- */}
                                <div className="form-item profile_pic_right">
                                  <label />
                                  <div className="pro_pic">
                                    {avatarSpinner ? (
                                      <Spinner />
                                    ) : (userData &&
                                      <img
                                        className="bg-nav w-full"
                                        src={
                                          userData.avatar_id === null
                                            ? "images/user_icon.svg"
                                            : __IMG_URL__ + userData.avatar_id
                                        }
                                      />
                                    )}
                                    <span className="bg-white rounded-full">
                                      <img src="images/photograph.svg" />
                                    </span>
                                    {userData.avatar_id === null ? null : (
                                      <span className="pic_options">
                                        <Link
                                          to="#"
                                          title="Remove Profile Pic"
                                          onClick={this.removeAvatar}
                                        >
                                          <i className="far fa-trash-alt"></i>
                                        </Link>
                                      </span>
                                    )}
                                    <input
                                      type="file"
                                      name="avatar_id"
                                      onChange={this.changeAvatar}
                                    />
                                  </div>
                                </div>
                                {/* ---------------------------------- */}

                                <div className="form-item">
                                  <label>Name</label>
                                  <input
                                    className={
                                      errClass == "name" ? "border-red-500" : ""
                                    }
                                    type="text"
                                    name="name"
                                    defaultValue={userData && userData.name}
                                    onChange={this.handlechange}
                                  />
                                </div>
                                <div className="form-item">
                                  <label>Email</label>
                                  <input
                                    className={
                                      errClass == "location"
                                        ? "border-red-500"
                                        : ""
                                    }
                                    type="text"
                                    name="location"
                                    placeholder="enter your location"
                                    onChange={this.handlechange}
                                    defaultValue={userData.email}
                                    disabled
                                    
                                  />
                                </div>
                                <div className="form-item">
                                  <label>Time Zone</label>
                                  {/* <div className="first_slot slots"> */}
                                    {/* --------------country code------------ */}
                                    {/* <select
                                      name="timezone"
                                      onChange={this.handlechange}
                                      value={userData && userData.timezone}
                                    >
                                      <option>select</option>
                                      {ZoneList.map((item, i) => (
                                        <option key={i} value={item.value}>
                                          {item.label}
                                        </option>
                                      ))}
                                    </select> */}
                                    <Select
                                name={'timezone'}
                                className="new_select"
                                options={ZoneList}
                                value={ZoneList.filter((option) => {
                                  return option.value === userData.timezone;
                                })}
                                onChange={this.handleSelect}
                                searchable={true}
                              />
                                  
                                    {/* -------------------------------------- */}
                                  {/* </div> */}
                                </div>
                                <div className="form-item sync">
                                  <label>Sync calendar</label>
                                  <span>
                                    <Link to="#" onClick={this.handleGoogle}>
                                      Connect with Google Calendar{" "}
                                    </Link>
                                    {/* <Link to="#">Connect with iCalendar</Link> */}
                                  </span>
                                </div>
                                <div className="form-actions mt-6">
                                  <label />
                                  <button type="submit">
                                    {profileSpinner ? (
                                      <LoadingSpinner />
                                    ) : (
                                      "Update"
                                    )}
                                  </button>
                                </div>
                              </form>: <Spinner/>}
                            </div>
                          </Fragment>
                        );
                      } else if (this.state.tab === "manageList") {
                        return (
                          <ManageListing/>
                        );
                      } else if (this.state.tab === "payments") {
                        return (
                          <Fragment>
                            {/* -----------------------Stripe section---------------------- */}
                            <div id="tabs-3">
                              <div className="pay_stripe mt-6">
                                <div className="stripe__img">
                                  <img src="images/stripe_img.jpg" />
                                </div>
                                <div className="stripe_detail">
                                  <h2 className="stripe_title">Stripe</h2>
                                  <p className="text-base">
                                    Millions of businesses of all sizes—from
                                    startups to large enterprises—use Stripe’s
                                    software and APIs to accept payments, send
                                    payouts, and manage their businesses online.
                                  </p>
                                  <div className="btn">
                                    {userData.is_acct_connected == "0" ? (
                                      <a
                                        href={`https://connect.stripe.com/oauth/authorize?response_type=code&client_id=${__STRIPE_CONNECT_ACCOUNT_KEY__}&scope=read_only`}
                                      >
                                        Connect with Stripe
                                      </a>
                                    ) : (
                                      <Link
                                        to="#"
                                        onClick={() =>
                                          this.props.setStripeModal(true)
                                        }
                                      >
                                        Disconnect your Stripe account
                                      </Link>
                                    )}
                                  </div>
                                  {/* {this.state.stripeConnect ?   
                                  <div className='btn'>
                                     <a href={`https://connect.stripe.com/oauth/authorize?response_type=code&client_id=ca_IFVD6rM85fxgHD72xczrtTMDJLnMGqWf&scope=read_only`}>
                                       Connect with Stripe
                                       </a>
                                     </div>:                               
                                     <div className='btn'>
                                     <a href='#'>
                                       Disconnect to Stripe 
                                       </a>
                                     </div>
                                     } */}
                                </div>
                              </div>
                            </div>
                          </Fragment>
                        );
                      } else {
                        return (
                          <Fragment>
                            {/*------------------Change Password Section ---------------------  */}
                            <div id="tabs-4" className="ch-pass--form">
                              <ChangePassword
                                submitHandler={this.passwordHandler}
                                old_password={this.state.old_password}
                                new_password={this.state.new_password}
                                c_password={this.state.c_password}
                                handlechange={this.handleChangePassword}
                                spinner={this.state.spinner}
                              />
                            </div>
                          </Fragment>
                        );
                      }
                    })()}
                  </div>
                </div>
                {this.state.tab === "myprofile" ? (
                  <div className="static__blocks bg-white md:-mx-3 mt-3 clearfix">
                    <InsightBlock
                      heading={"Total"}
                      text={"Appointments"}
                      insightData={allBookings.length}
                      clickURL={"/coach/dashboard/appointments"}
                    />
                    <InsightBlock
                      heading={"Upcoming"}
                      text={"Appointments"}
                      insightData={upcomingBookings.length}
                    />
                    <InsightBlock
                      heading={"Total"}
                      text={"Revenue"}
                      insightData={["£", revenue && revenue]}
                    />
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default CProfileView;