import React from "react";
import { Fragment } from "react";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import { connect } from "react-redux";
import { actions } from "../modules/CProfile";

export class ChangePassword extends React.Component {
  constructor(props) {
    super(props);
    this.submitHandler = this.submitHandler.bind(this);
    this.handlechange = this.handlechange.bind(this);
  }

  handlechange(e) {
    let { password } = this.props.CProfileState;
    password[e.target.name] = e.target.value;
    this.props.setPasswords(password);
  }

  componentWillUnmount(){
    this.props.setPasswords({
      old_password: "",
      new_password: "",
      c_password: "",
    })
  }

  submitHandler(event) {
    event.preventDefault();
    let { password } = this.props.CProfileState;
    if (!password.old_password.length) {
      this.props.setAlertMessage({
        message: "Old password can't be empty",
        color: "teal",
      });
    // } else if (
    //   password.old_password.length < 8 
    //       ) {
    //   this.props.setAlertMessage({
    //     message: "Incorrect old password",
    //     color: "teal",
    //   });
    } else if (!password.new_password.length) {
      this.props.setAlertMessage({
        message: "New password can't be empty",
        color: "teal",
      });
    } else if (password.new_password.length < 8) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (password.new_password.search(/[a-z]/i) < 0) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (password.new_password.search(/[0-9]/) < 0) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(password.new_password)
    ) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (password.new_password.length<8) {
        this.props.setAlertMessage({
          message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
          color: "teal",
        });  
    } else if (password.old_password === password.new_password) {
      this.props.setAlertMessage({
        message: "Old password and New password should not match.",
        color: "teal",
      });
    } else if (!password.c_password.length) {
      this.props.setAlertMessage({
        message: "confirm password can't be empty",
        color: "teal",
      });
    } else if (password.c_password !== password.new_password) {
      this.props.setAlertMessage({
        message: "New password and confirm password should be same",
        color: "teal",
      });
    } else {
      this.props.changePassword({ ...password });
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  render() {
    let { password, changePasswordSpinner } = this.props.CProfileState;
    return (
      <Fragment>
        <form className="clearfix profile_form" onSubmit={this.submitHandler}>
          <div className="form-item">
            <label>Old Password</label>
            <input
              type="password"
              placeholder="Old Password"
              name="old_password"
              value={password.old_password}
              onChange={this.handlechange}
            />
          </div>
          <div className="form-item">
            <label>New Password</label>
            <input
              placeholder="New Password"
              type="password"
              name="new_password"
              value={password.new_password}
              onChange={this.handlechange}
            />
          </div>
          <div className="form-item">
            <label>Confirm Password</label>
            <input
              type="password"
              placeholder="Confirm Password"
              name="c_password"
              value={password.c_password}
              onChange={this.handlechange}
            />
          </div>
          <div className="form-actions">
            <label />
            <button type="submit">
              {changePasswordSpinner ? <LoadingSpinner /> : "Submit"}
            </button>
          </div>
        </form>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CProfileState: state.CProfileState,
});

export default connect(mapStateToProps, actions)(ChangePassword);
