import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { actions } from "../modules/CProfile";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import MultiSelecter from "../../../components/Multiselect/MultiSelecter";
import Select from "react-select";
import { Editor } from "@tinymce/tinymce-react";
import Dropzone from "react-dropzone";

import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng,
  getInputProps,
} from "react-places-autocomplete";

export class ManageListing extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errClass: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.handleImg = this.handleImg.bind(this);
    this.handleLocation = this.handleLocation.bind(this);
    this.handleEditorChange = this.handleEditorChange.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.removeGalleryImage = this.removeGalleryImage.bind(this);
    this.removeGallery = this.removeGallery.bind(this);
    this.handleLocationSelect = this.handleLocationSelect.bind(this);
    this.onDrop = this.onDrop.bind(this);
  }

  handleChange(e) {
    let { listing_data } = this.props.selectState;
    listing_data[e.target.name] = e.target.value;
    this.props.setManageListingData(listing_data);
  }

  async componentDidMount() {
    // this.listing_data[gallery_images]=[]
    // await this.props.setManageListingData(this.listing_data)
  }

  handleLocation(value) {
    let { listing_data } = this.props.selectState;
    listing_data["location"] = value;
    this.props.setManageListingData(listing_data);
  }

  async handleLocationSelect(address) {
    let { listing_data } = this.props.selectState;
    const results = await geocodeByAddress(address);
    const latLng = await getLatLng(results[0]);
    listing_data["lattitude"] = latLng.lat;
    listing_data["longitude"] = latLng.lng;
    listing_data["location"] = address;
    this.props.setManageListingData(listing_data);
  }

  handleEditorChange(value) {
    let { listing_data } = this.props.selectState;
    listing_data["description"] = value;
    this.props.setManageListingData(listing_data);
  }

  handleSelect(selected, event) {
    let { listing_data } = this.props.selectState;
    listing_data[event.name] = selected.value;
    this.props.setManageListingData(listing_data);
  }

  handleMultiSelect = async (id, selectedList) => {
    let { listing_data } = this.props.selectState;
    let arr = [];
    selectedList.map((item) => arr.push(item.id));
    listing_data[id] = arr;
    this.props.setManageListingData(listing_data);
  };

  removeGallery(id) {
    if (confirm("Are you Sure?")) {
      this.props.removeGalleryImage(id);
    }
  }

  removeGalleryImage(img) {
    let {
      listing_data: { gallery_images },
      listing_data,
    } = this.props.selectState;

    gallery_images = gallery_images.filter((i) => i !== img);
    listing_data["gallery_images"] = gallery_images;
    this.props.setManageListingData(listing_data);
  }

  async handleImg(event) {
    let name = event.target.name;
    let { files } = event.target;
    let { listing_data } = this.props.selectState;
    if (!files[0].name.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
      jQuery("input[name='"+name+"']").val("");
      this.props.setAlertMessage({
        message: "The Image type must be JPEG, JPG, PNG.",
        color: "teal",
      });

      listing_data[name] = null;
      this.props.setManageListingData(listing_data);

    } else if (files[0].size > 8000000) {
      jQuery("input[name='"+name+"']").val("");
      this.props.setAlertMessage({
        message: "The Image size must be less than 8 MB.",
        color: "teal",
      });

      listing_data[name] = null;
      this.props.setManageListingData(listing_data);

      //---> Disappearing the Alert Message after 3 sec
    } else {
      let reader = new FileReader();
      reader.readAsDataURL(files[0]);
      reader.onload = (e) => {
        listing_data[name] = e.target.result;
        this.props.setManageListingData(listing_data);
        this.props.showCoverPreview(true);
      };
    }
    setTimeout(() => {
      this.props.setAlertMessage({
        message: "",
        color: "",
      });
    }, 5000);
  }

  onDrop = (files) => {
    let {
      listing_data: { gallery, gallery_images },
      listing_data,
    } = this.props.selectState;
    // let img_arr=[];
    if (files.length + gallery.length + gallery_images.length > 6) {
      this.props.setAlertMessage({
        message: "You can only select 6 images.",
        color: "teal",
      });
    } else {
      Object.keys(files).map(async (item, i) => {
        if (!files[item].name.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
          this.props.setAlertMessage({
            message: "The Image type must be JPEG, JPG, PNG",
            color: "teal",
          });
        } else if (files[item].size > 8000000) {
          this.props.setAlertMessage({
            message: "Image size should not be more than 8 MB.",
            color: "teal",
          });
        } else {
          let reader = new FileReader();
          reader.readAsDataURL(files[item]);
          reader.onload = (e) => {
            if (!gallery_images.includes(e.target.result)) {
              gallery_images.push(e.target.result);
            }
          };
        }
      });
      listing_data["gallery_images"] = gallery_images;
      this.props.setManageListingData(listing_data);
    }
    setTimeout(() => {
      this.props.setAlertMessage({
        message: "",
        color: "",
      });
    }, 5000);
  };

  submitHandler(e) {
    e.preventDefault();
    let { listing_data } = this.props.selectState;
    let specials = /[!@#$%`^&*()_+\-=\[\]{};':"\\|,~<>\/?]+/;
    let locationRegex = /[!@#$%`^&*()_+\=\[\]{};:\\|~<>\?]+/;
    let urlRegex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
    if (specials.test(listing_data.listing_name)) {
      this.props.setAlertMessage({
        message: "Listing name should not contain special characters",
        color: "teal",
      });
      this.setState({ errClass: "listing_name" });
    } else if (listing_data.location === "") {
      this.props.setAlertMessage({
        message: "Please enter the Location",
        color: "teal",
      });
      this.setState({ errClass: "location" });
    } else if (locationRegex.test(listing_data.location)) {
      this.props.setAlertMessage({
        message: "Please enter the valid Location",
        color: "teal",
      });
      this.setState({ errClass: "location" });
    } else if (listing_data.description === "") {
      this.props.setAlertMessage({
        message: "Please enter the Description",
        color: "teal",
      });
      this.setState({ errClass: "desc" });
    } else if (listing_data.listing_category === "select") {
      this.props.setAlertMessage({
        message: "Please select the Category",
        color: "teal",
      });
      this.setState({ errClass: "category" });
    } else if (listing_data.listing_region === "") {
      this.props.setAlertMessage({  
        message: "Please select the region.",
        color: "teal",
      });
      this.setState({ errClass: "region" });
    } else if (listing_data.gallery_images.length+listing_data.gallery.length===0) {
        this.props.setAlertMessage({
          message: "Please upload atleast 1 gallery Image",
          color: "teal",
        });
        this.setState({ errClass: "website" });  
    } else if (
      listing_data.video_url &&
      !listing_data.video_url.match(urlRegex)
    ) {
      this.props.setAlertMessage({
        message: "Please enter the valid video URL",
        color: "teal",
      });
      this.setState({ errClass: "video_url" });
    } else {
      this.props.updateListing({ ...listing_data });
    }
    setTimeout(() => {
      this.props.setAlertMessage({
        message: "",
        color: "",
      });
      this.setState({ errClass: "" });
    }, 5000);
  }

  render() {
    const { errClass } = this.state;
    const { listing_data } = this.props.selectState;
    const {
      listing_lables,
      listing_categories,
      listing_regions,
      listingSpinner,
      cover_change,
    } = this.props.CProfileState;
    return (
      <Fragment>
        {/* -----------------------Manage Listing section---------------------- */}
        <div id="tabs-2">
          {listing_data && (
            <form
              className="profile_form update-listing--form"
              onSubmit={this.submitHandler}
            >
              <div className="form-item">
                <label>Listing Name:</label>
                <input
                  className={errClass == "listing_name" ? "border-red-500" : ""}
                  placeholder="Your Listing Name"
                  type="text"
                  name="listing_name"
                  onChange={this.handleChange}
                  defaultValue={listing_data.listing_name}
                />
              </div>
              <div className="form-item">
                <label>Location:</label>
                <PlacesAutocomplete
                  value={listing_data.location}
                  onChange={this.handleLocation}
                  onSelect={this.handleLocationSelect}
                >
                  {({
                    getInputProps,
                    getSuggestionItemProps,
                    suggestions,
                    loading,
                  }) => {
                    return (
                      <div className="autocomplete-root">
                        <input
                          {...getInputProps({
                            placeholder: "Enter the location",
                            className: "location-search-input border-blue-800",
                          })}
                        />

                        <div className="autocomplete-dropdown-container">
                          {loading && <div>Loading...</div>}
                          {suggestions.map((suggestion, i) => {
                            const className = suggestion.active
                              ? "suggestion-item--active"
                              : "suggestion-item";
                            // inline style for demonstration purpose
                            const style = suggestion.active
                              ? {
                                  backgroundColor: "#fafafa",
                                  cursor: "pointer",
                                }
                              : {
                                  backgroundColor: "#ffffff",
                                  cursor: "pointer",
                                };
                            return (
                              <div
                                key={i}
                                {...getSuggestionItemProps(suggestion, {
                                  className,
                                  style,
                                })}
                              >
                                <span key={suggestion}>
                                  {suggestion.description}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  }}
                </PlacesAutocomplete>
              </div>
              {/*<div className="form-item">
                <label>Contact Email/URL :</label>
                <input
                  className={
                    errClass == "contact_email_or_url" ? "border-red-500" : ""
                  }
                  placeholder="Contact email address"
                  type="text"
                  name="contact_email_or_url"
                  onChange={this.handleChange}
                  defaultValue={listing_data.contact_email_or_url}
                />
                </div>*/}
              <div className="form-item">
                <label>Description: </label>

                <Editor
                  apiKey="a9ko3r2y3k9l644lkbwctig4dtth7vdm9dtixph76ctyqiy5"
                  value={listing_data.description}
                  name="description"
                  init={{
                    height: 400,
                    //menubar: 'insert',
                    plugins: [
                      "advlist autolink lists link image charmap print preview anchor",
                      "searchreplace visualblocks code fullscreen",
                      "insertdatetime media table paste imagetools wordcount",
                    ],
                    toolbar:
                      "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
                  }}
                  onEditorChange={this.handleEditorChange}
                />
              </div>
              <div className="form-item">
                <label>Listing Category:</label>

                <Select
                  name={"listing_category"}
                  className="new_select"
                  options={listing_categories}
                  value={listing_categories.filter((option) => {
                    return option.value === listing_data.listing_category;
                  })}
                  onChange={this.handleSelect}
                  searchable={true}
                />
              </div>

              <div className="form-item">
                <label>Listing Region:</label>
                <Select
                  name={"listing_region"}
                  className="new_select"
                  options={listing_regions}
                  value={listing_regions.filter((option) => {
                    return option.value === listing_data.listing_region;
                  })}
                  onChange={this.handleSelect}
                  searchable={true}
                />
              </div>
              <div className="form-item">
                <label>Listing Lables (optional) :</label>
                <MultiSelecter
                  id="listing_label"
                  Options={listing_lables}
                  displayValue={"label_name"}
                  selectedValue={listing_data.multilabel}
                  fireData={(id, selectedList) =>
                    this.handleMultiSelect(id, selectedList)
                  }
                />
              </div>

              <div className="form-item file_upload-field">
                <label>Cover Image:</label>
                <input
                  name="cover_image"
                  type="file"
                  onChange={this.handleImg}
                />
                <div className="file_desc">
                  <p>Maximum file size: 8 MB.</p>
                </div>
              </div>
              {cover_change ? (
                <img
                  key={listing_data.cover_image}
                  className="md:ml-48 max-w-sm my-5"
                  src={listing_data.cover_image}
                />
              ) : (
                <img
                  key={listing_data.cover_img}
                  className="md:max-w-sm my-5 ml-13rem"
                  src={__IMG_URL__ + listing_data.cover_img}
                />
              )}
              <div className="form-item file_upload-field ">
                <label>Gallery images:</label>
                <Dropzone onDrop={this.onDrop} maxFiles={10}>
                  {({ getRootProps, getInputProps }) => (
                    <section className="container">
                      <div {...getRootProps({ className: "dropzone" })}>
                        <input {...getInputProps()} />
                        <p>
                          Drag 'n' drop some files here, or click to select
                          files
                        </p>
                      </div>
                    </section>
                  )}
                </Dropzone>
              </div>
              <div className="manage_listing__gallery flex">
                <ul className="gallery__images flex">
                  {listing_data.gallery.map((img) => (
                    <li
                      className="mx-3 image-area mb-8"
                      key={img.id}
                      id={"image-" + img.id}
                    >
                      <a
                        className="remove-image"
                        style={{ cursor: "pointer" }}
                        onClick={() => this.removeGallery(img.id)}
                      >
                        &#215;
                      </a>
                      <img key={img.id} src={__IMG_URL__ + img.gallery_img} />
                    </li>
                  ))}
                  {listing_data.gallery_images &&
                    listing_data.gallery_images.map((img, i) => (
                      <li className="mx-2 image-area" key={i}>
                        <Link
                          to="#"
                          className="remove-image"
                          onClick={() => this.removeGalleryImage(img)}
                        >
                          &#215;
                        </Link>
                        <img key={img} src={img} />
                      </li>
                    ))}
                </ul>
              </div>

              {/*<div className="form-item">
                <label>Website : (Optional)</label>
                <input
                  onChange={this.handleChange}
                  defaultValue={listing_data.website}
                  type="text"
                  name="website"
                  placeholder="website url"
                  autoComplete="off"
                  className={
                    errClass == "website" ? "border-red-500" : "border-blue-800"
                  }
                />
              </div>
              <div className="form-item">
                <label>Phone Number: (Optional)</label>
                <input
                  onChange={this.handleChange}
                  defaultValue={listing_data.phone}
                  type="text"
                  name="phone"
                  placeholder="Phone no."
                  autoComplete="off"
                  className={
                    errClass == "phone" ? "border-red-500" : "border-blue-800"
                  }
                />
              </div>*/}

              <div className="form-item">
                <label>Video : (optional)</label>
                <input
                  className={
                    errClass == "video_url"
                      ? "border-red-500"
                      : "border-blue-800"
                  }
                  type="text"
                  name="video_url"
                  placeholder="Url to video"
                  autoComplete="off"
                  defaultValue={listing_data.video_url}
                  onChange={this.handleChange}
                />
              </div>
              <div className="form-item file_upload-field">
                  <label>Insurance Certificate (optional) </label>
                  <input
                    name="insurance_certificate"
                    type="file"
                    onChange={this.handleImg}
                  />
                  <div className="file_desc">
                    <p>Maximum file size: 8 MB.</p>
                  </div>
                </div>
                  {listing_data.insurance_certificate && <img
                      key={listing_data.insurance_certificate}
                      className="ml-13rem w-32 my-5"
                      src={ (listing_data.insurance_certificate.indexOf("data:image") > -1 ) ? listing_data.insurance_certificate :  __IMG_URL__ + listing_data.insurance_certificate}
                    />
                  }
                <div className="form-item file_upload-field">
                  <label>Business Certificate (optional)</label>
                  <input
                    name="business_certificate"
                    type="file"
                    onChange={this.handleImg}
                  />
                  <div className="file_desc">
                    <p>Maximum file size: 8 MB.</p>
                  </div>
                </div>
                   {listing_data.business_certificate && <img
                      key={listing_data.business_certificate}
                      className="ml-13rem w-32 my-5"
                      src={ (listing_data.business_certificate.indexOf("data:image") > -1 ) ? listing_data.business_certificate :  __IMG_URL__ + listing_data.business_certificate}
                    />
                    }
              <div className="form-grid">
                <div className="form-actions">
                  <button type="submit">
                    {listingSpinner ? <LoadingSpinner /> : "Update"}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CProfileState: state.CProfileState,
});

export default connect(mapStateToProps, actions)(ManageListing);
