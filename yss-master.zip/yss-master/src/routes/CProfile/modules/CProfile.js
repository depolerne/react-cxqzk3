import auth from "../../../helpers/auth";
import _without from "lodash/without";
import _remove from "lodash/remove";
import _get from "lodash/get";
import fetch from "isomorphic-fetch";
import {
  setUserDataInState,
  setAlertMessage,
  setMenuHover,
  setCounsellorLocation,
  setManageListingData,
} from "../../selectWrapper/modules/select";
import { setListingsData } from "../../Listing/modules/Listing";
import { setSiteAlertMessage } from "../../SiteWrapper/modules/site";

//---> Defining types for different actions
export const CPROFILE_P_SET_SPINNER_STATUS = "CPROFILE_P_SET_SPINNER_STATUS";
export const CPROFILE_P_SET_AVATAR_SPINNER_STATUS =
  "CPROFILE_P_SET_AVATAR_SPINNER_STATUS";
export const CPROFILE_P_SET_CPROFILE_INFO = "CPROFILE_P_SET_CPROFILE_INFO";
export const SET_EMPTY_FORM_DATA = "SET_EMPTY_FORM_DATA";
export const SET_CPROFILE_COUNSELLOR_PASSWORD =
  "SET_CPROFILE_COUNSELLOR_PASSWORD";
export const SET_CPROFILE_CHANGE_PASSWORD_SPINNER =
  "SET_CPROFILE_CHANGE_PASSWORD_SPINNER";
export const SET_CPROFILE_TOP_HEADER = "SET_CPROFILE_TOP_HEADER";
export const SET_C_PROFILE_UPCOMING_APPOINTMENTS_LENGTH =
  "SET_C_PROFILE_UPCOMING_APPOINTMENTS_LENGTH";
export const SET_C_PROFILE_ALL_APPOINTMENTS = "SET_C_PROFILE_ALL_APPOINTMENTS";
export const SET_REMOVE_STRIPE_ACCOUNT_MODAL_STATUS =
  "SET_REMOVE_STRIPE_ACCOUNT_MODAL_STATUS";
export const SET_UPDATE_LISTING_DATA_SPINNER =
  "SET_UPDATE_LISTING_DATA_SPINNER";
export const CPROFILE_SET_LISTINGS_REGIONS_DATA =
  "CPROFILE_SET_LISTINGS_REGIONS_DATA";
export const CPROFILE_SET_LISTINGS_LABELS_DATA =
  "CPROFILE_SET_LISTINGS_LABELS_DATA";
export const CPROFILE_SET_LISTINGS_CATEGORY_DATA =
  "CPROFILE_SET_LISTINGS_CATEGORY_DATA";
export const CPROFILE_SET_IMAGE_PREVIEW_ARRAY =
  "CPROFILE_SET_IMAGE_PREVIEW_ARRAY";
export const MANAGE_LISTING_SHOW_COVER_IMAGE_PREVIEW =
  "MANAGE_LISTING_SHOW_COVER_IMAGE_PREVIEW";
//---> Defining Actions to set state variables
export const setHeader = (arr) => {
  return {
    type: SET_CPROFILE_TOP_HEADER,
    payload: arr,
  };
};

export const setAvatarSpinner = (status) => {
  return {
    type: CPROFILE_P_SET_AVATAR_SPINNER_STATUS,
    payload: status,
  };
};

export const setCProfileSpinnerStatus = (status) => {
  return {
    type: CPROFILE_P_SET_SPINNER_STATUS,
    payload: status,
  };
};

export const setEmptyForm = (flag) => {
  return {
    type: SET_EMPTY_FORM_DATA,
    payload: flag,
  };
};

export const setPasswords = (data) => {
  return {
    type: SET_CPROFILE_COUNSELLOR_PASSWORD,
    payload: data,
  };
};

export const setStripeModal = (flag) => {
  return {
    type: SET_REMOVE_STRIPE_ACCOUNT_MODAL_STATUS,
    payload: flag,
  };
};

export const setChangePasswordSpinner = (flag) => {
  return {
    type: SET_CPROFILE_CHANGE_PASSWORD_SPINNER,
    payload: flag,
  };
};

export const setAllAppointments = (data) => {
  return {
    type: SET_C_PROFILE_ALL_APPOINTMENTS,
    payload: data,
  };
};

export const setUpcomingBookingsLength = (length) => {
  return {
    type: SET_C_PROFILE_UPCOMING_APPOINTMENTS_LENGTH,
    payload: length,
  };
};

export function setListingSpinner(flag) {
  return {
    type: SET_UPDATE_LISTING_DATA_SPINNER,
    payload: flag,
  };
}

export const setListingCategories = (data) => {
  return {
    type: CPROFILE_SET_LISTINGS_CATEGORY_DATA,
    payload: data,
  };
};

export const setListingsRegions = (data) => {
  return {
    type: CPROFILE_SET_LISTINGS_REGIONS_DATA,
    payload: data,
  };
};

export const setListingsLables = (data) => {
  return {
    type: CPROFILE_SET_LISTINGS_LABELS_DATA,
    payload: data,
  };
};
//--->API to update user's the profile picture

export function setImagePreviews(data) {
  return {
    type: CPROFILE_SET_IMAGE_PREVIEW_ARRAY,
    payload: data,
  };
}

export function showCoverPreview(params) {
  return {
    type: MANAGE_LISTING_SHOW_COVER_IMAGE_PREVIEW,
    payload: params,
  };
}

export const updateAvatar = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setAvatarSpinner(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/update/profile/image`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ` + token,
          },
          body: data,
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setAvatarSpinner(false));
        } else if (response.success) {
          await dispatch(setAvatarSpinner(false));
          await dispatch(setUserDataInState(response.user));
          await dispatch(
            setAlertMessage({
              message: "Profile picture updated successfully",
              color: "green",
            })
          );
        }
      } catch (e) {
        await dispatch(setAvatarSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "You need to login first",
          color: "teal",
        })
      );
      await dispatch(setAvatarSpinner(false));
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

// ---->API to update Counsellor's profile

export const updateProfile = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setCProfileSpinnerStatus(true));
    await dispatch(setAlertMessage(""));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/profile-update?name=${data.name}&location=${data.location}&timezone=${data.timezone}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/vnd.api+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setCProfileSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setCProfileSpinnerStatus(false));
          await dispatch(
            setAlertMessage({
              message: "Profile updated successfully.",
              color: "green",
            })
          );
          await dispatch(setUserDataInState(response.user));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setCProfileSpinnerStatus(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "You need to login first",
          color: "teal",
        })
      );
      await dispatch(setCProfileSpinnerStatus(false));
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 5000);
  };
};

// ---> API to chnage password
export const changePassword = (data) => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setChangePasswordSpinner(true));
    const token = auth.getAccessToken();
    const params = { params: data };
    if (token) {
      try {
        let result = await fetch(`${__API__}/change-password`, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ` + token,
          },
          body: JSON.stringify(params),
        });
        let response = await result.json();
        if (!response.success) {
          await dispatch(setChangePasswordSpinner(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(
            setAlertMessage({
              message: "Password changed successfully",
              color: "green",
            })
          );
          await dispatch(setChangePasswordSpinner(false));
          await dispatch(
            setPasswords({
              old_password: "",
              new_password: "",
              c_password: "",
            })
          );
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setChangePasswordSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "You need to login first",
          color: "teal",
        })
      );
      await dispatch(setChangePasswordSpinner(false));
    }
    await setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 5000);
  };
};

// ----------------Stripe connect API---------------
export const connectWithStripe = (stripeToken) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/connect/account?stripe_id=${stripeToken.code}&grant_type=${stripeToken.scope}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/vnd.api+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setUserDataInState(response.user));
          await dispatch(
            setAlertMessage({
              message: "Stripe account connected",
              color: "green",
            })
          );
        }
      } catch (e) {
        // await dispatch(setAlertMessage({message:'Server error Please try again.',color:'red'}));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error !! Please refresh the page.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec

    await setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const disconnectStripe = () => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/remove/user/account?`, {
          method: "POST",
          headers: {
            "Content-Type": "application/vnd.api+json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          await dispatch(setStripeModal(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setStripeModal(false));
          await dispatch(setUserDataInState(response.user));
          await dispatch(
            setAlertMessage({
              message: "Stripe removed Successfully",
              color: "green",
            })
          );
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "red",
          })
        );
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error !! Please refresh the page.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec

    await setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const connectGoogleCalendar = (data) => {
  console.log(data);
  return async (dispatch, getState) => {
    var gapi = window.gapi;
    var CLIENT_ID =
      "651841694791-i9lf1c41irrjenkj05b0e6o0jt29k7ck.apps.googleusercontent.com";
    var DISCOVERY_DOCS = [
      "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
    ];
    var SCOPES = "https://www.googleapis.com/auth/calendar.events";

    gapi.load("client:auth2", () => {
      gapi.client.init({
        apiKey: "",
        clientId: CLIENT_ID,
        discoveryDocs: DISCOVERY_DOCS,
        scope: SCOPES,
      });
    });

    let { upcomingBookings } = getState().CProfileState;

    upcomingBookings.map((i) =>
      console.log(
        new Date(
          i.booking_date.split("-")[0] +
            " " +
            i.booking_date.split("-")[1] +
            " " +
            i.booking_date.split("-")[2] +
            "," +
            i.slot
        ).toISOString()
      )
    );
    gapi.auth2
      .getAuthInstance()
      .signIn()
      .then(() => {
        upcomingBookings.map((item) => {
          console.log(item);
          var request = gapi.client.calendar.events.insert({
            calendarId: "primary",
            resource: {
              summary: "Your Safe Space Appointment",
              location: item.counsellor.location,
              description: `counselling session with ${item.user.name}`,
              start: {
                dateTime: new Date(
                  item.booking_date.split("-")[0] +
                    " " +
                    item.booking_date.split("-")[1] +
                    " " +
                    item.booking_date.split("-")[2] +
                    "," +
                    item.slot
                ).toISOString(),
                timeZone: "America/Los_Angeles",
              },
              end: {
                dateTime: new Date(
                  item.booking_date.split("-")[0] +
                    " " +
                    item.booking_date.split("-")[1] +
                    " " +
                    item.booking_date.split("-")[2] +
                    "," +
                    item.slot
                ).toISOString(),
                timeZone: item.counsellor.timezone,
              },
              attendees: [
                { email: item.counsellor.email },
                { email: item.user.email },
              ],
              reminders: {
                useDefault: false,
                overrides: [
                  { method: "email", minutes: 24 * 60 },
                  { method: "popup", minutes: 10 },
                ],
              },
            },
          });

          request.execute((event) => {
            console.log(event);
            // window.open(event.htmlLink);
          });
        });
      });
  };
};

export const deleteuserAvatar = () => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setAvatarSpinner(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/delete/profile/image`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setAvatarSpinner(false));
        } else if (response.success) {
          await dispatch(setAvatarSpinner(false));
          await dispatch(
            setAlertMessage({
              message: "Profile picture deleted successfully",
              color: "green",
            })
          );
          await dispatch(setUserDataInState(response.user));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setAvatarSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error! Please refresh the page.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const getBookingsLength = () => {
  return async (dispatch) => {
    let token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/all/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        var response = await result.json();
        if (response.success) {
          dispatch(setAllAppointments(response.bookings));
        }
      } catch (e) {
        console.log(e);
      }
    }
  };
};

export const getUpcomingAppointments = () => {
  return async (dispatch) => {
    let token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        var response = await result.json();
        if (response.success) {
          dispatch(setUpcomingBookingsLength(response.upcoming.data));
        }
      } catch (e) {
        console.log(e);
      }
    }
  };
};

export function updateListing(data) {
  return async (dispatch, getState) => {
    await dispatch(setListingSpinner(true));
    const token = auth.getAccessToken();
    let bodyData = {
      params: data,
    };
    if (token) {
      try {
        let result = await fetch(`${__API__}/update/listing`, {
          method: "POST",
          headers: {
            "Content-Type": "application/vnd.api+json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
          body: JSON.stringify(bodyData),
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setListingSpinner(false));
        } else if (response.success) {
          await dispatch(setListingSpinner(false));
          await dispatch(showCoverPreview(false));
          await dispatch(
            setAlertMessage({
              message: "Listing updated successfully.",
              color: "green",
            })
          );
          response.listing_data["gallery_images"] = [];
          await dispatch(setManageListingData(response.listing_data));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setListingSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "You need to login first",
          color: "teal",
        })
      );
      await dispatch(setListingSpinner(false));
    }
    await setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 5000);
  };
}

export function fetchCategory() {
  return async (dispatch) => {
    try {
      let category = await fetch(`${__API__}/get/listing/category`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await category.json();
      if (!response.success) {
      } else if (response.success) {
        await dispatch(setListingCategories(response.categories));
      }
    } catch (e) {
      await dispatch(
        setAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchRegions() {
  return async (dispatch) => {
    try {
      let regions = await fetch(`${__API__}/get/listing/region`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await regions.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setListingsRegions(response.regions));
      }
    } catch (e) {
      await dispatch(
        setAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchLables() {
  return async (dispatch) => {
    try {
      let lables = await fetch(`${__API__}/get/listing/label`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await lables.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setListingsLables(response.labels));
      }
    } catch (e) {
      await dispatch(
        setAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export const removeGalleryImage = (imageId) => {
  return async (dispatch, getState) => {
    let token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/delete/gallery/` + imageId, {
          method: "POST",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        var response = await result.json();
        if (response.success) {
          await dispatch(
            setAlertMessage({ message: "Images Removed successfully" })
          );
          let { listing_data } = getState().selectState;
          listing_data["gallery"] = listing_data["gallery"].filter(
            (i) => i.id !== imageId
          );
          await dispatch(setManageListingData(listing_data));
        }
      } catch (e) {
        console.log(e);
      }
    }
    await setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 5000);
  };
};
//---> exporting multiple functions and actions
export const actions = {
  updateProfile,
  changePassword,
  connectWithStripe,
  connectGoogleCalendar,
  updateAvatar,
  setAlertMessage,
  setPasswords,
  setHeader,
  setUserDataInState,
  deleteuserAvatar,
  getUpcomingAppointments,
  getBookingsLength,
  setStripeModal,
  disconnectStripe,
  setMenuHover,
  setCounsellorLocation,
  setListingSpinner,
  setManageListingData,
  setListingsData,
  updateListing,
  fetchCategory,
  fetchLables,
  fetchRegions,
  setImagePreviews,
  removeGalleryImage,
  setSiteAlertMessage,
  showCoverPreview,
};

//---> defining the initialState for state variables

const initialState = {
  profileSpinner: false,
  avatarSpinner: false,
  changePasswordSpinner: false,
  password: {
    old_password: "",
    new_password: "",
    c_password: "",
  },
  topHeader: ["Profile"],
  allBookings: [],
  upcomingBookings: [],
  removeStripeModal: false,
  listingSpinner: false,
  listing_lables: [],
  listing_categories: [],
  listing_regions: [],
  preview: [],
  cover_change: false,
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_C_PROFILE_UPCOMING_APPOINTMENTS_LENGTH]: (state, action) => {
    return {
      ...state,
      upcomingBookings: action.payload,
    };
  },

  [SET_C_PROFILE_ALL_APPOINTMENTS]: (state, action) => {
    console.log(action.payload);
    return {
      ...state,
      allBookings: action.payload,
    };
  },

  [CPROFILE_P_SET_AVATAR_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      avatarSpinner: action.payload,
    };
  },

  [CPROFILE_P_SET_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      profileSpinner: action.payload,
    };
  },

  [SET_CPROFILE_COUNSELLOR_PASSWORD]: (state, action) => {
    return {
      ...state,
      password: action.payload,
    };
  },

  [SET_CPROFILE_CHANGE_PASSWORD_SPINNER]: (state, action) => {
    return {
      ...state,
      changePasswordSpinner: action.payload,
    };
  },
  [SET_CPROFILE_TOP_HEADER]: (state, action) => {
    return {
      ...state,
      topHeader: action.payload,
    };
  },

  [SET_REMOVE_STRIPE_ACCOUNT_MODAL_STATUS]: (state, action) => {
    return {
      ...state,
      removeStripeModal: action.payload,
    };
  },
  [SET_UPDATE_LISTING_DATA_SPINNER]: (state, action) => {
    return {
      ...state,
      listingSpinner: action.payload,
    };
  },
  [CPROFILE_SET_LISTINGS_CATEGORY_DATA]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["category_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].category_name;
      delete action.payload[i].id;
    }
    return {
      ...state,
      listing_categories: action.payload,
    };
  },
  [CPROFILE_SET_LISTINGS_LABELS_DATA]: (state, action) => {
    return {
      ...state,
      listing_lables: action.payload,
    };
  },
  [CPROFILE_SET_LISTINGS_REGIONS_DATA]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["region_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].region_name;
      delete action.payload[i].id;
    }
    return {
      ...state,
      listing_regions: action.payload,
    };
  },
  [CPROFILE_SET_IMAGE_PREVIEW_ARRAY]: (state, action) => {
    return {
      ...state,
      preview: action.payload,
    };
  },
  [MANAGE_LISTING_SHOW_COVER_IMAGE_PREVIEW]: (state, action) => {
    return {
      ...state,
      cover_change: action.payload,
    };
  },
};

export default function CProfileReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
