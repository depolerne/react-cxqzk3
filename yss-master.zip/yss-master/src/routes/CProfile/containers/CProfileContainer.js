import React from 'react';
import {
    actions,connectWithStripe
} from '../modules/CProfile';

import { bindActionCreators } from 'redux';
import CProfileView from '../components/CProfileView';
import { connect } from 'react-redux';
import { withJob } from 'react-jobs';
import RedBox from 'redbox-react';

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});

const mapStateToProps = (state) => ({
    selectState: state.selectState,
    CProfileState: state.CProfileState,
    auth:state.auth
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => {
        dispatch(connectWithStripe());
    },
    /* eslint-disable */ ErrorComponent: ({ error }) => __DEV__ ? <RedBox error={error} /> : null,
})(CProfileView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
