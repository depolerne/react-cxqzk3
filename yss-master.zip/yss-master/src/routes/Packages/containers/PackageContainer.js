import React from "react";
import { actions, getPackages } from "../modules/Packages";
import { bindActionCreators } from "redux";
import PackageView from "../components/PackageView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  PackageState: state.PackageState,
  EditPackageState: state.EditPackageState,
  selectState: state.selectState,
  CreatePackageState: state.CreatePackageState,
});

const withJobComponent = withJob({
  work: async ({ dispatch}) => {
    // await dispatch(getPackages())
  },
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(PackageView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
