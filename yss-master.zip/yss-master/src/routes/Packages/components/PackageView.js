import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import Spinner from "../../../components/Spinner/Spinner";
import auth from "../../../helpers/auth";
import PackageDetails from "./PackageDetails";
import { setTimeLable } from "../../../helpers/checkSlots";

export class PackegeView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      loadingSpinner: false,
      packages: "",
      currentPage: 1,
      pages: "",
      totalpage: [],
      last_page: 0,
      packageData: {},
      details: false,
    };
    this.loadPackages = this.loadPackages.bind(this);
    this.prevPage = this.prevPage.bind(this);
    this.nextPage = this.nextPage.bind(this);
    this.changePage = this.changePage.bind(this);
    this.setPageClass = this.setPageClass.bind(this);
    this.openDetails = this.openDetails.bind(this);
  }

  setPageClass(value) {
    if (this.state.currentPage === value) {
      return true;
    } else {
      return false;
    }
  }

  async componentDidMount() {
    await this.props.setMenuHover('packages')
    await this.loadPackages();
    let body=document.body;
    body.className="dashboard_packages"; 
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  async prevPage(e) {
    let num = (await parseInt(this.state.currentPage)) - 1;
    if (this.state.currentPage > 1) {
      await this.setState({ currentPage: num });
      await this.loadPackages();
    }
  }

  async nextPage() {
    let num = (await parseInt(this.state.currentPage)) + 1;
    if (this.state.currentPage < this.state.last_page);
    this.setState({ currentPage: num });
    await this.loadPackages();
  }

  async changePage(e) {
    let value = await parseInt(e.target.name);
    await this.setState({ currentPage: value });
    await this.loadPackages();
  }

  async loadPackages() {
    this.setState({ loadingSpinner: true });
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/getPackagesByCounsellorId?page=${this.state.currentPage}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (response.success) {
          this.setState({
            loadingSpinner: false,
            packages: response.packages.data,
            totalpage: [...Array(response.packages.last_page).keys()],
            last_page: response.packages.last_page,
          });
          await this.props.setPackagesData(response.packages);
        } else if (!response.success) {
          this.setState({
            loadingSpinner: false,
            totalpages: [],
          });
        }
      } catch (e) {
        console.log(e);
        this.setState({ loadingSpinner: false });
      }
    }
  }

  openDetails(data) {
    this.setState({ packageData: data, details: !this.state.details });
  }

  render() {
    let { currentPage, packages, totalpage, last_page } = this.state;
    packages = Array.from(packages);

    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            {this.state.details ? (
              <PackageDetails
                packageData={this.state.packageData}
                cancelEvent={() => this.openDetails()}
                match={this.props.match}
              />
            ) : null}
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  <span>Packages</span>
                </h3>
              </div>
              
              <div className="middle__content">
                {this.state.loadingSpinner ? (
                  <Spinner text={"Fetching Packages..."} />
                ) : packages === undefined || packages.length == 0 ? (
                  <div className="no__packages">
                    <p>You have not created any packages yet</p>
                    <div className="create_pack_button btn clearfix">
                      <Link to="/coach/dashboard/createpackage">
                        Create Package
                      </Link>
                    </div>
                  </div>
                ) : (
                  <ul className="admin_packages_lists">
                    {packages !== undefined
                      ? packages.map((item, i) => {
                          return (
                            <li key={i}>
                              <div className="pack__info">
                                <div className="pack__detail">
                                  <div className="pack__title">
                                    <h3>{item.package_name.slice(0, 20)}</h3>
                                    <h3 className="text_nav_blue">
                                      £{item.amount}
                                    </h3>
                                  </div>
                                  <div className="pack__text">
                                    <p>
                                      {item.package_description.slice(0, 130)}
                                      {"..."}
                                      <Link
                                        to="#"
                                        onClick={() => this.openDetails(item)}
                                        className="read_more"
                                      >
                                        read more
                                      </Link>
                                    </p>
                                  </div>
                                  <div className="pack_history">
                                    <p>
                                      Duration:{" "}
                                      <span>
                                        {item.session_hours} {" : "}{" "}
                                        {item.session_minutes}{" "}
                                        {setTimeLable(
                                          item.session_hours,
                                          item.session_minutes
                                        )
                                          ? "Minutes"
                                          : "Hours"}
                                      </span>
                                    </p>
                                    <p className="text-blue-800">
                                    {item.no_of_slots > 1 ? <span>{`[${item.no_of_slots} Sessions]`}</span> :null}
                                    </p>
                                  </div>
                                  <div className="btn book_pack bg_blue text-white">
                                    <Link
                                      to={`/coach/dashboard/editpackage/${item.id}`}
                                    >
                                      Edit
                                    </Link>
                                  </div>
                                </div>
                              </div>
                            </li>
                          );
                        })
                      : null}
                    {currentPage < last_page ||
                    packages.length % 6 == 0 ? null : (
                      <li>
                        <div className="create_new_pack pack__info">
                          <Link
                            className="bg_blue text-white py-3 px-6"
                            to="/coach/dashboard/createpackage"
                          >
                            Create New Package
                          </Link>
                        </div>
                      </li>
                    )}
                  </ul>
                )}
              </div>
              {this.state.packages.length == 0 || last_page == 1 ? null : (
                <div className="site_pagination">
                  <ul>
                    <li className={currentPage > 1 ? "prev" : "disable"}>
                      <Link to="#" onClick={this.prevPage}>
                        &lt; Prev{" "}
                      </Link>
                    </li>
                    {totalpage.map((number, i) => {
                      return (
                        <li className="prev" key={i}>
                          <Link
                            to="#"
                            className={
                              this.setPageClass(number + 1)
                                ? "bg-blue-900 rounded-full text-white"
                                : ""
                            }
                            name={number + 1}
                            onClick={this.changePage}
                          >
                            {number + 1}
                          </Link>
                        </li>
                      );
                    })}
                    <li
                      className={currentPage < last_page ? "next" : "disable"}
                    >
                      <Link to="#" onClick={this.nextPage}>
                        Next &gt;{" "}
                      </Link>
                    </li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default PackegeView;