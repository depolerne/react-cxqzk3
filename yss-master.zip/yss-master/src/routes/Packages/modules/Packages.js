import auth from "../../../helpers/auth";
import _without from "lodash/without";
import _remove from "lodash/remove";
import _get from "lodash/get";
import { setMenuHover } from "../../selectWrapper/modules/select";
//---> Defining types for different actions

export const PACKAGE_P_SET_PACKAGE_DATA = "PACKAGE_P_SET_PACKAGE_DATA";
export const PACKAGE_P_SET_IS_ERR_MESSAGE = "PACKAGE_P_SET_IS_ERR_MESSAGE";
export const PACKAGE_P_SET_SPINNER_STATUS = "PACKAGE_P_SET_SPINNER_STATUS";

// ---> Defining actions

export const setPackagesData = (jsonData) => {
  return {
    type: PACKAGE_P_SET_PACKAGE_DATA,
    payload: jsonData,
  };
};

export const setIsErrMessage = (errValue) => {
  return {
    type: PACKAGE_P_SET_IS_ERR_MESSAGE,
    payload: errValue,
  };
};

export const setPackageSpinnerStatus = (status) => {
  return {
    type: PACKAGE_P_SET_SPINNER_STATUS,
    payload: status,
  };
};

//---> exporting the functions and actions
export const actions = {
  setPackagesData,
  setIsErrMessage,
  setMenuHover
};

//---> defining the initial State for state variables

const initialState = {
  IsErrMessage: { message: "", color: "" },
  packageData: "",
  packageSpinnerStatus: false,
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [PACKAGE_P_SET_PACKAGE_DATA]: (state, action) => {
    return {
      ...state,
      packageData: action.payload,
    };
  },
  [PACKAGE_P_SET_IS_ERR_MESSAGE]: (state, action) => {
    return {
      ...state,
      IsErrMessage: action.payload,
    };
  },
  [PACKAGE_P_SET_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      packageSpinnerStatus: action.payload,
    };
  },
};

export const PackageReducer = (state = initialState, action) => {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
};

export default PackageReducer;
