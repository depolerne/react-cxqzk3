import {
    actions
} from '../modules/Listing';
import { bindActionCreators } from 'redux';
import ListingView from '../components/ListingView';
import { connect } from 'react-redux'

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});

const mapStateToProps = (state) => ({
    ListingState:state.ListingState,
    selectState:state.selectState
});
  
export default connect(mapStateToProps, mapDispatchToProps)(ListingView);
