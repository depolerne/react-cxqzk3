import fetch from "isomorphic-fetch";
import auth from "../../../helpers/auth";
import { setSiteAlertMessage } from "../../SiteWrapper/modules/site";
import { setSelectedSlots } from "../../Checkout/modules/Checkout";
//---> Defining types for different actions

export const FETCH_LISTING_SET_DATA = "FETCH_LISTING_SET_DATA";
export const SET_FETCH_LISTING_SPINNER_STATUS =
  "SET_FETCH_LISTING_SPINNER_STATUS";
export const SET_FETCH_LISTING_PERCENTAGE_VALUE =
  "SET_FETCH_LISTING_PERCENTAGE_VALUE";
export const FETCH_SET_LISTING_PACKAGES_DATA =
  "FETCH_SET_LISTING_PACKAGES_DATA";
export const SET_LISTINGS_SET_AUTH_MODAL = "SET_LISTINGS_SET_AUTH_MODAL";
export const LISTINGS_SET_BOOKING_MODAL = "LISTINGS_SET_BOOKING_MODAL";
export const LISTINGS_SET_SELECTED_PACKAGE_DATA =
  "LISTINGS_SET_SELECTED_PACKAGE_DATA";
export const SET_LISTINGGS_SET_PACKAGE_DETAILS =
  "SET_LISTINGGS_SET_PACKAGE_DETAILS";
export const SET_LISTING_ID = "SET_LISTING_ID";
export const SET_FETCH_PACKAGE_SPINNER_STATUS =
  "SET_FETCH_PACKAGE_SPINNER_STATUS";
export const SET_COUNSELLOR_AVAILABILITY = "SET_COUNSELLOR_AVAILABILITY";
export const SET_COUNSELLOR_REVIEW_STATUS = "SET_COUNSELLOR_REVIEW_STATUS";
export const SET_REVIEW_MODAL_FLAG = "SET_REVIEW_MODAL_FLAG";
export const SET_LISTING_REVIEWS_DATA = "SET_LISTING_REVIEWS_DATA";
export const SET_REVIEW_LISTING_ID = "SET_REVIEW_LISTING_ID";
export const SET_READ_REVIEW_FLAG = "SET_READ_REVIEW_FLAG";
export const SET_UPDATED_REVIEW_DATA = "SET_UPDATED_REVIEW_DATA";
export const SET_ALLOW_TO_REVIEW = "SET_ALLOW_TO_REVIEW";
export const SET_READ_REVIEW_DATA = "SET_READ_REVIEW_DATA"
//---> Defining Actions to set state variables
export function readReview(flag) {
  return {
    type: SET_READ_REVIEW_FLAG,
    payload: flag,
  };
}

export function setAllowtoreview(value) {
  return {
    type: SET_ALLOW_TO_REVIEW,
    payload: value,
  };
}

export function readReiewData(params) {
  return {
    type: SET_READ_REVIEW_DATA,
    payload: params,
  };
}

export const setListingsData = (data) => {
  return {
    type: FETCH_LISTING_SET_DATA,
    payload: data,
  };
};

export const setListingId = (id) => {
  return {
    type: SET_LISTING_ID,
    payload: id,
  };
};

export function setAuthModal(flag) {
  return {
    type: SET_LISTINGS_SET_AUTH_MODAL,
    payload: flag,
  };
}

export const setPackageSpinner = (flag) => {
  return {
    type: SET_FETCH_PACKAGE_SPINNER_STATUS,
    payload: flag,
  };
};

export const setFetchListingSpinner = (status) => {
  return {
    type: SET_FETCH_LISTING_SPINNER_STATUS,
    payload: status,
  };
};

export function setUpdatedReviewData(params) {
  return {
    type: SET_UPDATED_REVIEW_DATA,
    payload: params,
  };
}

export const setListingPercentage = (value) => {
  return {
    type: SET_FETCH_LISTING_PERCENTAGE_VALUE,
    payload: value,
  };
};

export const setListingPackages = (packages) => {
  return {
    type: FETCH_SET_LISTING_PACKAGES_DATA,
    payload: packages,
  };
};

export function setBookingModal(flag) {
  return {
    type: LISTINGS_SET_BOOKING_MODAL,
    payload: flag,
  };
}

export const setBookingPackage = (data) => {
  return {
    type: LISTINGS_SET_SELECTED_PACKAGE_DATA,
    payload: data,
  };
};

export const setPackageDetails = (data) => {
  return {
    type: SET_LISTINGGS_SET_PACKAGE_DETAILS,
    payload: data,
  };
};

export function setCounsellorAvail(data) {
  return {
    type: SET_COUNSELLOR_AVAILABILITY,
    payload: data,
  };
}

export function setReviewStatus(status) {
  return {
    type: SET_COUNSELLOR_REVIEW_STATUS,
    payload: status,
  };
}

export function setReviewModal(flag) {
  return {
    type: SET_REVIEW_MODAL_FLAG,
    payload: flag,
  };
}

export function setReviews(data) {
  return {
    type: SET_LISTING_REVIEWS_DATA,
    payload: data,
  };
}

//---> API to fetch individual Package Data by Id
export const fetchListing = (listing_id) => {
  return async (dispatch, getState) => {
    await dispatch(setSiteAlertMessage(""));
    await dispatch(setFetchListingSpinner(true));
    const token = auth.getAccessToken();
    try {
      let result = await fetch(`${__API__}/get/listing/by/id/${listing_id}`, {
        method: "GET",
        cache: "no-cache",
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          Accept: "application/json",
          Authorization: `Bearer ` + token,
        },
      });
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
        await dispatch(setFetchListingSpinner(false));
      } else if (response.success) {
        const {
          userData: { id },
        } = getState().selectState;
        await dispatch(setListingId(response.data.id));
        await dispatch(setListingsData(response.data));
        await dispatch(setListingPercentage(response.profile_percentage));
        await dispatch(setFetchListingSpinner(false));
        if (auth.isAuthenticated) {
          await dispatch(checkCounsellorAvail(id, token));
        }

        return response.data;
      }
    } catch (e) {
      dispatch(
        setSiteAlertMessage({
          message: "You need to login first",
          color: "teal",
        })
      );
      await dispatch(setFetchListingSpinner(false));
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchListingPackages = (page) => {
  return async (dispatch, getState) => {
    await dispatch(setSiteAlertMessage(""));
    await dispatch(setPackageSpinner(true));
    const token = auth.getAccessToken();
    const { listing_id } = getState().ListingState;
    try {
      let result = await fetch(
        `${__API__}/get/counsellor/packages?listing_id=${listing_id}&page=${page}&limit=${2}`,
        {
          method: "GET",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        // Object.keys(response.errors).map((item) => {
        //   dispatch(
        //     setSiteAlertMessage({
        //       message: response.errors[item][0],
        //       color: "teal",
        //     })
        //   );
        // });
        await dispatch(setPackageSpinner(false));
      } else if (response.success) {
        await dispatch(setListingPackages(response.packages));
        await dispatch(setPackageSpinner(false));
      }
    } catch (e) {
      dispatch(
        setSiteAlertMessage({
          message: "Server error please try again.",
          color: "teal",
        })
      );
      await dispatch(setPackageSpinner(false));
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const checkCounsellorAvail = (user_id, token) => {
  return async (dispatch, getState) => {
    const {
      listing_data: {
        user: { id },
      },
    } = await getState().ListingState;
    try {

      user_id = (user_id == undefined) ? auth.getUserId() : user_id;

      let result = await fetch(
        `${__API__}/get/availability?user_id=${user_id}&counsellor_id=${id}`,
        {
          method: "POST",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setCounsellorAvail(response.data));
      }
    } catch (e) {
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const checkReviewStatus = () => {
  return async (dispatch, getState) => {
    const { listing_id } = await getState().ListingState;
    const token = auth.getAccessToken();
    if (auth.isAuthenticated) {
      try {
        let result = await fetch(
          `${__API__}/check/if/listing/rated?listing_id=${listing_id}`,
          {
            method: "GET",
            cache: "no-cache",
            headers: {
              "Content-Type": "application/json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setSiteAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setReviewStatus(response.rating_flag));
          await dispatch(setAllowtoreview(response.allow_to_review));
        }
      } catch (e) {
        console.log(e);
      }
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchReviews = (page) => {
  return async (dispatch, getState) => {
    const { listing_id } = await getState().ListingState;
    try {
      let result = await fetch(
        `${__API__}/get/all/reviews?listing_id=${listing_id}&page=${page}`,
        {
          method: "GET",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setReviews(response.reviews));
      }
    } catch (e) {
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export function saveReviewRating(data) {
  console.log(data);
  return async (dispatch, getState) => {
    const { listing_id } = getState().ListingState;
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/reviewrating?rating=${data.rating}&review=${data.review}&listing_id=${listing_id}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        console.log(response);
        if (!response.success) {
          await dispatch(setReviewModal(""));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setReviewModal(""));
          await dispatch(
            setSiteAlertMessage({
              message: "Rating saved successfully",
              color: "green",
            })
          );
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
    }
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function updateReview(data) {
  return async (dispatch, getState) => {
    const { listing_id } = getState().ListingState;
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/update/review?review_id=${data.id}&rating=${data.rating}&review=${data.review}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        console.log(response);
        if (!response.success) {
          await dispatch(setReviewModal(""));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setReviewModal(""));
          await dispatch(
            setSiteAlertMessage({
              message: "Rating saved successfully",
              color: "green",
            })
          );
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
    }
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

//---> exporting multiple functions and actions

export const actions = {
  fetchListing,
  setListingsData,
  setFetchListingSpinner,
  setListingPercentage,
  setSiteAlertMessage,
  fetchListingPackages,
  setBookingModal,
  setAuthModal,
  setBookingPackage,
  setPackageDetails,
  setListingPackages,
  setPackageSpinner,
  setListingId,
  setSelectedSlots,
  checkCounsellorAvail,
  setCounsellorAvail,
  checkReviewStatus,
  fetchReviews,
  saveReviewRating,
  readReview,
  setAllowtoreview,
  readReiewData,
  setReviewModal,
  setUpdatedReviewData,
  updateReview
};

//---> defining the initialState for state variables

const initialState = {
  listing_data: {},
  fetch_package_spinner: false,
  fetch_listing_spinner: false,
  listing_percentage: "",
  authModal: "",
  bookingModal: "",
  reviewModal: "",
  packageData: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
    total: 0,
  },
  reviews: { data: [], last_page: 0, currentPage: 1, totalPage: [], total: 0 },
  targetPackage: {},
  packageDetails: {},
  listing_id: "",
  rating_flag: "",
  canReview: "",
  review_listing_id: "",
  isAvailable: false,
  readReviewData: {},
  updatedReviewData: {},
};

const ACTION_HANDLERS = {
  [FETCH_SET_LISTING_PACKAGES_DATA]: (state, action) => {
    return {
      ...state,
      packageData: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
        total: action.payload.total,
      },
    };
  },

  [LISTINGS_SET_BOOKING_MODAL]: (state, action) => {
    return {
      ...state,
      bookingModal: action.payload,
    };
  },

  [FETCH_LISTING_SET_DATA]: (state, action) => {
    
    return {
      ...state,
      listing_data: action.payload,
    };
  },
  [SET_FETCH_LISTING_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      fetch_listing_spinner: action.payload,
    };
  },
  [SET_FETCH_PACKAGE_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      fetch_package_spinner: action.payload,
    };
  },
  [SET_FETCH_LISTING_PERCENTAGE_VALUE]: (state, action) => {
    return {
      ...state,
      listing_percentage: action.payload,
    };
  },
  [SET_LISTINGS_SET_AUTH_MODAL]: (state, action) => {
    return {
      ...state,
      authModal: action.payload,
    };
  },
  [LISTINGS_SET_SELECTED_PACKAGE_DATA]: (state, action) => {
    return {
      ...state,
      targetPackage: action.payload,
    };
  },
  [SET_LISTINGGS_SET_PACKAGE_DETAILS]: (state, action) => {
    return {
      ...state,
      packageDetails: action.payload,
    };
  },
  [SET_LISTING_ID]: (state, action) => {
    return {
      ...state,
      listing_id: action.payload,
    };
  },
  [SET_COUNSELLOR_AVAILABILITY]: (state, action) => {
    return {
      ...state,
      isAvailable: action.payload,
    };
  },
  [SET_COUNSELLOR_REVIEW_STATUS]: (state, action) => {
    return {
      ...state,
      rating_flag: action.payload,
    };
  },
  [SET_LISTING_REVIEWS_DATA]: (state, action) => {
    
    return {
      ...state,
      reviews: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
        total: action.payload.total,
      },
    };
  },
  [SET_REVIEW_MODAL_FLAG]: (state, action) => {
    return {
      ...state,
      reviewModal: action.payload,
    };
  },
  [SET_UPDATED_REVIEW_DATA]: (state, action) => {
    return {
      ...state,
      updatedReviewData: action.payload,
    };
  },
  [SET_READ_REVIEW_DATA]:(state,action)=>{
    return {
      ...state,
      readReviewData: action.payload,
    };
  },
  [SET_ALLOW_TO_REVIEW]:(state,action)=>{
    return {
      ...state,
      canReview: action.payload,
    };
  }
};

export default function ListingReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
