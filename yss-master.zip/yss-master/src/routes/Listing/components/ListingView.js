import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import Spinner from "../../../components/Spinner/Spinner";
import auth from "../../../helpers/auth";
import ReactPlayer from "react-player";
import { setTimeLable } from "../../../helpers/checkSlots";
import SignUpModal from "./SignUpModal";
import LoginModal from "./LoginModal";
import AuthOTPModal from "./AuthOTPModal";
import ReviewModal from "../../../components/Modals/ReviewModal/ReviewModal";
import ReadReview from "../../../components/Modals/ReviewModal/ReadReview";
import EditReview from "../../../components/Modals/ReviewModal/EditReview";
import CheckoutView from "../../Checkout/components/CheckoutView";
import BookingView from "../../Checkout/components/BookingView";
import { PackageDetails } from "../../Packages/components/PackageDetails";
import SimpleReactLightbox from "simple-react-lightbox";
import { SRLWrapper } from "simple-react-lightbox";
import ReactStars from "react-rating-stars-component";
import AllReview from "../../../components/Modals/ReviewModal/AllReview";

export class ListingView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showDetails: false,
      viewAllReviews: false,
    };
    this.bookNow = this.bookNow.bind(this);
    this.scrollToPackages = this.scrollToPackages.bind(this);
    this.openDetails = this.openDetails.bind(this);
    this.changePage = this.changePage.bind(this);
    this.prevPage = this.prevPage.bind(this);
    this.nextPage = this.nextPage.bind(this);
    this.setPageClass = this.setPageClass.bind(this);
    this.writeReview = this.writeReview.bind(this);
    this.myDivToFocus = React.createRef();
  }

  async componentDidMount() {
    let body = document.body;
    body.className = "listing_view";

    window.scrollTo(0, 0);
    let { params } = this.props.match;
    this.props.fetchListing(params.id);
    this.props.setListingId(params.id);
    if (auth.isAuthenticated) {
      this.props.checkReviewStatus();
    }
    this.props.fetchListingPackages(1);
    this.props.fetchReviews(1);
    document.addEventListener("keyup", (e) => {
      if (e.keyCode === 27) {
        this.props.setBookingModal("");
        this.props.setSelectedSlots({});
        this.props.setAuthModal("");
        this.props.openReviewModal(false);
      }
    });
    const {
      userData: { id },
    } = await this.props.selectState;
    const token = auth.getAccessToken();
    //this.props.checkCounsellorAvail(id,token)
  }

  bookNow(item) {
    this.setState({ showDetails: false });
    if (auth.isAuthenticated) {
      // let { packageData } = this.props.ListingState;
      // temp = packageData.data.filter((item) => item.id == id);
      this.props.setBookingPackage(item);
      this.props.setBookingModal("booking");
    } else {
      this.props.setAuthModal("login");
    }
  }

  scrollToPackages() {
    if (this.myDivToFocus.current) {
      this.myDivToFocus.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
  }

  openDetails(data) {
    this.setState({
      packageDetails: data,
      showDetails: !this.state.showDetails,
    });
  }

  async prevPage(e) {
    let { packageData } = this.props.ListingState;
    let value = (await parseInt(packageData.currentPage)) - 1;
    if (packageData.currentPage > 1) {
      packageData["currentPage"] = value;
      this.props.fetchListingPackages(value);
    }
  }

  async nextPage() {
    let { packageData } = this.props.ListingState;
    let value = (await parseInt(packageData.currentPage)) + 1;
    if (value <= packageData.last_page) {
      // packageData[currentPage] = value;
      this.props.fetchListingPackages(value);
    }
  }

  async changePage(e) {
    let { packageData } = this.props.ListingState;
    let value = await parseInt(e.target.name);
    packageData["currentPage"] = value;
    this.props.fetchListingPackages(value);
  }

  setPageClass(value) {
    let { packageData } = this.props.ListingState;
    if (packageData.currentPage === value) {
      return true;
    } else {
      return false;
    }
  }

  writeReview() {
    if (auth.isAuthenticated) {
      this.props.setReviewModal("give");
    } else {
      this.props.setAuthModal("login");
    }
  }

  render() {
    const {
      listing_data,
      fetch_listing_spinner,
      packageData,
      authModal,
      bookingModal,
      fetch_package_spinner,
      isAvailable,
      reviewModal,
      rating_flag,
      reviews,
      readReview,
      canReview,
      readAllReviews,
      packageData: { data, last_page, currentPage, totalPage },
    } = this.props.ListingState;
    let { showDetails, packageDetails, viewAllReviews } = this.state;

    const Labels = (
      <ul className="tag_lists">
        {listing_data.multilabel &&
          listing_data.multilabel.map((i, j) => (
            <li key={j}>
              <i className="fas fa-tag"></i> {i.label_name}
            </li>
          ))}
      </ul>
    );

    const CreateAccountBlock = !auth.isAuthenticated ? (
      <div className="information_block listing__description create-account__block">
        <span className="description__text">
          If you want to get started quikly please create an account so you can
          view appointments available today
        </span>
        <span className="description__btn">
          <Link
            to="#"
            className="create-account__btn text-center"
            onClick={() => this.props.setAuthModal("signup")}
          >
            Create account
          </Link>
        </span>
      </div>
    ) : null;

    const AvailableBlock =
      isAvailable && auth.isAuthenticated ? (
        <div className="information_block listing__description flex">
          <span>
            Your coach is available today{" "}
            <Link
              to="#"
              className="text-blue-800 font-bold"
              onClick={() => this.scrollToPackages()}
            >
              click here
            </Link>{" "}
            to book an Appointment.
          </span>
          <br />
        </div>
      ) : null;

    return (
      <Fragment>
        <SimpleReactLightbox>
          {!fetch_listing_spinner ? (
            <div className="main-content yss-site--main__content listing__view--data">
              {authModal === "login" ? (
                <LoginModal />
              ) : authModal === "signup" ? (
                <SignUpModal />
              ) : authModal === "OTP" ? (
                <AuthOTPModal
                  cancelEvent={() => this.props.setAuthModal("")}
                  history={this.props.history}
                />
              ) : null}
              {bookingModal == "booking" ? (
                <BookingView
                  closeEvent={() => {
                    this.props.setBookingModal("");
                    this.props.setSelectedSlots({});
                    document.body.classList.remove('booking_modal');
                  }}
                />
              ) : bookingModal == "checkout" ? (
                <CheckoutView history={this.props.history} />
              ) : null}
              {showDetails ? (
                <PackageDetails
                  bookEvent={(id) => this.bookNow(id)}
                  cancelEvent={() => this.openDetails()}
                  packageData={packageDetails}
                  match={this.props.match}
                />
              ) : null}
              {reviewModal == "give" ? (
                <ReviewModal />
              ) : reviewModal == "read" ? (
                <ReadReview />
              ) : reviewModal == "all" ? (
                <AllReview />
              ) : reviewModal == "edit" ? (
                <EditReview />
              ) : null}

              <div
                className="main__top-banner cover__pic--wrapper bg-cover"
                style={{
                  backgroundImage: `url(${
                    __IMG_URL__ + listing_data.cover_img
                  })`,
                }}
              >
                <div className="main_banner__wrapper cover__content page__content">
                  <div className="coevr__left w-full lg:w-3/5 lg:pr-2">
                    <div className="verify__status">
                      <a href="#" className="claimed-ribbon popup-trigger">
                        <span className="ion-checkmark-circled"></span>
                        <span className="tooltip">Verified Listing</span>
                      </a>
                    </div>
                    <h2 className="listing__name">
                      {listing_data.listing_name}
                    </h2>
                    <div className="mt-4 listing__location">
                      {listing_data.location}
                    </div>
                    <div className="mt-4 listing_category">
                      {listing_data.listing_category ? (
                        <span className="category__name">
                          <a href="#">
                            {listing_data.listing_category.category_name}
                          </a>
                        </span>
                      ) : null}
                    </div>
                    <div className="mt-4 listing-rating listing-rating--card">
                      {/* {listing_data.avg_rating ? (
                        <h1 className="text-yellow-600 font-bold text-xl">
                          {"(" +
                            parseFloat(listing_data.avg_rating).toFixed(1) +
                            ")"}
                        </h1>
                      ) : null} */}
                      {listing_data && (
                        <ReactStars
                          edit={false}
                          isHalf={true}
                          value={parseFloat(listing_data.avg_rating).toFixed(2)}
                          activeColor="#eb8a2f"
                          color="#fff"
                        />
                      )}
                      {listing_data.total_reviews > 0 && (
                        <span className="listing-rating-count listing-rating-count--card">
                          <Link
                            to="#"
                            className="review__counter"
                            onClick={() => this.props.setReviewModal("all")}
                          >
                            {listing_data.total_reviews} Reviews
                          </Link>
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="coevr__right w-full lg:w-2/5 lg:pl-2">
                    {listing_data.user &&
                    listing_data.user.profile_percentage === 100 &&
                    auth.getUserType() !== "counsellor" ? (
                      <div className="write__review lg:text-right btn">
                        <Link
                          className="w-auto"
                          to="#"
                          onClick={() => this.scrollToPackages()}
                        >
                          Book Appointment
                        </Link>
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
              {fetch_listing_spinner ? (
                <Spinner />
              ) : (
                <div className="page__content">
                  <form className="listing__preview">
                    <div className="job_listing_preview single-job_listing">
                      <div className="listing-other-details lg:flex">
                        <div className="w-full lg:w-2/3 lg:pr-4">
                          {CreateAccountBlock}
                          {AvailableBlock}
                          <div
                            className="information_block listing__description"
                            dangerouslySetInnerHTML={{
                              __html: listing_data.description,
                            }}
                          ></div>
                          {listing_data.video_url ? (
                            <div className="information_block listing__video">
                              <h2>
                                <i className="fas fa-film"></i> Video
                              </h2>

                              <div className="video__block">
                                <ReactPlayer url={listing_data.video_url} />
                              </div>
                            </div>
                          ) : null}

                          {CreateAccountBlock}

                          <div className="information_block review__block">
                            <h2>
                              <i className="fas fa-notes-medical"></i> Reviews
                            </h2>
                            <div className="write__review btn">
                              {canReview === 1 ? (
                                rating_flag === 0 ? (
                                  <Link
                                    className="text-white"
                                    to="#"
                                    onClick={() => this.writeReview()}
                                  >
                                    Write Review
                                  </Link>
                                ) : (
                                  <h1>Already Reviewed</h1>
                                )
                              ) : null}
                            </div>
                            {reviews.data && reviews.data.length >= 1 ? (
                              <div className="packages__list">
                                <ul className=" md:flex md:flex-wrap">
                                  {reviews.data.slice(0, 2).map((item) => (
                                    <li className="mb-6" key={item.id}>
                                      <div className="pack__info">
                                        <div className="pack__detail">
                                          <div className="pack__title">
                                            <h3>{item.user.name}</h3>
                                          </div>
                                          <div className="pack__text">
                                            <p>
                                              {(item.review) ? item.review.slice(0, 150) : ""}
                                              <Link
                                                className="read_more"
                                                to="#"
                                                onClick={() => {
                                                  this.props.setReviewModal(
                                                    "read"
                                                  );
                                                  this.props.readReiewData(
                                                    item
                                                  );
                                                }}
                                              >
                                                { (item.review) ? item.review.length > 150
                                                  ? "... read more"
                                                  : null : null }
                                              </Link>
                                            </p>
                                          </div>
                                          <div className="mt-4 listing-rating listing-rating--card">
                                            {/* {item.rating ? (
                                              <h1 className="text-yellow-700 font-bold text-xl my-auto">
                                                {"(" +
                                                  parseFloat(
                                                    item.rating
                                                  ).toFixed(1) +
                                                  ")"}
                                              </h1>
                                            ) : (
                                              <h1 className="text-gray-600 font-bold text-xl my-auto">
                                                {"(" + 0 + ")"}
                                              </h1>
                                            )} */}
                                            <ReactStars
                                              edit={false}
                                              size={30}
                                              isHalf={true}
                                              value={parseFloat(
                                                item.rating
                                              ).toFixed(2)}
                                              activeColor="#eb8a2f"
                                            />
                                          </div>
                                        </div>
                                      </div>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            ) : (
                              <p>No reviews</p>
                            )}
                            {reviews.data.length > 2 ? (
                              <Link
                                to="#"
                                className="read_more"
                                onClick={() => this.props.setReviewModal("all")}
                              >
                                view more
                              </Link>
                            ) : null}
                          </div>

                          {packageData &&
                          listing_data.user &&
                          auth.getUserType() !== "counsellor" &&
                          listing_data.user.profile_percentage === 100 ? (
                            <div className="information_block listing__gallery package__block">
                              <Fragment>
                                <h2>
                                  <i className="fas fa-notes-medical"></i>{" "}
                                  Packages
                                </h2>
                                <div
                                  className="packages__list"
                                  ref={this.myDivToFocus}
                                >
                                  {packageData &&
                                  listing_data.user.profile_percentage ===
                                    100 &&
                                  packageData.data.length == 0 ? (
                                    <p className="m-auto">
                                      No packages found for this coach.
                                    </p>
                                  ) : (
                                    <ul className="md:flex md:flex-wrap">
                                      {packageData.data.map((item, i) => (
                                        <li className="mb-6" key={i}>
                                          <div className="pack__info">
                                            <div className="pack__detail">
                                              <div className="pack__title">
                                                <h3>
                                                  {item.package_name.slice(
                                                    0,
                                                    20
                                                  )}
                                                </h3>
                                                <h3 className="text_nav_blue">
                                                  £{item.amount}
                                                </h3>
                                              </div>
                                              <div className="pack__text">
                                                <p>
                                                  {item.package_description.slice(
                                                    0,
                                                    150
                                                  )}
                                                  <Link
                                                    to="#"
                                                    className="read_more"
                                                    onClick={() =>
                                                      this.openDetails(item)
                                                    }
                                                  >
                                                    {item.package_description
                                                      .length > 120
                                                      ? "... read more"
                                                      : null}
                                                  </Link>
                                                </p>
                                              </div>
                                              <div className="pack_history">
                                                <p>
                                                  Duration:{" "}
                                                  <span>
                                                    {item.session_hours}
                                                    {":"}
                                                    {item.session_minutes}{" "}
                                                    {setTimeLable(
                                                      item.session_hours,
                                                      item.session_minutes
                                                    )
                                                      ? "Minutes"
                                                      : "Hours"}
                                                  </span>
                                                </p>
                                                <p className="text-blue-800">
                                                  {item.no_of_slots > 1 ? (
                                                    <span>{`[${item.no_of_slots} Sessions]`}</span>
                                                  ) : null}
                                                </p>
                                              </div>
                                              <div className="btn book_pack bg_blue text-white">
                                                {/* {auth.isAuthenticated ? ( */}
                                                <Link
                                                  to="#"
                                                  onClick={() =>
                                                    this.bookNow(item)
                                                  }
                                                >
                                                  Book Now
                                                </Link>
                                              </div>
                                            </div>
                                          </div>
                                        </li>
                                      ))}
                                    </ul>
                                  )}
                                </div>

                                {packageData.data.length == 0 ? null : (
                                  <div className="site_pagination">
                                    <ul>
                                      <li
                                        className={
                                          currentPage > 1
                                            ? "prev"
                                            : "prev_list disable"
                                        }
                                      >
                                        <Link to="#" onClick={this.prevPage}>
                                          &lt; Prev{" "}
                                        </Link>
                                      </li>
                                      {totalPage.map((number, i) => {
                                        return (
                                          <li className="prev" key={i}>
                                            <Link
                                              to="#"
                                              className={
                                                this.setPageClass(number + 1)
                                                  ? "bg-blue-900 text-white"
                                                  : ""
                                              }
                                              name={number + 1}
                                              onClick={this.changePage}
                                            >
                                              {number + 1}
                                            </Link>
                                          </li>
                                        );
                                      })}
                                      <li
                                        className={
                                          currentPage < last_page
                                            ? "next"
                                            : "next_list disable"
                                        }
                                      >
                                        <Link to="#" onClick={this.nextPage}>
                                          Next &gt;{" "}
                                        </Link>
                                      </li>
                                    </ul>
                                  </div>
                                )}
                              </Fragment>
                            </div>
                          ) : null}
                        </div>

                        <div className="w-full lg:w-1/3 lg:pl-4">
                          {listing_data.gallery ? (
                            <div className="information_block listing__gallery">
                              <h2>
                                <i className="fas fa-camera"></i> Photo Gallery
                              </h2>
                              <SRLWrapper>
                                <ul className="gallery__images">
                                  {listing_data.gallery.map((i) => (
                                    <li key={i.id}>
                                      <a href={__IMG_URL__ + i.gallery_img}>
                                        <img
                                          src={__IMG_URL__ + i.gallery_img}
                                        />
                                      </a>
                                    </li>
                                  ))}
                                </ul>
                              </SRLWrapper>
                            </div>
                          ) : null}
                          <div className="information_block listing__tags">
                            <h2>
                              <i className="fas fa-tag"></i> What we Do
                            </h2>
                            {Labels}
                          </div>
                          <div className="information_block listing__gallery">
                            <a
                              href="https://soberlisticradio.com/"
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              <h2>
                                <i className="fas fa-music"></i> SOBERLISTIC
                                RADIO
                              </h2>
                              <img src="/images/radio.jpg" />
                            </a>
                          </div>
                          <div className="information_block listing__gallery">
                            <a
                              href="https://soberlisticacademy.com/"
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              <h2>
                                <i className="fas fa-lightbulb"></i> SOBERLISTIC
                                COURSES
                              </h2>
                              <img src="/images/yoga.jpg" />
                            </a>
                          </div>
                          <div className="information_block listing__gallery">
                            <a
                              href="https://soberlistic.social/articles/"
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              <h2>
                                <i className="fas fa-lightbulb"></i> SOBERLISTIC
                                ARTICLES
                              </h2>
                              <img src="/images/sthetoscope.jpg" />
                            </a>
                          </div>
                          <div className="information_block listing__gallery">
                            <h2>
                              <i className="fas fa-lightbulb"></i> SPONSERS
                            </h2>
                            <img src="images/doc_1.jpg" />
                          </div>
                          <div className="information_block listing__gallery">
                            <h2>
                              <i className="fas fa-lightbulb"></i> SPONSERS
                            </h2>
                            <img src="/images/nutritions.jpg" />
                          </div>
                          <div className="information_block listing__gallery">
                            <h2>
                              <i className="fas fa-lightbulb"></i> SPONSERS
                            </h2>
                            <img src="/images/ani.jpg" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              )}
            </div>
          ) : (
            <Spinner />
          )}
        </SimpleReactLightbox>
      </Fragment>
    );
  }
}

export default ListingView;
