import React, { Children, Fragment } from "react";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import { actions } from "../../login/modules/auth";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import queryString from "query-string";
import { Link } from "react-router-dom";

export class AuthOTPModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      otp: "",
      email: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount() {
    document.body.classList.add("modal--open","package_otp_modal");
  } 

  componentWillUnmount() {
    document.body.classList.remove("modal--open","package_otp_modal");
  }

  onSubmit(event) {
    event.preventDefault();
    let { otp } = this.props.auth;
    if (otp == "") {
      this.props.setOTPErrorMessage("Please enter the otp");
    } else if (otp.length < 4) {
      this.props.setOTPErrorMessage("Please enter the valid otp");
    } else {
      this.props.verifyEmail({ otp, history: this.props.history });
    }
    setTimeout(() => {
      this.props.setOTPErrorMessage("");
    }, 3000);
  }

  handleChange(event) {
    let { otp } = this.props.auth;
    otp = event.target.value.substring(0, 4);
    this.props.setAuthOTPValue(otp);
  }

  limitText(event) {
    if (event.target.value.length > 4) {
      event.target.value = event.target.value.substring(0, 4);
    }
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  render() {
    let { otp_err, otp } = this.props.auth;
    return (
      <Fragment>
        <div className="modal opacity fixed w-full h-full top-0 left-0 flex items-center justify-center z-10">
          <div className="modal-overlay absolute w-full h-full bg-gray-900 opacity-75" />
          <div className="modal-container bg-white w-11/12 md:w-9/12 lg:w-4/12 mx-auto rounded shadow-lg z-50 overflow-y-auto">
            {/* Add margin if you want to see some of the overlay behind the modal*/}
            <div className="modal-content p-6 text-left">
              {/*Title*/}
              {/*Body*/}
              <div className="modal__body text-center">
                <div className="site__logo w-24 m-auto">
                  <Link to="#">
                    <img
                      className="w-full"
                      src="images/yss_new_logo4x.svg"
                      alt="Site Logo"
                    />
                    <span>Your Safe Space</span>
                  </Link>
                </div>
                {/* -------- */}
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 mt-5">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <div className="mt-2">
                        <p className="block mt-2 text-base font-light text-center text-gray-700">
                          We sent a One Time Password (OTP) to Your E-mail
                        </p>
                        <form onSubmit={this.onSubmit}>
                          <div className="flex px-16 mt-6">
                            <input
                              type="number"
                              value={otp}
                              className="h-16 text-center border-2 m-auto"
                              onChange={this.handleChange}
                              onKeyDown={(e) => this.limitText(e)}
                              onKeyUp={(e) => this.limitText(e)}
                            />
                          </div>
                          {otp_err ? (
                            <p className="err-message mx-auto text-center">
                              {otp_err}
                            </p>
                          ) : null}
                          <div className="px-6 mt-6">
                            <button
                              type="submit"
                              className="block w-full px-6 py-3 text-white uppercase bg_blue rounded-lg shadow-lg"
                            >
                              {this.props.spinnerStatus ? (
                                <LoadingSpinner />
                              ) : (
                                "Verify Email"
                              )}
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CListingState: state.CListingState,
  auth: state.auth,
});

export default connect(mapStateToProps, actions)(AuthOTPModal);
