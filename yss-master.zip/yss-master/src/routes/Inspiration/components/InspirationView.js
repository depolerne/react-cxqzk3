import React, { Fragment } from "react";
import { Link } from "react-router-dom";

export class InspirationView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    let body = document.body;
    body.className = "inspiration_page";
  }

  render() {
    return (
      <Fragment>
        <div className="main-content yss-site--main__content content__homepage">
          <div className="main-site__content">
            <div 
              className="site__top-banner"
              style={{
                backgroundImage: 'url(/images/inspiration_banner-img.jpg)',
              }}
            >
              <div className="main_banner__wrapper inspiration__content page__content text-center">
                <div className="banner__title">Aricles & Tips</div>
              </div>
            </div>
            <div className="page__content">
              <div className="listing-other-details lg:flex">
                <div className="w-full lg:w-2/3 lg:pr-4">
                  <div className="information_block listing__description">
                    <div className="blog__items">
                      <div className="blog__image">
                        <img src="/images/inspiration_banner-img.jpg" />
                      </div>
                      <div className="blog__title">
                        <h3 className="title">Use Food to Ease Anxiety</h3>
                      </div>
                    </div>
                    <div className="blog__text">
                      <div className="blog__meta">
                        <span className="blog__author">
                          <a href="#">
                            <img src="/images/blog__logo.png" /> Your Safe Space
                            Online
                          </a>
                        </span>
                        <span className="blog__date">
                          <i className="far fa-calendar"></i> December 10, 2020
                        </span>
                      </div>
                      <div className="blog__desc">
                        <p>
                          Use Food to Ease Anxiety: For some, individuals,
                          feelings of anxiety are at an unsurpassed high. In
                          spite of the fact that we can’t totally eliminate the
                          wellsprings of stress from our lives, we can discover
                          instruments and strategies that can help us better
                          deal with the pressure. Improving rest propensities,
                          expanding actual work, rehearsing…
                        </p>
                      </div>
                      <div className="blog__btn mt-6">
                        <Link
                          to="/blog"
                          className="w-32 bg_blue text-white p-3 text-center i0nline-block"
                        >
                          Read More
                        </Link>
                      </div>
                    </div>
                  </div>

                  <div className="information_block listing__description">
                    <div className="blog__items">
                      <div className="blog__image">
                        <img src="/images/inspiration_banner-img.jpg" />
                      </div>
                      <div className="blog__title">
                        <h3 className="title">Use Food to Ease Anxiety</h3>
                      </div>
                    </div>
                    <div className="blog__text">
                      <div className="blog__meta">
                        <span className="blog__author">
                          <a href="#">
                            <img src="/images/blog__logo.png" /> Your Safe Space
                            Online
                          </a>
                        </span>
                        <span className="blog__date">
                          <i className="far fa-calendar"></i> December 10, 2020
                        </span>
                      </div>
                      <div className="blog__desc">
                        <p>
                          Use Food to Ease Anxiety: For some, individuals,
                          feelings of anxiety are at an unsurpassed high. In
                          spite of the fact that we can’t totally eliminate the
                          wellsprings of stress from our lives, we can discover
                          instruments and strategies that can help us better
                          deal with the pressure. Improving rest propensities,
                          expanding actual work, rehearsing…
                        </p>
                      </div>
                      <div className="blog__btn mt-6">
                        <Link
                          to="/blog"
                          className="w-32 bg_blue text-white p-3 text-center inline-block"
                        >
                          Read More
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="w-full lg:w-1/3 lg:pl-4">
                  <div className="information_block listing__booking">
                    <form className="blog__search">
                      <input type="text" placeholder="Search" />
                    </form>
                  </div>

                  <div className="information_block listing__booking">
                    <h2>Recent Posts</h2>
                    <ul>
                      <li>
                        <a href="#">Use Food to Ease Anxiety</a>
                      </li>
                      <li>
                        <a href="#">The Science Behind a Good Workout</a>
                      </li>
                      <li>
                        <a href="#">Difference in Diversity</a>
                      </li>
                    </ul>
                  </div>

                  <div className="information_block listing__booking">
                    <h2>Recent Comments</h2>
                    <ul>
                      <li></li>
                    </ul>
                  </div>

                  <div className="information_block listing__booking">
                    <h2>Archive</h2>
                    <ul>
                      <li>
                        <a href="#">December 2020</a>
                      </li>
                      <li>
                        <a href="#">January 2019</a>
                      </li>
                    </ul>
                  </div>

                  <div className="information_block listing__booking">
                    <h2>Categories</h2>
                    <ul>
                      <li>
                        <a href="#">Counselling</a>
                      </li>
                      <li>
                        <a href="#">Fitness</a>
                      </li>
                      <li>
                        <a href="#">Nutrition</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default InspirationView;
