import React, { Fragment } from "react";

export class BlogView extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    let body = document.body;
    body.className = "inspiration_page";
  }
  render() {
    return (
      <Fragment>
		<div className="main-content yss-site--main__content content__homepage content__blogpage">
          <div className="main-site__content">
			<div className="main__top-banner" style={{
                backgroundImage: 'url(/images/inspiration_banner-img.jpg)',
              }}>
              {/*<div className="main_banner__items">
				<img src="/images/nutrition.jpg" />
			  </div>*/}
			  <div className="main_banner__wrapper inspiration__content page__content text-center">
				<div className="banner__title">Use Food to Ease Anxiety</div>
			  </div>
			</div>
			
			
			<div className="page__content">
			  <div className="listing-other-details md:flex">
				<div className="w-full md:w-1/2 lg:w-2/3 md:pr-4">
				  <div className="information_block listing__description">
					<div className="blog__text">
						<div className="blog__meta">
							<span className="blog__author"><a href="#"><img src="/images/blog__logo.png" /> Your Safe Space Online</a></span>
							<span className="blog__date"><i className="far fa-calendar"></i> December 10, 2020</span>
						</div>
						<div className="blog__desc">
							<h2>Use Food to Ease Anxiety</h2>
							<p>For some, individuals, feelings of anxiety are at an unsurpassed high. In spite of the fact that we can’t totally eliminate the wellsprings of stress from our lives, we can discover instruments and strategies that can help us better deal with the pressure. Improving rest propensities, expanding actual work, rehearsing care, and unplugging from the news or web-based media can go far toward diminishing pressure. Furthermore, as this article clarifies, changing your dietary patterns can likewise go far toward assisting you with dealing with your feelings of anxiety.</p>

							<p>To start with, it’s essential to express that no nourishments cause or forestall uneasiness. An examination can for the most part disclose to us more about affiliations instead of causes; at the end of the day, it can reveal to us that eating or maintaining a strategic distance from specific nourishments might be pretty much connected with encountering nervousness.</p>

							<p>Furthermore, the nourishments you routinely burn-through are bound to affect tension levels than any single supper. Predictable, positive nourishment decisions, for example, restricting lousy nourishments, devouring adequate nutrient D and nourishments wealthy in omega-3s, eating a different eating routine, preparing your own food and rehearsing care while eating, may fundamentally improve uneasiness levels and generally mind-set. Accordingly, one “state of mind upgrading smoothie” will likely do next to no to lessen real tension.</p>

							<p>We should investigate various kinds of food and dietary patterns and their consequences for the state of mind and feelings of anxiety.</p>
							
							<h2>Solace Foods</h2>
							<p>Frozen yogurt, potato chips, mac’n’cheese, singed chicken—these nourishments are regularly connected with offering solace during snapshots of stress or tension. However, do these nourishments really improve mindset? Exploration has uncovered fascinating connections among sort of dietary fat admission, wellness level, weight record (BMI), and tension. Individuals who burn-through more noteworthy measures of solid fats and exercise more will in general have lower measures of tension. Further, BMI is emphatically connected with uneasiness, implying that heavier people normally show more noteworthy measures of tension.</p>

							<p>Subsequently, eating nourishments high in undesirable (supportive of provocative) fats as well as calorically thick nourishments that lead to weight pick up is associated with tension. Then again, eating well fats and practicing routinely is related to an improved mindset and flexibility.</p>

							<p>Objective: Follow the 80/20 principle. Eat well nourishments (especially solid fats) 80% of the time and enjoy less-sound admission close to 20% of the time. Bump all “comfort” nourishments, for example, pastries, low-quality nourishment, singed nourishments, and liquor into the 20%.</p>
							
							<h2>Mind Foods</h2>
							<p>While omega-3 fats, nutrient D, calcium, zinc, magnesium, and probiotics have been related to a better state of mind and lower nervousness, it is ridiculous to expect a specific food or nutrition class to work wonders. Nourishments high in these supplements may expand serotonin levels straightforwardly or help with the creation of serotonin, a compound that adds to sensations of prosperity and joy, and improves the nature of rest.</p>

							<p>Objective: Regularly devour nourishments high in omega-3 fats and nutrient D, and the other significant micronutrients will become alright. In particular, eat in any event two servings of fish for every week or take a top-notch fish oil supplement (talk about all supplementation with a Registered Dietitian). Likewise burn-through nourishments high in nutrient D (fish, egg yolks, dairy, and mushrooms) and get in any event 10 minutes of day by day sun presentation.</p>
							
							<h2>Gut Foods</h2>
							<p>The gut microbiome, and the connected gut-mind hub, may assume an enormous part in the improvement of uneasiness and sadness. The gut microbiome is made out of microscopic organisms, infections, and growths living in the digestion tracts and has been connected to irritation, appetite and satiety, glucose guideline, sensitivities, psychological wellness, and other metabolic conditions. Aggravation or helpless gut wellbeing is alluded to as dysbiosis and has been connected to a few psychological instabilities including nervousness and melancholy. Nourishments that contain counterfeit tones, flavors, and sugars just as the absence of dietary fiber add to gut dysbiosis. Normal, entire nourishments wealthy in fiber can improve gut wellbeing. Examination proposes that the more different the eating regimen, the more assorted the microbiome and the more versatile it will be to trouble.</p>

							<p>Probiotics may likewise add to reestablishing gut microbiome work and, along these lines, have a possible function in the treatment and anticipation of uneasiness. An ongoing report reasoned that probiotics taken with doctor endorsed drugs were more powerful in diminishing uneasiness indications than prescription alone. Further examination is required prior to inferring that everybody (or everybody with nervousness) should take probiotic supplements. Be that as it may, it is sensible to routinely devour nourishments containing normal probiotics, for example, yogurt, kefir, tempeh, a fermented tea, miso, kimchi, and sauerkraut.</p>

							<p>Objective: Eat a different eating regimen that routinely incorporates matured nourishments. Maintain a strategic distance from fake tones, flavors, and sugars.</p>
							
							<h2>Feast Preparation</h2>
							<p>Food is as much about association all things considered about sustenance. Americans burn-through almost 50% of their dinners alone and generally half outside of the home. This leaves a little cover of suppers eaten with loved ones at home. Cooking and eating with others whose organization you appreciate gives shared conviction to positive, advancing conversation, which in itself can improve mind-set and straightforwardness nervousness.</p>

							<p>Objective: Strive to locate extra importance and reason with dinners. Eat out or take out less than three suppers for each week.</p>
							
							<h2>Zero in on Your Food</h2>
							<p>Consider how much individuals surge and perform various tasks as the day progressed. This incorporates supper time, during which everybody appears to stare at the TV, check email or skim web-based media streams. Unplug to improve your association with food and upgrade your state of mind. Discussion about the day with relatives—share what you realized, snapshots of appreciation, and kind signals you gave or got.</p>

							<p>Objective: Sit down at an eating table for in any event one feast for every day and unplug from all innovation (except for ambient sounds, whenever wanted). Zero in on simply eating and interfacing with others during dinners.</p>

							<p>It tends to be hard to recall at the time, yet steady and long haul good dieting propensities lessen nervousness more than any single food, drink, or supplement. Moreover, associating with food and with others empowers a positive relationship with food and feast times. Along these lines, for ideal emotional well-being, organize burning-through solid, various nourishments, and discover comfort in interfacing with food and others.</p>
						</div>
					</div>
				  </div>
				</div>

				<div className="w-full md:w-1/2 lg:w-1/3 md:pl-4">
				  <div className="information_block listing__booking">
					<form className="blog__search">
						<input type="text" placeholder="Search" />
					</form>
				  </div>
				  
				  <div className="information_block listing__booking">
					<h2>Recent Posts</h2>
					<ul>
						<li>
							<a href="#">Use Food to Ease Anxiety</a>
						</li>
						<li>
							<a href="#">The Science Behind a Good Workout</a>
						</li>
						<li>
							<a href="#">Difference in Diversity</a>
						</li>
					</ul>
				  </div>
				  
				  <div className="information_block listing__booking">
					<h2>Recent Comments</h2>
					<ul>
						<li>
							
						</li>
					</ul>
				  </div>
				  
				  <div className="information_block listing__booking">
					<h2>Archive</h2>
					<ul>
						<li>
							<a href="#">December 2020</a>
						</li>
						<li>
							<a href="#">January 2019</a>
						</li>
					</ul>
				  </div>
				  
				  <div className="information_block listing__booking">
					<h2>Categories</h2>
					<ul>
						<li>
							<a href="#">Counselling</a>
						</li>
						<li>
							<a href="#">Fitness</a>
						</li>
						<li>
							<a href="#">Nutrition</a>
						</li>
					</ul>
				  </div>
				</div>
			  </div>
			</div>
		  </div>
		</div>
      </Fragment>
    );
  }
}

export default BlogView;
