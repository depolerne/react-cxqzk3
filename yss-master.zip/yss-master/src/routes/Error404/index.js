import ErrorContainer from './containers/ErrorContainer';
export { ErrorContainer };
export * from './modules/error';

export default ErrorContainer;
