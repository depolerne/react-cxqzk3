import React from 'react';

const redirectToDashboard = [
  '/user',
  '/user/login',
  '/dashboard/login'
];

export class ErrorView extends React.Component {
    render () {
        if(redirectToDashboard.indexOf(this.props.location.pathname) >= 0) {
            this.props.history.push('/');
        }
        return (
            <div className='page404-view'>
                <div className='page404-container page404'>
                    <h1 className='page404-error-text'>404. Page not found.</h1>
                </div>
            </div>
        );
    }
}

export default ErrorView;
