import React, { Fragment } from "react";
import Spinner from "../../../components/Spinner/Spinner";
import auth from "../../../helpers/auth";
import { Link } from "react-router-dom";
import Cookies from "js-cookie";
// import SignUpModal from "./SignUpModal";
// import LoginModal from "../../Listing/components/LoginModal";
// import AuthOTPModal from "./AuthOTPModal";
import { PackageDetails } from "../../Packages/components/PackageDetails";
import { AlertBox } from "../../../components/AlertBox/AlertBox";
import { setTimeLable } from "../../../helpers/checkSlots";

var temp;

export class CListingView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checkoutState: false,
      packageData: [],
      userSpinner: false,
      packageSpinner: false,
      name: "",
      avatar_id: "",
      currentPage: 1,
      totalPages: [],
      last_page: 0,
      packageDetails: {},
      details: false,
      _baseUrl: "https://api.soberlistic.com/",
    };
    this.loadData = this.loadData.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.fetchUser = this.fetchUser.bind(this);
    this.prevPage = this.prevPage.bind(this);
    this.nextPage = this.nextPage.bind(this);
    this.changePage = this.changePage.bind(this);
    this.setActiveClass = this.setActiveClass.bind(this);
    this.openDetails = this.openDetails.bind(this);
  }

  componentDidMount() {
    let body=document.body;
    body.className="package_listings";
    if (!auth.isAuthenticated) {
      this.props.setAuthModal("login");
    }
    this.fetchUser();
    this.loadData();
    // this.props.setSelectedSlots({});
    this.props.setCounsellorId(this.props.match.params.id);
    if (this.props.match.params.id !== "id") {
      Cookies.set("__pid", this.props.match.params.id, { expires: 7 });
    }
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  submitHandler(id) {
    let { packageData } = this.state;
    let { userData } = this.props.selectState;
    temp = packageData.filter((item) => item.id == id);
    this.props.setBookingPackage(temp[0]);
  }

  async fetchUser() {
    this.setState({ userSpinner: true });
    let result = await fetch(
      `${__API__}/get/counsellor/details?user_id=${this.props.match.params.id}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/vnd.api+json; charset=utf-8",
          Accept: "application/json",
        },
      }
    );

    let response = await result.json();
    if (response.success) {
      this.setState({
        avatar_id: response.user.avatar_id,
        name: response.user.name,
        userSpinner: false,
      });
    }
    this.props.CounsellorName(this.state.name);
  }

  async loadData() {
    this.setState({ packageSpinner: true });
    let result = await fetch(
      `${__API__}/get/counsellor/packages?user_id=${this.props.match.params.id}&page=${this.state.currentPage}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/vnd.api+json; charset=utf-8",
          Accept: "application/json",
        },
      }
    );
    let response = await result.json();
    if (response.success) {
      this.setState({
        packageData: response.packages.data,
        packageSpinner: false,
        last_page: response.packages.last_page,
        totalPages: [...Array(response.packages.last_page).keys()],
      });
    } else if (!response.success) {
      this.setState({ packageData: [], packageSpinner: false });
      this.props.setAlertMessage({
        message: "No packages found for this counsellor",
        color: "teal",
      });
    }
  }

  async prevPage(e) {
    let num = (await parseInt(this.state.currentPage)) - 1;
    if (this.state.currentPage > 1) {
      await this.setState({ currentPage: num });
      await this.loadData();
    }
  }

  async nextPage() {
    let num = (await parseInt(this.state.currentPage)) + 1;
    if (this.state.currentPage < this.state.last_page);
    this.setState({ currentPage: num });
    await this.loadData();
  }

  async changePage(e) {
    let value = await parseInt(e.target.name);
    await this.setState({ currentPage: value });
    await this.loadData();
  }

  setActiveClass(value) {
    if (this.state.currentPage === value) {
      return true;
    } else {
      return false;
    }
  }

  openDetails(data) {
    this.setState({ packageDetails: data, details: !this.state.details });
  }

  render() {
    let { packageData, currentPage, last_page, totalPages } = this.state;
    packageData = Array.from(packageData);
    let { avatar_id, name, _baseUrl } = this.state;
    let { authModal, errMessage } = this.props.CListingState;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            {this.state.details ? (
              <PackageDetails
                bookEvent={(id) => this.submitHandler(id)}
                cancelEvent={() => this.openDetails()}
                packageData={this.state.packageDetails}
                match={this.props.match}
              />
            ) : null}
            <div className="page__content">
              {/* {errMessage.message ? (
                <AlertBox
                  color={errMessage.color}
                  AlertText={errMessage.message}
                />
              ) : null}
              {authModal === "login" ? (
                <LoginModal />
              ) : authModal === "signup" ? (
                <SignUpModal />
              ) : authModal === "OTP" ? (
                <AuthOTPModal
                  cancelEvent={() => this.props.setAuthModal("")}
                  history={this.props.history}
                />
              ) : null} */}
              <div className="form__heading md:flex md:flex-wrap justify-between">
                <h3>
                  Package <span>Listings</span>
                </h3>
                <h3>  <a href='https://soberlistic.com/get-help/'>Go back to Listings</a>
                </h3>
              </div>
              <div className="middle__content md:flex">
                <div className="w-full md:pr-6 md:w-3/4">
                  {this.state.userSpinner ? (
                    <Spinner />
                  ) : (
                    <div className="doc__info">
                      <div className="doc_image">
                        <img
                          src={
                            avatar_id === null
                              ? "/images/user_blue.svg"
                              : _baseUrl + avatar_id
                          }
                        />
                      </div>
                      <div className="doc__detail">
                        <div className="doc__title">
                          <h3>{name}</h3>
                          {/* <p className="book_history">
                            20 Times Booked Previously
                          </p> */}
                        </div>
                        <div className="info__text">
                          <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing
                            elit, sed do eiusmod tempor incididunt ut labore et
                            dolore magna aliqua. Lorem ipsum dolor sit amet,
                            consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua. Lorem
                            ipsum dolor sit amet, consectetur adipiscing elit,
                            sed do eiusmod tempor incididunt ut labore et dolore
                            magna aliqua. Lorem ipsum dolor sit amet,
                            consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt ut labore et dolore magna aliqua.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  {this.state.packageSpinner ? (
                    <Spinner />
                  ) : (
                    <div className="packages__list md:flex md:flex-wrap">
                      {packageData === undefined || packageData.length == 0 ? (
                        <p className="m-auto">
                          No packages found for this counsellor.
                        </p>
                      ) : (
                        packageData.map((item, i) => {
                          return (
                            <div className="md:w-1/2 mb-6 md:px-3" key={i}>
                              <div className="pack__info">
                                <div className="pack__detail">
                                  <div className="pack__title">
                                    <h3>{item.package_name.slice(0, 20)}</h3>
                                    <h3 className="text_nav_blue">
                                      £{item.amount}
                                    </h3>
                                  </div>
                                  <div className="pack__text">
                                    <p>
                                      {item.package_description.slice(0, 150)}
                                      <Link
                                        to="#"
                                        className="read_more"
                                        onClick={() => this.openDetails(item)}
                                      >
                                        {item.package_description.length > 120
                                          ? "... read more"
                                          : null}
                                      </Link>
                                    </p>
                                  </div>
                                  <div className="pack_history">
                                    <p>
                                      Duration:{" "}
                                      <span>
                                        {item.session_hours}
                                        {":"}
                                        {item.session_minutes}{" "}
                                        {setTimeLable(
                                          item.session_hours,
                                          item.session_minutes
                                        )
                                          ? "Minutes"
                                          : "Hours"}
                                      </span>
                                    </p>
                                    {/* <p>
                                        Total Bookings: <span></span>
                                      </p> */}
                                  </div>
                                  <div className="btn book_pack bg_blue text-white">
                                    {/* {auth.isAuthenticated ? ( */}
                                    <Link
                                      to={`/packages/${this.props.match.params.id}/create-booking`}
                                      onClick={() =>
                                        this.submitHandler(item.id)
                                      }
                                    >
                                      Book Now
                                    </Link>
                                  </div>
                                </div>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  )}
                  {/* ------------code snippet for pagination ------------ */}
                  {last_page == 1 || last_page == 0 ? null : (
                    <div className="site_pagination">
                      <ul>
                        <li className={currentPage > 1 ? "prev" : "disable"}>
                          <Link to="#" onClick={this.prevPage}>
                            &lt; Prev{" "}
                          </Link>
                        </li>
                        {totalPages.map((number, i) => {
                          return (
                            <li className="prev" key={i}>
                              <Link
                                to="#"
                                className={
                                  this.setActiveClass(number + 1)
                                    ? "bg-blue-900 text-white rounded-full"
                                    : ""
                                }
                                name={number + 1}
                                onClick={this.changePage}
                              >
                                {number + 1}
                              </Link>
                            </li>
                          );
                        })}
                        <li
                          className={
                            currentPage < last_page ? "next" : "disable"
                          }
                        >
                          <Link to="#" onClick={this.nextPage}>
                            Next &gt;{" "}
                          </Link>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
                {/* ------------------------------------------------ */}
                <div className="how_it_works w-full mt-6 md:w-1/4 md:mt-0">
                  <div className="block__info">
                    <div className="block_title">
                      <h3>How it works</h3>
                    </div>
                    <ul className="work_list">
                      <li className="book_person">
                        Book for anyone in your family
                      </li>
                      <li className="book_slot">
                        Select a convenient time slot
                      </li>
                      <li className="book_join">
                        You can join the video call from your phone (or) any
                        device
                      </li>
                      <li className="book_video">
                        Complete payment and you can stay safe by video
                        consulting from home
                      </li>
                    </ul>
                  </div>
                  <div className="our_features block__info mt-6">
                    <div className="block_title">
                      <h3>Our Features</h3>
                    </div>
                    <ul>
                      <li>HD Video</li>
                      <li>Personalized room URL</li>
                      <li>Secure data center</li>
                      <li>No patient data stored</li>
                      <li>End-to-end encryption</li>
                      <li>Meets HIPAA requirements</li>
                      <li>Breach insurance</li>
                      <li>Meets GDPR requirements</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default CListingView;
