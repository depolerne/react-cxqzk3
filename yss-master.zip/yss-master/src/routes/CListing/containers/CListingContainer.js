import React from "react";
import { connect } from "react-redux";
import { actions } from "../modules/CListing";
import CListingView from "../components/CListingView";
import RedBox from "redbox-react";
import { bindActionCreators } from "redux";
import { withJob } from "react-jobs";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CListingState: state.CListingState,
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {},
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(CListingView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
