import auth from "../../../helpers/auth";
import _without from "lodash/without";
import _remove from "lodash/remove";
import _get from "lodash/get";
import { setAlertMessage } from "../../selectWrapper/modules/select";
// import {setSelectedSlots} from '../../Checkout/modules/Checkout'
//---> Defining types for different actions

export const CLISTING_P_SET_COUNSELLOR_ID = "CLISTING_P_SET_COUNSELLOR_ID";
export const CLISTING_P_SET_IS_ERR_MESSAGE = "CLISTING_P_SET_IS_ERR_MESSAGE";
export const SELECT_TOP_SET_MODAL = "SELECT_TOP_SET_MODAL";
export const SET_LOADING_SPINNER_STATUS = "SET_LOADING_SPINNER_STATUS";
export const SET_TARGET_PACKAGE_FOR_BOOKING = "SET_TARGET_PACKAGE_FOR_BOOKING";
export const SELECT_COUNSELLOR_NAME = "SELECT_COUNSELLOR_NAME";
//export const CLISTINGS_SET_OPEN_MODAL = "CLISTINGS_SET_OPEN_MODAL";
export const CLISTINGS_SET_COUNSELLOR_TIME_ZONE='CLISTINGS_SET_COUNSELLOR_TIME_ZONE'
//---> Defining Actions to set state variables

export function setCounsellorId(id) {
  return {
    type: CLISTING_P_SET_COUNSELLOR_ID,
    payload: id,
  };
}

// export const setAuthModal = (flag) => {
//   return {
//     type: CLISTINGS_SET_OPEN_MODAL,
//     payload: flag,
//   };
// };

export function setBookingPackage(value) {
  return {
    type: SET_TARGET_PACKAGE_FOR_BOOKING,
    payload: value,
  };
}

export function setIsErrMessage(err) {
  return {
    type: CLISTING_P_SET_IS_ERR_MESSAGE,
    payload: err,
  };
}

export const CounsellorName = (name) => {
  return {
    type: SELECT_COUNSELLOR_NAME,
    payload: name,
  };
};

export const setCTimeZone=(zone)=>{
  return {
    type: CLISTINGS_SET_COUNSELLOR_TIME_ZONE,
    payload: zone
  }
}

//---> exporting multiple functions and actions

export const actions = {
  setIsErrMessage,
  setCounsellorId,
  CounsellorName,
  //setAuthModal,
  setBookingPackage,
  setCTimeZone,
  setAlertMessage,
  // setSelectedSlots,
};

//---> defining the initialState for state variables

const initialState = {
  loadingSpinner: false,
  targetPackage: "",
  counsellor_name: "",
  counsellor_id: "",
  c_zone:'',
  //authModal: "",
  errMessage:{
    message:'',color:''
  }
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [CLISTINGS_SET_COUNSELLOR_TIME_ZONE]:(state, action)=>{
    return {
      ...state,
      c_zone: action.payload,
    }
  },
  [CLISTING_P_SET_IS_ERR_MESSAGE]:(state,action)=>{
    return {
      ...state,
      errMessage: action.payload,
    }
  },
  [SELECT_COUNSELLOR_NAME]: (state, action) => {
    return {
      ...state,
      counsellor_name: action.payload,
    };
  },
  [SET_LOADING_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      loadingSpinner: action.payload,
    };
  },
  [SET_TARGET_PACKAGE_FOR_BOOKING]: (state, action) => {
    return {
      ...state,
      targetPackage: action.payload,
    };
  },
  [CLISTING_P_SET_COUNSELLOR_ID]: (state, action) => {
    return {
      ...state,
      counsellor_id: action.payload,
    };
  },
  // [CLISTINGS_SET_OPEN_MODAL]: (state, action) => {
  //   return {
  //     ...state,
  //     authModal: action.payload,
  //   };
  // },
};

export default function CListingReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
