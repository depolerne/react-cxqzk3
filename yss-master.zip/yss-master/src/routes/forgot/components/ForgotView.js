import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import { AlertBox } from "../../../components/AlertBox/AlertBox";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";

export class ForgotView extends React.Component {
  constructor(props) {
    super(props);
    this.handlechange = this.handlechange.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
  }

  /* Body class add - 16-09-2021 */
  componentDidMount() {
    let body = document.body;
    body.className = "user_login";
  }

  handlechange(event) {
    const name = event.target.name;
    const value = event.target.value;
    let { forgotData } = this.props.forgotState;
    forgotData[name] = value;
    this.props.setForgotData(forgotData)
  }

  componentWillUnmount() {
    localStorage.removeItem("otp");
    localStorage.removeItem("forgot-email");
    this.props.setForgotData({
      password: "",
      c_password: "",
      OTP: "",
    });
  }

  submitHandler(event) {
    let { forgotData } = this.props.forgotState;
    event.preventDefault();
    if (forgotData.password.length < 8) {
      this.props.setForgotPasswordErr({
        message: "Password must contain 8 characters including one special & one numeric character",
        color: "teal",
      });
    } else if (forgotData.password.length < 8) {
      this.props.setForgotPasswordErr({
        message: "Password must contain 8 characters including one special & one numeric character",
        color: "teal",
      });
      this.setState({ errClass: "password" });
    } else if (forgotData.password.search(/[a-z]/i) < 0) {
      this.props.setForgotPasswordErr({
        message: "Password must contain at least one letter.",
        color: "teal",
      });
    } else if (forgotData.password.search(/[0-9]/) < 0) {
      this.props.setForgotPasswordErr({
        message: "Password must contain at least one numeric character.",
        color: "teal",
      });
    } else if (
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(forgotData.password)
    ) {
      this.props.setForgotPasswordErr({
        message: "Password must contain at least one special character.",
        color: "teal",
      });
    } else if (forgotData.password !== forgotData.c_password) {
      this.props.setForgotPasswordErr({
        message: "Password and confirm password should be same",
        color: "teal",
      });

    // } else if (forgotData.otp.length<4) {
    //     this.props.setForgotPasswordErr({
    //       message: "Please enter a valid OTP",
    //       color: "teal",
    //     });
    } else {
      this.props.changePassword({ ...forgotData, history: this.props.history });
    }
    setTimeout(() => {
      this.props.setForgotPasswordErr({ message: "", color: "" });
    }, 3000);
  }

  render() {
    const { errforgotMessage, forgotSpinnerStatus, forgotData } = this.props.forgotState;

    return (
      <Fragment>
        <div className="login_form md:w-1/2 bg-white p-4 text-center">
          {errforgotMessage.message ? (
            <AlertBox
              AlertText={errforgotMessage.message}
              color={errforgotMessage.color}
            />
          ) : null}
          <div className="site__logo w-24 m-auto">
          <Link to="/">
            <img 
              className="w-full"
              src="images/soberlistic_small_logo.png"
              alt="Site Logo"
            />
            <span>Soberlistic</span>
            </Link>
          </div>
          <div className="main_forms">
            <form className="login_form" onSubmit={this.submitHandler}>
              <div className="form_title font-bold">
                <h3>Forgot password</h3>
              </div>
              <div className="form-item">
                <label>New password</label>
                <input
                  type="password"
                  name="password"
                  onChange={this.handlechange}
                  value={forgotData.password}
                />
              </div>
              <div className="form-item">
                <label>Confirm Password</label>
                <input
                  type="password"
                  name="c_password"
                  onChange={this.handlechange}
                  value={forgotData.c_password}
                />
              </div>
              <div className="form-item">
                <label>OTP</label>
                <input
                  type="password"
                  name="OTP"
                  onChange={this.handlechange}
                  value={forgotData.otp}
                />
              </div>
              <div className="form-actions">
                <button type="submit">
                  {forgotSpinnerStatus ? <LoadingSpinner /> : "Submit"}
                </button>
              </div>
            </form>
          </div>
        </div>
        <div className="welcome_note reset-pwd-note text-white text-center md:w-1/2 p-6 md:px-16">
          <div className="form_text--title">
            <h3>Heading</h3>
          </div>
          <div className="login__text">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
            <p>
              Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
              maecenas accumsan lacus.
            </p>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
            <p>
              Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
              maecenas accumsan lacus.
            </p>
          </div>
          <div className="btn login_text--btn">
            <Link to="/user/login">Login as User</Link>
          </div>
        </div>
      </Fragment>
    );
  }
}

ForgotView.propTypes = {
  history: PropTypes.object.isRequired,
  forgotState: PropTypes.object.isRequired,
};

export default ForgotView;
