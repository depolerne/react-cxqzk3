import React, { Fragment } from "react";
import { actions } from "../modules/forgot";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { AlertBox } from "../../../components/AlertBox/AlertBox";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";

export class ForgotPassword extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errorClass: "",
      email: "",
    };
    this.handlechange = this.handlechange.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
  }
  handlechange(e) {
    this.setState({ email: e.target.value });
  }

  componentDidMount(){
    let body = document.body;
    body.className = "user_login";
    this.props.setAuthModal('')
  } 

  submitHandler(e) {
    e.preventDefault();
    let regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    if (!this.state.email.length) {
      this.props.setForgotPasswordErr({
        message: "Please enter the email",
        color: "teal",
      });
      this.setState({ errClass: "email" });
    } else if (!regex.test(this.state.email)) {
      this.props.setForgotPasswordErr({
        message: "Enter a valid Email Address.",
        color: "teal",
      });
      this.setState({ errClass: "email" });
    } else {
      this.props.forgotPassword({ ...this.state, history: this.props.history });
    }
    setTimeout(() => {
      this.props.setForgotPasswordErr({ message: "", color: "" });
    }, 3000);
  }

  render() {
    const { errforgotMessage, sendMailSpinner } = this.props.forgotState;
    return (
      <Fragment>
        <div className="login_form md:w-1/2 bg-white pt-8 pb-4 px-4 text-center">
          {errforgotMessage.message ? (
            <AlertBox
              AlertText={errforgotMessage.message}
              color={errforgotMessage.color}
            />
          ) : null}
          <div className="site__logo w-24 m-auto">
          <Link to="/">
            <img
              className="w-full"
              src="images/soberlistic_small_logo.png"
              alt="Site Logo"
            />
            <span>Soberlistic</span>
            </Link>
          </div>
          <div className="main_forms">
            <form className="login_form" onSubmit={this.submitHandler}>
              <div className="form_title font-bold">
                <h3>Forgot Password</h3>
              </div>
              <div className="form-item">
                <label>Email Address</label>
                <input
                  className={
                    this.state.errorClass == "email" ? "border-red-500" : ""
                  }
                  type="text"
                  name="username"
                  onChange={this.handlechange}
                  value={this.state.username}
                />
              </div>
              <div className="form-actions">
                <button type="submit">
                  {sendMailSpinner ? <LoadingSpinner/>: 'Submit'}
                </button>
              </div>
            </form>
            <div className="forget_pwd">
              <Link to="/user/login" className="text_nav_blue">
                Back
              </Link>
            </div>
          </div>
        </div>
        <div className="welcome_note forgot_welcome_note text-white text-center md:w-1/2 p-4 md:px-16">
          <div className="form_text--title">
            <h3>Heading</h3>
          </div>
          <div className="login__text">
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
            <p>
              Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
              maecenas accumsan lacus.
            </p>
          </div>
          <div className="btn login_text--btn">
            <Link to="/user/login">Login as User</Link>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  auth: state.auth,
  forgotState: state.forgotState
});

export default connect(mapStateToProps, actions)(ForgotPassword);
