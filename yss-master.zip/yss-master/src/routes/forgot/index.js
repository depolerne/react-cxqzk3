import Forgot from './containers/ForgotContainer';
export { Forgot };
export * from './modules/forgot';

export default Forgot;
