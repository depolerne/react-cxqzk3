import fetch from "isomorphic-fetch";
import { setErrLoginMessage } from "../../login/modules/auth";
import { setAuthModal } from "../../Listing/modules/Listing";

export const FORGOT_P_SET_SPINNER_STATUS = "FORGOT_P_SET_SPINNER_STATUS";
export const SET_FORGOT_PASSWORD_ERR_MESSAGE =
  "SET_FORGOT_PASSWORD_ERR_MESSAGE";
export const SET_FORGOT_PASSWORD_KEY = "SET_FORGOT_PASSWORD_KEY";
export const SET_FORGOT_PASSWORD_EMAIL = "SET_FORGOT_PASSWORD_EMAIL";
export const FORGOT_SET_EMAIL_OTP_SPINNER_STATUS =
  "FORGOT_SET_EMAIL_OTP_SPINNER_STATUS";
export const FORGOT_SET_FORM_DATA = "FORGOT_SET_FORM_DATA";

export function setForgotSpinnerStatus(status) {
  return {
    type: FORGOT_P_SET_SPINNER_STATUS,
    payload: status,
  };
}

export const setForgotPasswordErr = (value) => {
  return {
    type: SET_FORGOT_PASSWORD_ERR_MESSAGE,
    payload: value,
  };
};

export const setForgotPasswordKey = (key) => {
  return {
    type: SET_FORGOT_PASSWORD_KEY,
    payload: key,
  };
};

export const setForgotEmail = (email) => {
  return {
    type: SET_FORGOT_PASSWORD_EMAIL,
    payload: email,
  };
};

export const setSendMailSpinner = (flag) => {
  return {
    type: FORGOT_SET_EMAIL_OTP_SPINNER_STATUS,
    payload: flag,
  };
};

export const setForgotData = (data) => {
  return {
    type: FORGOT_SET_FORM_DATA,
    payload: data,
  };
};

export const forgotPassword = (data) => {
  return async (dispatch) => {
    await dispatch(setSendMailSpinner(true));
    await dispatch(setForgotEmail(data.email));
    await localStorage.setItem("forgot-email", data.email);
    try {
      const result = await fetch(
        `${__API__}/forgot-password?email=${data.email}`,
        {
          method: "POST",
          cache: "no-cache",
          body: JSON.stringify(data),
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        await dispatch(setSendMailSpinner(false));
        Object.keys(response.errors).map((item) => {
          dispatch(
            setForgotPasswordErr({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setSendMailSpinner(false));
        await dispatch(
          setForgotPasswordErr({
            message: "We have shared a OTP on your Email.",
            color: "green",
          })
        );
        await dispatch(setForgotPasswordKey(response.otp));
        localStorage.setItem("otp", response.otp);
        await data.history.push("/user/request/reset-password/");
      }
    } catch (e) {
      await dispatch(setSendMailSpinner(false));
      dispatch(
        setForgotPasswordErr({
          message: "Email not recognized. Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    setTimeout(() => {
      dispatch(setForgotPasswordErr({ message: "", color: "" }));
    }, 10000);
  };
};

export const changePassword = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setForgotPasswordErr(""));
    await dispatch(setForgotSpinnerStatus(true));
    let email = localStorage.getItem("forgot-email");
    let otp = localStorage.getItem("otp");
    try {
      let result = await fetch(
        `${__API__}/reset/password?email=${email}&otp=${otp}&password=${data.password}`,
        {
          method: "POST",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
          },
        }
      );

      let response = await result.json();
      if (!response.success) {
        await dispatch(setForgotSpinnerStatus(false));
        Object.keys(response.errors).map((item) => {
          dispatch(
            setForgotPasswordErr({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(
          setErrLoginMessage({
            message: "Password changed successfully",
            color: "green",
          })
        );
        await dispatch(setForgotSpinnerStatus(false));
        await data.history.push("/user/login");
        localStorage.removeItem("otp");
        localStorage.removeItem("forgot-email");
      }
    } catch (e) {
      await dispatch(setForgotPasswordErr("Server error Please try again!!"));
      await dispatch(setForgotSpinnerStatus(false));
    }
    await setTimeout(() => {
      dispatch(setForgotPasswordErr({ message: "", color: "" }));
      dispatch(setErrLoginMessage({ message: "", color: "" }));
    }, 7000);
  };
};

export const actions = {
  changePassword,
  setForgotSpinnerStatus,
  setForgotPasswordErr,
  forgotPassword,
  setForgotData,
  setAuthModal
};

export const initialState = {
  errforgotMessage: { message: "", color: "" },
  forgotSpinnerStatus: false,
  forgotPasswordkey: "",
  sendMailSpinner: false,
  forgotData: {
    password: "",
    c_password: "",
    OTP: "",
  },
};

const ACTION_HANDLERS = {
  [FORGOT_SET_EMAIL_OTP_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      sendMailSpinner: action.payload,
    };
  },
  [FORGOT_P_SET_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      forgotSpinnerStatus: action.payload,
    };
  },
  [SET_FORGOT_PASSWORD_ERR_MESSAGE]: (state, action) => {
    return {
      ...state,
      errforgotMessage: action.payload,
    };
  },
  [SET_FORGOT_PASSWORD_KEY]: (state, action) => {
    return {
      ...state,
      forgotPasswordkey: action.payload,
    };
  },
  [FORGOT_SET_FORM_DATA]: (state, action) => {
    return {
      ...state,
      forgotData: { ...action.payload },
    };
  },
};

export default function forgotReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
