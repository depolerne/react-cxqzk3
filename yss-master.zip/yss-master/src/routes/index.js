import React, { Fragment } from "react";
import CoreLayout from "./../layouts/CoreLayout";
import LoginLayout from "./../layouts/LoginLayout";
import CounsellorLayout from "./../layouts/CounsellorLayout";
import packageLayout from "./../layouts/packageLayout";
import SessionLayout from "../layouts/SessionLayout";
import SessionWrapper from "./SessionWrapper/SessionWrapper";
import SiteWrapper from "./SiteWrapper";
import SelectWrapper from "./selectWrapper";
import Dashboard from "./dashboard";
import CDashboard from "./CDashboard";
import Login from "./login";
import Error404 from "./Error404";
import { renderRoutes } from "react-router-config";
import { Root } from "./../layouts/Root";
import { Redirect } from "react-router";
import Signup from "./Signup";
import UserAppointment from "./UserAppointment";
import Notification from "./Notification";
import Profile from "./Profile";
import CProfile from "./CProfile";
import CListing from "./CListing";
import Availablity from "./Availablity";
import Packages from "./Packages";
import CreatePackage from "./CreatePackage";
import EditPackage from "./EditPackage";
import Forgot from "./forgot";
import Checkout from "./Checkout";
import CAppointments from "./CAppointments";
import { exact, instanceOf } from "prop-types";
import { VideoSession } from "./VideoSession";
import VideoReady from "./UserAppointment/components/VideoReady";
import HomeView from "./Home/components/HomeView";
import ForgotPassword from "./forgot/components/ForgotPassword";
import SiteLayout from "../layouts/SiteLayout/SiteLayout";
import AddListings from "./AddListings";
import SearchNow from "./SearchNow";
import AddListingPreview from "./AddListings/components/AddListingPreview";
import InspirationView from "./Inspiration/components/InspirationView";
import Listing from "./Listing";
import BlogView from "./Inspiration/components/BlogView";
import VideoStart from "./CAppointments/components/VideoStart";
import { SavedView } from "./AddListings/components/SavedView";
import InsuranceView from "./Insurance/components/InsuranceView";
import HowThisWorks from "../components/HowThisWorks/HowThisWorks";
import AboutView from "../components/About/AboutView";
import PrivacyPolicy from "../components/PrivacyPolicy/PrivacyPolicy";
import TermsAndCondition from "../components/TermsAndCondition/TermsAndCondition";
import ContactContainers from "./Contact";
import CookieConsent from '../components/CookieConsent/CookieConsent';

// export const redirectRoute = () => {
//   return <Redirect to={"/"} />;
// };

export const routes = [
  {
    component: Root,
    routes: [
      // {
      //   path: "/",
      //   exact: true,
      //   component: redirectRoute,
      // },
      {
        path: "/dashboard/",
        component: CoreLayout,
        routes: [
          {
            path: "/dashboard/",
            component: SelectWrapper,
            routes: [
              {
                path: "/dashboard/",
                exact: true,
                component: Dashboard,
              },
              {
                path: "/dashboard/appointments",
                exact: true,
                component: UserAppointment,
              },
              {
                path: "/dashboard/notifications",
                exact: true,
                component: Notification,
              },
              {
                path: "/dashboard/myprofile",
                exact: true,
                component: Profile,
              },
              {
                path: "/dashboard/startsession",
                exact: true,
                component: VideoReady,
              },
            ],
          },
        ],
      },
      {
        path: "/",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/",
            component: SiteWrapper,
            routes: [
              {
                path: "/",
                component: HomeView,
              }
            ],
          },
        ],
      },
      {
        path: "/about",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/about",
            component: SiteWrapper,
            routes: [
              {
                path: "/about",
                component: AboutView,
              },
            ],
          },
        ],
      },
      {
        path: "/add-your-listings",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/add-your-listings",
            component: SiteWrapper,
            routes: [
              {
                path: "/add-your-listings",
                component: AddListings,
              },
            ],
          },
        ],
      },
      {
        path: "/listing-preview",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/listing-preview",
            component: SiteWrapper,
            routes: [
              {
                path: "/listing-preview",
                component: AddListingPreview,
              },
            ],
          },
        ],
      },
      {
        path: "/find-your-coach",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/find-your-coach",
            component: SiteWrapper,
            routes: [
              {
                path: "/find-your-coach",
                component: SearchNow,
              },
            ],
          },
        ],
      },
      {
        path: "/listing/:id/:slug",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/listing/:id/:slug",
            component: SiteWrapper,
            routes: [
              {
                path: "/listing/:id/:slug",
                component: Listing,
              },
            ],
          },
        ],
      },
      {
        path: "/listing/:slug",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/listing/:slug",
            component: SiteWrapper,
            routes: [
              {
                path: "/listing/:slug",
                component: Listing,
              },
            ],
          },
        ],
      },
      {
        path: "/cookies-consent",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/cookies-consent",
            component: SiteWrapper,
            routes: [
              {
                path: "/cookies-consent",
                component: CookieConsent,
              },
            ],
          },
        ],
      },
      {
        path: "/inspiration",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/inspiration",
            component: SiteWrapper,
            routes: [
              {
                path: "/inspiration",
                component: InspirationView,
              },
            ],
          },
        ],
      },
      {
        path: "/contact",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/contact",
            component: SiteWrapper,
            routes: [
              {
                path: "/contact",
                component: ContactContainers,
              },
            ],
          },
        ],
      },
      {
        path: "/blog",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/blog",
            component: SiteWrapper,
            routes: [
              {
                path: "/blog",
                component: BlogView,
              },
            ],
          },
        ],
      },
      {
        path: "/welcome",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/welcome",
            component: SiteWrapper,
            routes: [
              {
                path: "/welcome",
                component: SavedView,
              },
            ],
          },
        ],
      },
      {
        path: "/insurance-claim",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/insurance-claim",
            component: SiteWrapper,
            routes: [
              {
                path: "/insurance-claim",
                component: InsuranceView,
              },
            ],
          },
        ],
      },
      {
        path: "/how-it-works",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/how-it-works",
            component: SiteWrapper,
            routes: [
              {
                path: "/how-it-works",
                component: HowThisWorks,
              },
            ],
          },
        ],
      },
      {
        path: "/terms-and-conditions",
        exact: true,
        component: SiteLayout,
        routes: [
          {
            path: "/terms-and-conditions",
            component: SiteWrapper,
            routes: [
              {
                path: "/terms-and-conditions",
                component: TermsAndCondition,
              },
            ],
          },
        ],
      },
      {
        path: "/privacy-policy",
        component: SiteLayout,
        routes: [
          {
            path: "/privacy-policy",
            component: SiteWrapper,
            routes: [
              {
                path: "/privacy-policy",
                component: PrivacyPolicy,
              },
            ],
          },
        ],
      },
      {
        path: "/coach/dashboard",
        component: CounsellorLayout,
        routes: [
          {
            path: "/coach/dashboard",
            component: SelectWrapper,
            routes: [
              {
                path: "/coach/dashboard",
                exact: true,
                component: CDashboard,
              },
              {
                path: "/coach/dashboard/appointments",
                exact: true,
                component: CAppointments,
              },
              {
                path: "/coach/dashboard/notifications",
                exact: true,
                component: Notification,
              },
              {
                path: "/coach/dashboard/availability",
                exact: true,
                component: Availablity,
              },
              {
                path: "/coach/dashboard/myprofile",
                exact: true,
                component: CProfile,
              },
              {
                path: "/coach/dashboard/myprofile?scope=scope&code=code",
                exact: true,
                component: CProfile,
              },
              {
                path: "/coach/dashboard/package_lists",
                exact: true,
                component: Packages,
              },
              {
                path: "/coach/dashboard/createpackage",
                exact: true,
                component: CreatePackage,
              },
              {
                path: "/coach/dashboard/editpackage/:package_id",
                exact: true,
                component: EditPackage,
              },
              {
                path: "/coach/dashboard/new_session",
                exact: true,
                component: VideoStart,
              },
            ],
          },
        ],
      },
      {
        path: "/user",
        component: LoginLayout,
        routes: [
          {
            path: "/user/login",
            exact: true,
            component: Login,
          },
          {
            path: "/user/login/:id",
            exact: true,
            component: Login,
          },
          {
            path: "/user/signup",
            exact: true,
            component: Signup,
          },
          {
            path: "/user/forgot-password/",
            component: ForgotPassword,
          },
          {
            path: "/user/request/reset-password/",
            component: Forgot,
          },
        ],
      },

      {
        path: "/coach",
        component: LoginLayout,
        routes: [
          {
            path: "/coach/login",
            exact: true,
            component: Login,
          },
          {
            path: "/coach/login/:email_id/:id",
            exact: true,
            component: Login,
          },
        ],
      },
      {
        path: "/forgot_password",
        component: LoginLayout,
        routes: [
          {
            path: "/forgot_password",
            exact: true,
            component: Forgot,
          },
        ],
      },
      {
        path: "/session/new_session",
        component: SessionLayout,
        routes: [
          {
            path: "/session/new_session",
            component: SessionWrapper,
            routes: [
              {
                path: "/session/new_session",
                exact: true,
                component: VideoSession,
              },
            ],
          },
        ],
      },
      {
        path: "/startSession/session",
        component: SessionLayout,
        routes: [
          {
            path: "/startSession/session",
            component: SessionWrapper,
            routes: [
              {
                path: "/startSession/session",
                exact: true,
                component: VideoSession,
              },
            ],
          },
        ],
      },
      {
        path: "/packages/:id",
        component: packageLayout,
        routes: [
          {
            path: "/packages/:id",
            component: SelectWrapper,
            routes: [
              // {
              //   path: "/packages/:id",
              //   exact: true,
              //   component: CListing,
              // },
              {
                path: "/packages/:id/create-booking",
                exact: true,
                component: Checkout,
              },
            ],
          },
        ],
      },
      {
        path: "",
        component: CoreLayout,
        routes: [
          {
            path: "*",
            component: Error404,
          },
        ],
      },
    ],
  },
];

/*  Note: Instead of using JSX, we recommend using react-router
 PlainRoute objects to build route definitions. */

export const createRoutes = () => {
  return renderRoutes(routes);
};

export default createRoutes;
