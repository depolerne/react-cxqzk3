import React from "react";
import {
  actions
} from "../modules/AddListings";

import { bindActionCreators } from "redux";
import AddListingsView from "../components/AddListingsView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  AddListingState: state.AddListingState,
  auth: state.auth,
});

export default connect(mapStateToProps, mapDispatchToProps)(AddListingsView);
