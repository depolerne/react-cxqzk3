import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import auth from "../../../helpers/auth";

export class SavedView extends React.Component {
  constructor(props) {
    super(props);
    // if (auth.isAuthenticated) {
    //   this.props.history.push("/connect/home");
    // }
  }
  render() {
    return (
      <Fragment>
        <div className="main-content yss-site--main__content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Thank <span>You For Signing Up!</span>
                </h3>
              </div>
              <div className="site__form middle__content add-listing--form">
                <div className="form-item form-item--login__required">
                  <span>
                    Listing submitted successfully.Your Listing will be visible
                    once it will be approved.</span><br/>
                  <span>
                    To complete your Profile go to your Dashboard.
                  </span>
                  <Link
                    to="/coach/dashboard"
                    className="login-rquired__button"
                  >
                    Go to your Dashboard
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}
