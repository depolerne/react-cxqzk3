import React, { Fragment } from "react";
import { connect } from "react-redux";
import { actions } from "../../AddListings/modules/AddListings";
import { bindActionCreators } from "redux";
import { Link } from "react-router-dom";
import ReactPlayer from "react-player";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import auth from "../../../helpers/auth";

export class AddListingPreview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.redirectBack = this.redirectBack.bind(this);
    if (!this.props.AddListingState.listingData.email) {
      this.props.history.push("/add-your-listings");
    }
  }

  componentDidMount() {
    let body = document.body;
    body.className = "add_listings_preview";
  }

  redirectBack() {
    this.props.history.push("/add-your-listings");
  }

  render() {
    let {
      listingData,
      lables,
      categories,
      addListingSpinner,
    } = this.props.AddListingState;
    const Labels = listingData.listing_label.map((item) => {
      lables &&
        listingData &&
        listingData.listing_label.map((item) => (
          <li>
            <i className="fas fa-tag"></i>{" "}
            {lables.find((i) => i.value === item).label}
          </li>
        ));
    });

    const CreateAccountBlock = !auth.isAuthenticated ? (
      <div className="information_block listing__description create-account__block">
      <span className="description__text">
        If you want to get started quikly please create an account so you can
        view appointments available today
      </span>
      <span className="description__btn">
        <Link
          to="#"
          className="create-account__btn text-center"
          onClick={() => this.props.setAuthModal("signup")}
        >
          Create account
        </Link>
      </span>
    </div>
    ) : null;
    return (
      <Fragment>
        <div className="main-content yss-site--main__content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Preview Your <span>Listing</span>
                </h3>
              </div>
              <form className="listing__preview">
                <div className="form-actions">
                  <button
                    onClick={() => this.redirectBack()}
                    type="button"
                    name="listing_edit"
                  >
                    Edit Listing
                  </button>
                  <button
                    type="button"
                    name="listing_continue"
                    onClick={() =>
                      this.props.submitListing({
                        ...listingData,
                        history: this.props.history,
                      })
                    }
                  >
                    {addListingSpinner ? <LoadingSpinner /> : "Submit Listing"}
                  </button>
                </div>
                {/* Listing details for preview */}
                <div className="job_listing_preview single-job_listing">
                  <div className="cover__pic--wrapper">
                    <div className="cover__pic">
                      <img src={listingData.cover_img} />
                    </div>

                    <div className="cover__content">
                      <div className="coevr__left w-full md:w-3/5 md:pr-2">
                        <h2 className="listing__name">{listingData.name}</h2>
                        <div className="mt-4 listing__location">
                          {listingData.location}
                        </div>
                        <div className="mt-4 listing_category">
                          <span className="category__name">
                            <a href="#">
                              {
                                categories.find(
                                  (i) => i.value == listingData.listing_category
                                ).label
                              }
                            </a>
                          </span>
                        </div>
                        <div className="mt-4 listing-rating listing-rating--card">
                          <span className="listing-stars listing-stars--card">
                            <span className="listing-star">
                              <i className="fas fa-star"></i>
                            </span>
                            <span className="listing-star">
                              <i className="fas fa-star"></i>
                            </span>
                            <span className="listing-star listing-star--empty">
                              <i className="far fa-star"></i>
                            </span>
                            <span className="listing-star listing-star--empty">
                              <i className="far fa-star"></i>
                            </span>
                            <span className="listing-star listing-star--empty">
                              <i className="far fa-star"></i>
                            </span>
                          </span>
                          <span className="listing-rating-count listing-rating-count--card">
                            <Link to="#">0 Reviews</Link>
                          </span>
                        </div>
                      </div>

                      {/* <div className="coevr__right w-full md:w-2/5 md:pl-2">
                        <div className="write__review text-right btn">
                          <a className="w-auto pointer-events-none" href="#">
                            Write Review
                          </a>
                        </div>
                      </div> */}
                    </div>
                  </div>
                  <div className="listing-other-details lg:flex">
                    <div className="w-full lg:w-2/3 lg:pr-4">
                      {CreateAccountBlock}
                      <div
                        className="information_block listing__description"
                        dangerouslySetInnerHTML={{
                          __html: listingData.description,
                        }}
                      ></div>
                      {CreateAccountBlock}
                      {listingData.video_url ? (
                        <div className="information_block listing__video">
                          <h2>
                            <i className="fas fa-film"></i> Video
                          </h2>
                          <div className="video__block">
                            <ReactPlayer url={listingData.video_url} />
                          </div>
                        </div>
                      ) : null}
                    </div>

                    <div className="w-full lg:w-1/3 lg:pl-4">
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-camera"></i> Photo Gallery
                        </h2>
                        <ul className="gallery__images">
                          {listingData.gallery_images.map((i) => {
                            return (
                              <Fragment>
                                <li>
                                  <img src={i} />
                                </li>
                              </Fragment>
                            );
                          })}
                        </ul>
                      </div>
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-music"></i> SOBERLISTIC RADIO
                        </h2>
                        <img src="/images/radio.jpg" />
                      </div>
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-lightbulb"></i> SOBERLISTIC
                          COURSES
                        </h2>
                        <img src="/images/yoga.jpg" />
                      </div>
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-lightbulb"></i> SOBERLISTIC
                          ARTICLES
                        </h2>
                        <img src="/images/sthetoscope.jpg" />
                      </div>
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-lightbulb"></i> SPONSERS
                        </h2>
                        <img src="images/doc_1.jpg" />
                      </div>
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-lightbulb"></i> SPONSERS
                        </h2>
                        <img src="/images/nutritions.jpg" />
                      </div>
                      <div className="information_block listing__gallery">
                        <h2>
                          <i className="fas fa-lightbulb"></i> SPONSERS
                        </h2>
                        <img src="/images/ani.jpg" />
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CDashboardState: state.CDashboardState,
  AddListingState: state.AddListingState,
});

export default connect(mapStateToProps, mapDispatchToProps)(AddListingPreview);
