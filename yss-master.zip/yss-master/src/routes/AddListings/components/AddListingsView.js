import React, { Fragment } from "react";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import { Link } from "react-router-dom";
import { ZoneList } from "../../../helpers/ZoneList";
import { FormValidator } from "../../../helpers/FormValidator";

import auth from "../../../helpers/auth";
import Select from "react-select";
import { Editor } from "@tinymce/tinymce-react";
import MapInput from "../../../components/MapInput/MapInput";
import Dropzone from "react-dropzone";
import MultiSelecter from "../../../components/Multiselect/MultiSelecter";

import PlacesAutocomplete, {
  geocodeByAddress,
  getLatLng,
  // getInputProps,
} from "react-places-autocomplete";

export class AddListingsView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errClass: "",
      address: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.editorHandleChange = this.editorHandleChange.bind(this);
    this.handleLocation = this.handleLocation.bind(this);
    this.handleMultiSelect = this.handleMultiSelect.bind(this);
    this.handleLocationSelect = this.handleLocationSelect.bind(this);
    this.showPreview = this.showPreview.bind(this);
    this.handleImg = this.handleImg.bind(this);
    this.submitData = this.submitData.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.onDrop = this.onDrop.bind(this);
    this.removeGallery = this.removeGallery.bind(this);
    if (auth.isAuthenticated) {
      this.props.history.push("/");
    }
  }

  componentDidMount() {
    let body = document.body;
    body.className = "add_your_listings";
    this.props.fetchCategory();
    this.props.fetchLables();
    this.props.fetchRegions();
    // var script = document.createElement("script");
    // script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyCzf8RXQS27SPKYkdq6UMdZV0JctvWNFv0&libraries=places`;
    // script.async = true;
    // document.head.appendChild(script);
  }

  handleLocation(value) {
    let { listingData } = this.props.AddListingState;
    listingData["location"] = value;
    this.props.setAddListingData(listingData);
  }

  async handleLocationSelect(address) {
    //console.log(address);
    let { listingData } = this.props.AddListingState;
    const results = await geocodeByAddress(address);
    const latLng = await getLatLng(results[0]);
    listingData["lattitude"] = latLng.lat;
    listingData["longitude"] = latLng.lng;
    listingData["location"] = address;
    this.props.setAddListingData(listingData);
  }

  async handleImg(event) {
    let { listingData } = this.props.AddListingState;
    let name = event.target.name;
    let { files } = event.target;
    console.log(files[0].name);
    if (!files[0].name.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
      jQuery("input[name='"+name+"']").val("");
      this.props.setSiteAlertMessage({
        message: "The Image type must be JPEG, JPG, PNG",
        color: "teal",
      });

      listingData[name] = null;
      this.props.setAddListingData(listingData);

    } else if (files[0].size > 8000000) {
      jQuery("input[name='"+name+"']").val("");
      this.props.setSiteAlertMessage({
        message: "The Image size must be less than 8 MB",
        color: "teal",
      });

      listingData[name] = null;
      this.props.setAddListingData(listingData);
      //---> Disappearing the Alert Message after 3 sec
    } else {
      let reader = new FileReader();
      reader.readAsDataURL(files[0]);
      reader.onload = (e) => {
        listingData[name] = e.target.result;
        this.props.setAddListingData(listingData);
      };
    }
    setTimeout(() => {
      this.props.setSiteAlertMessage({
        message: "",
        color: "",
      });
    }, 5000);
  }

  handleSelect(selected, event) {
    let { listingData } = this.props.AddListingState;
    listingData[event.name] = selected.value;
    this.props.setAddListingData(listingData);
  }

  handleMultiSelect = async (id, selectedList) => {
    let { listingData } = this.props.AddListingState;
    let arr = [];
    selectedList.map((item) => arr.push(item.value));
    listingData[id] = arr;
    this.props.setAddListingData(listingData);
  };

  handleChange(e) {
    let { listingData } = this.props.AddListingState;
    let name = e.target.name;
    let value = e.target.value;
    listingData[name] = value;
    this.props.setAddListingData(listingData);
  }

  removeGallery(img) {
    let {
      listingData,
      listingData: { gallery_images },
    } = this.props.AddListingState;
    gallery_images = gallery_images.filter((i) => i !== img);
    listingData["gallery_images"] = gallery_images;
    this.props.setAddListingData(listingData);
  }

  onDrop(files) {
    let { listingData } = this.props.AddListingState;
    let img_arr = [];
    if (files.length + listingData.gallery_images.length > 6) {
      this.props.setSiteAlertMessage({
        message: "You can only select 6 images.",
        color: "teal",
      });
    } else {
      Object.keys(files).map((item, i) => {
        if (!files[item].name.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
          this.props.setSiteAlertMessage({
            message: "The Image type must be JPEG, JPG, PNG",
            color: "teal",
          });
        } else if (files[item].size > 8000000) {
          this.props.setSiteAlertMessage({
            message: "Image size should not be more than 8 MB.",
            color: "teal",
          });
        } else {
          let reader = new FileReader();
          reader.readAsDataURL(files[item]);
          reader.onload = (e) => {
            if (!listingData.gallery_images.includes(e.target.result)) {
              listingData["gallery_images"].push(e.target.result);
            }
            img_arr.push(e.target.result);
          };
        }
      });
      console.log(listingData)
      this.props.setAddListingData(listingData);
    }
    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
    }, 5000);
  }

  editorHandleChange(value) {
    let { listingData } = this.props.AddListingState;
    listingData["description"] = value;
    this.props.setAddListingData(listingData);
  }

  showPreview(e) {
    e.preventDefault();
    let { listingData } = this.props.AddListingState;
    let { err, errClass } = FormValidator(listingData);

    if (!err) {
      this.props.history.push("/listing-preview");
    } else {
      this.props.setSiteAlertMessage({
        message: err.message,
        color: err.color,
      });
      this.setState({ errClass: errClass });
    }

    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
      this.setState({ errClass: "" });
    }, 5000);
  }

  submitData(e) {
    e.preventDefault();
    let { listingData } = this.props.AddListingState;
    let { err, errClass } = FormValidator(listingData);
    console.log(err);
    if (!err) {
      this.props.submitListing({ ...listingData, history: this.props.history });
    } else {
      this.props.setSiteAlertMessage({
        message: err.message,
        color: err.color,
      });
      this.setState({ errClass: errClass });
    }
    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
      this.setState({ errClass: "" });
    }, 5000);
  }

  render() {
    let {
      listingData,
      addListingSpinner,
      categories,
      lables,
      regions,
    } = this.props.AddListingState;
    let { errClass } = this.state;

    return (
      <Fragment>
        <div className="main-content yss-site--main__content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Add Your <span>Listing</span>
                </h3>
              </div>
              <div className="site__form middle__content add-listing--form">
                <form className="clearfix" onSubmit={(e) => this.submitData(e)}>
                  {!auth.isAuthenticated ? (
                    <div className="form-item form-item--login__required">
                      <span>
                        If you don't have an account you can create one below by
                        entering your email address/username. Your account
                        details will be confirmed via email.
                      </span>
                      <Link
                        to="/coach/login"
                        className="login-rquired__button"
                      >
                        Sign In
                      </Link>
                    </div>
                  ) : null}
                  <div className="form-item">
                    <div className="form-label">Email:</div>
                    <input
                      className={
                        errClass == "email"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="text"
                      name="email"
                      placeholder="you@yourdomain.com"
                      onChange={this.handleChange}
                      value={listingData.email}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Username:</div>
                    <input
                      className={
                        errClass == "username"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="text"
                      name="name"
                      onChange={this.handleChange}
                      value={listingData.name}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Password:</div>
                    <input
                      className={
                        errClass == "password"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="password"
                      name="password"
                      onChange={this.handleChange}
                      value={listingData.password}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Confirm Password:</div>
                    <input
                      className={
                        errClass == "c_password"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="password"
                      name="c_password"
                      onChange={this.handleChange}
                      value={listingData.c_password}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Listing Name:</div>
                    <input
                      className={
                        errClass == "listing_name"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="text"
                      name="listing_name"
                      placeholder="Your listing name"
                      onChange={this.handleChange}
                      value={listingData.listing_name}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item">
                    <div className="form-label">Location :</div>
                    <PlacesAutocomplete
                      value={listingData.location}
                      onChange={this.handleLocation}
                      onSelect={this.handleLocationSelect}
                    >
                      {({
                        getInputProps,
                        getSuggestionItemProps,
                        suggestions,
                        loading,
                      }) => {
                        return (
                          <div className="autocomplete-root">
                            <input
                              {...getInputProps({
                                placeholder: "Enter the location",
                                className:
                                  errClass === "location"
                                    ? "location-search-input border-red-500"
                                    : "location-search-input border-color-blue",
                              })}
                            />

                            <div className="autocomplete-dropdown-container">
                              {loading && <div>Loading...</div>}
                              {suggestions.map((suggestion, i) => {
                                const className = suggestion.active
                                  ? "suggestion-item--active"
                                  : "suggestion-item";
                                // inline style for demonstration purpose
                                const style = suggestion.active
                                  ? {
                                      backgroundColor: "#fafafa",
                                      cursor: "pointer",
                                    }
                                  : {
                                      backgroundColor: "#ffffff",
                                      cursor: "pointer",
                                    };
                                return (
                                  <div
                                    key={i}
                                    {...getSuggestionItemProps(suggestion, {
                                      className,
                                      style,
                                    })}
                                  >
                                    <span key={suggestion}>
                                      {suggestion.description}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      }}
                    </PlacesAutocomplete>
                    {/* <MapInput fireData={(add,lat,lng)=>this.handleLocationSelect()}/> */}
                  </div>
                  {/*<div className="form-item">
                    <div className="form-label">
                      Contact Email/URL : (optional)
                    </div>
                    <input
                      className={
                        errClass == "contact_email_or_url"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="text"
                      name="contact_email_or_url"
                      placeholder="Enter an email address or website url"
                      onChange={this.handleChange}
                      value={listingData.contact_email_or_url}
                      autoComplete="off"
                    />
                    </div>*/}
                  <div className="form-item">
                    <div className="form-label">Description: </div>
                    <Editor
                      apiKey="a9ko3r2y3k9l644lkbwctig4dtth7vdm9dtixph76ctyqiy5"
                      value={listingData.description}
                      name="description"
                      init={{
                        height: 300,
                        //menubar: 'insert',
                        plugins: [
                          "advlist autolink lists link image charmap print preview anchor",
                          "searchreplace visualblocks code fullscreen",
                          "insertdatetime media table paste imagetools",
                        ],
                        toolbar:
                          "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
                      }}
                      onEditorChange={this.editorHandleChange}
                    />
                  </div>

                  {categories ? (
                    <div className="form-item">
                      <label>Listing Category:</label>
                      <Select
                        name={"listing_category"}
                        className="new_select"
                        options={categories}
                        value={categories.filter((option) => {
                          return option.value === listingData.listing_category;
                        })}
                        onChange={this.handleSelect}
                        searchable={true}
                      />
                    </div>
                  ) : null}

                  <div className="form-item">
                    <label>Listing Region:</label>
                    <Select
                      name={"listing_region"}
                      className="new_select"
                      options={regions}
                      value={regions.filter((option) => {
                        return option.value === listingData.listing_region;
                      })}
                      onChange={this.handleSelect}
                      searchable={true}
                    />
                  </div>

                  <div className="form-item">
                    <label>Timezone :</label>

                    <Select
                      name={"timezone"}
                      className="new_select"
                      options={ZoneList}
                      value={ZoneList.filter((option) => {
                        return option.value === listingData.timezone;
                      })}
                      onChange={this.handleSelect}
                      searchable={true}
                    />
                  </div>

                  <div className="form-item">
                    <label>Listing Lables (optional) :</label>

                    <MultiSelecter
                      id="listing_label"
                      Options={lables}
                      displayValue={"label"}
                      fireData={(id, selectedList) =>
                        this.handleMultiSelect(id, selectedList)
                      }
                    />
                    <div className="form-description">
                      <p>Choose labels for this listing. Maximum of 3.</p>
                    </div>
                  </div>

                  <div className="form-item file_upload-field">
                    <label>Cover Image</label>
                    <input
                      name="cover_img"
                      type="file"
                      onChange={this.handleImg}
                    />
                    <div className="file_desc">
                      <p>Maximum file size: 8 MB.</p>
                    </div>
                    <img
                      key={listingData.cover_img}
                      className="md:ml-48 max-w-sm my-5"
                      src={listingData.cover_img}
                    />
                  </div>

                  <div className="form-item file_upload-field">
                    <label>Gallery images</label>
                    {/* <input
                      name="gallery_images"
                      type="file"
                      onChange={this.handleImg}
                      multiple
                    />
                    <div className="file_desc">
                      <p>Maximum file size: 8 MB.</p>
                    </div> */}
                    <Dropzone onDrop={this.onDrop} maxFiles={10}>
                      {({ getRootProps, getInputProps }) => (
                        <section className="container">
                          <div {...getRootProps({ className: "dropzone" })}>
                            <input {...getInputProps()} />
                            <p>
                              Drag 'n' drop some files here, or click to select
                              files
                            </p>
                          </div>
                        </section>
                      )}
                    </Dropzone>
                  </div>
                  <div className="listing__gallery">
                    <ul className="gallery__images flex">
                      {listingData.gallery_images.map((src, i) => {
                        return (
                          <Fragment key={i}>
                            <li>
                              <a
                                className="remove-image"
                                style={{ cursor: "pointer" }}
                                onClick={() => this.removeGallery(src)}
                              >
                                &#215;
                              </a>
                              <img src={src} key={i} />
                            </li>
                          </Fragment>
                        );
                      })}
                    </ul>
                  </div>

                  {/*<div className="form-item">
                    <div className="form-label">Website (optional) : </div>
                    <input
                      className={
                        errClass == "listing_name"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="url"
                      name="website"
                      placeholder="https://www.example.com"
                      onChange={this.handleChange}
                      value={listingData.website}
                      autoComplete="off"
                      className={
                        errClass == "website"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                    />
                    </div>*/}
                  {/*<div className="form-item">
                    <div className="form-label">Phone Number : (optional)</div>
                    <input
                      className={
                        errClass == "listing_name"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="number"
                      name="phone"
                      placeholder="Phone Number"
                      onChange={this.handleChange}
                      value={listingData.phone}
                      autoComplete="off"
                      className={
                        errClass == "phone"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                    />
  </div>*/}

                  <div className="form-item">
                    <div className="form-label">Video : (optional)</div>
                    <input
                      className={
                        errClass == "video_url"
                          ? "border-red-500"
                          : "border-color-blue"
                      }
                      type="url"
                      name="video_url"
                      placeholder="Url to video"
                      onChange={this.handleChange}
                      value={listingData.video_url}
                      autoComplete="off"
                    />
                  </div>
                  <div className="form-item file_upload-field">
                    <label>Insurance Certificate (optional) </label>
                    <input
                      name="insurance_certificate"
                      type="file"
                      onChange={this.handleImg}
                    />
                    <div className="file_desc">
                      <p>Maximum file size: 8 MB.</p>
                    </div>
                    <img
                      key={listingData.insurance_certificate}
                      className="md:ml-48 max-w-sm my-5"
                      src={listingData.insurance_certificate}
                    />
                  </div>
                  <div className="form-item file_upload-field">
                    <label>Business Certificate (optional)</label>
                    <input
                      name="business_certificate"
                      type="file"
                      onChange={this.handleImg}
                    />
                    <div className="file_desc">
                      <p>Maximum file size: 8 MB.</p>
                    </div>
                    <img
                      key={listingData.business_certificate}
                      className="md:ml-48 max-w-sm my-5"
                      src={listingData.business_certificate}
                    />
                  </div>
                  <div className="form-grid">
                    <div className="form-actions">
                      <button type="submit">
                        {addListingSpinner ? <LoadingSpinner /> : "Add Listing"}
                      </button>
                      <button
                        type="button"
                        onClick={(e) => this.showPreview(e)}
                      >
                        Preview
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default AddListingsView;
