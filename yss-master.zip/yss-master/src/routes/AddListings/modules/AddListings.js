import fetch from "isomorphic-fetch";
import _get from "lodash/get";
import { setSiteAlertMessage } from "../../SiteWrapper/modules/site";
import auth from "../../../helpers/auth";
import { setUserDataInState } from "../../login/modules/auth";
import { setAlertMessage } from "../../selectWrapper/modules/select";

export const SET_ADD_LISTINGS_FORM_DATA = "SET_ADD_LISTINGS_FORM_DATA";
export const SET_ADD_LISTINGS_SPINNER_STATUS =
  "SET_ADD_LISTINGS_SPINNER_STATUS";
export const SET_ADD_LISTINGS_REGIONS = "SET_ADD_LISTINGS_REGIONS";
export const SET_ADD_LISTINGS_LABLES = "SET_ADD_LISTINGS_LABLES";
export const SET_ADD_LISTINGS_CATEGORY = "SET_ADD_LISTINGS_CATEGORY";

//---> Fetching userDate and Saving the user data into the redux state

export const setAddListingData = (data) => {
  return {
    type: SET_ADD_LISTINGS_FORM_DATA,
    payload: data,
  };
};

export const setAddListingSpinner = (flag) => {
  return {
    type: SET_ADD_LISTINGS_SPINNER_STATUS,
    payload: flag,
  };
};

export const setListingCategories = (data) => {
  return {
    type: SET_ADD_LISTINGS_CATEGORY,
    payload: data,
  };
};

export const setListingsRegions = (data) => {
  return {
    type: SET_ADD_LISTINGS_REGIONS,
    payload: data,
  };
};

export const setListingsLables = (data) => {
  return {
    type: SET_ADD_LISTINGS_LABLES,
    payload: data,
  };
};


export function submitListing(data) {
  return async (dispatch) => {
    await dispatch(addListings(data));
  };
}


export function fetchCategory() {
  return async (dispatch) => {
    try {
      let category = await fetch(`${__API__}/get/listing/category`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await category.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setListingCategories(response.categories));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchRegions() {
  return async (dispatch) => {
    try {
      let regions = await fetch(`${__API__}/get/listing/region`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await regions.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setListingsRegions(response.regions));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchLables() {
  return async (dispatch) => {
    try {
      let lables = await fetch(`${__API__}/get/listing/label`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await lables.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setListingsLables(response.labels));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function addListings(data) {
  return async (dispatch) => {
    let bodyData = {
      params: data,
    };
    await dispatch(setAddListingSpinner(true));
    try {
      let result = await fetch(`${__API__}/add/listing`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(bodyData),
      });
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
        await dispatch(setAddListingSpinner(false));
      } else if (response.success) {
        await dispatch(setAddListingSpinner(false));
        await dispatch(setUserDataInState(response.user_data));
        await auth.setTokens(response.token, response.user_data.roles.role);
        data.history.push("/welcome");
        await dispatch(
          setAlertMessage({
            message: "Listing added successfully",
            color: "green",
          })
        );
      }
    } catch (e) {
      await dispatch(setAddListingSpinner(false));
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
  };
}

export const actions = {
  setAddListingData,
  setSiteAlertMessage,
  setAddListingSpinner,
  setListingCategories,
  setListingsLables,
  setListingsRegions,
  fetchCategory,
  fetchLables,
  fetchRegions,
  addListings,
  submitListing
};

const initialState = {
  listingData: {
    email: "",
    name: "",
    password: "",
    c_password: "",
    listing_name: "",
    location: "",
    contact_email_or_url: "",
    description: "",
    listing_category: "",
    listing_region: "",
    listing_label: [],
    cover_img: "",
    gallery_images: [],
    timezone: "",
    website: "",
    phone: "",
    video_url: "",
    lattitude: "",
    longitude: "",
    insurance_certificate: "",
    business_certificate: ""
  },
  addListingSpinner: false,
  categories: [],
  lables: [],
  regions: [],
  submit_listing: false,
};

const ACTION_HANDLERS = {
  [SET_ADD_LISTINGS_FORM_DATA]: (state, action) => {
    console.log(action.payload);
    return {
      ...state,
      listingData: action.payload,
    };
  },
  [SET_ADD_LISTINGS_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      addListingSpinner: action.payload,
    };
  },
  [SET_ADD_LISTINGS_CATEGORY]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["category_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].category_name;
      delete action.payload[i].id;
    }
    return {
      ...state,
      categories: action.payload,
    };
  },
  [SET_ADD_LISTINGS_LABLES]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["label_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].label_name;
      delete action.payload[i].id;
    }
    action.payload.push({ label: "Other", value: "0" });
    return {
      ...state,
      lables: action.payload,
    };
  },
  [SET_ADD_LISTINGS_REGIONS]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["region_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].region_name;
      delete action.payload[i].id;
    }
    return {
      ...state,
      regions: action.payload,
    };
  },
};

export default function AddListingReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
