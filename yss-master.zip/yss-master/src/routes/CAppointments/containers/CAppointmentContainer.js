import React from "react";
import { actions, fetchBooking } from "../modules/CAppointment";
import { bindActionCreators } from "redux";
import CAppointmentView from "../components/CAppointmentView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  CAppointmentState: state.CAppointmentState,
  CDashboardState: state.CDashboardState,
  selectState:state.selectState
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {
      // dispatch(fetchBooking());
  },
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(CAppointmentView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
