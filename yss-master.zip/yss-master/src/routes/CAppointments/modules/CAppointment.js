import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import { result } from "lodash";
import {
  setAlertMessage,
  setMenuHover,
  setChannelId,
  saveSessionData,
  setRequestSender,
  saveCallHistory,
  setCallDuration,
} from "../../selectWrapper/modules/select";
import { setCallStatus,setCurrentSession } from "../../VideoSession/modules/VideoSession";

//---> Defining types for different actions

export const SET_APPOINTMENTS_TODAY_DATA = "SET_APPOINTMENTS_TODAY_DATA";
export const SET_APPOINTMENTS_PAST_DATA = "SET_APPOINTMENTS_PAST_DATA";
export const SET_APPOINTMENTS_UPCOMING_DATA = "SET_APPOINTMENTS_UPCOMING_DATA";
export const SET_APPOINTMENTS_ERR_MESSAGE = "SET_APPOINTMENTS_ERR_MESSAGE";
export const SET_SESSION_ERR_MESSAGE = "SET_SESSION_ERR_MESSAGE";
export const SET_APPOINTMENTS_SPINNER_STATUS =
  "SET_APPOINTMENTS_SPINNER_STATUS";
export const SET_APPOINTMENTS_BY_WEEK = "SET_APPOINTMENTS_BY_WEEK";
export const SET_ONGOING_APPOINTMENTS = "SET_ONGOING_APPOINTMENTS";
export const SET_START_SESSION_SPINNER = "SET_START_SESSION_SPINNER";
//---> Defining Actions to set state variables

export const setPastAppointments = (pastData) => {
  return {
    type: SET_APPOINTMENTS_PAST_DATA,
    payload: pastData,
  };
};

export const setAppointmentsByWeek = (weekData) => {
  return {
    type: SET_APPOINTMENTS_BY_WEEK,
    payload: weekData,
  };
};

export const setTodayAppointments = (todayData) => {
  return {
    type: SET_APPOINTMENTS_TODAY_DATA,
    payload: todayData,
  };
};

export const setUpcomingAppointments = (UpcomingData) => {
  return {
    type: SET_APPOINTMENTS_UPCOMING_DATA,
    payload: UpcomingData,
  };
};

export const setSpinnerStatus = (status) => {
  return {
    type: SET_APPOINTMENTS_SPINNER_STATUS,
    payload: status,
  };
};

export const setCurrentPage = (page) => {
  return {
    type: SET_PAGINATION_CURRENT_PAGE,
    payload: page,
  };
};

export const setOngoingAppointments = (data) => {
  return {
    type: SET_ONGOING_APPOINTMENTS,
    payload: data,
  };
};

export const setAskToJoinSpinner = (flag) => {
  return {
    type: SET_START_SESSION_SPINNER,
    payload: flag,
  };
};

export function CancelAppointment(deleteItemId) {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    if (token) {
      try {
        await fetch(`${__API__}/api/v1.0/Appointment/${deleteItemId}`, {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        await dispatch(setAlertMessage(deleteItemId));
      } catch (e) {
        console.log(e);
      }
    }
  };
}

export const fetchPastBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/past/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setPastAppointments(response.past));
          await dispatch(setSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchUpcomingBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/upcoming/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setUpcomingAppointments(response.upcoming));
          await dispatch(setSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchTodayBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/todays/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setSpinnerStatus(false));
        } else if (response.success) {
          if (current_page > -1) {
            await dispatch(setTodayAppointments(response.todays));
          } else if (current_page == -1) {
            await dispatch(setOngoingAppointments(response.todays));
          }
          await dispatch(setSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const fetchWeekBookings = (current_page) => {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    await dispatch(setSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/get/current/week/booking?page=${current_page}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setAppointmentsByWeek(response.current_week));
          await dispatch(setSpinnerStatus(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setSpinnerStatus(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "No account details available",
          color: "teal",
        })
      );
      await dispatch(setSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export function initiateSession(data) {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/join-session?from_id=${data.from_id}&to_id=${data.to_id}&booking_id=${data.booking_id}&timing=${data.minutes}&channel_id=${data.channel}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();

        if (!response.success) {
          await dispatch(
            setAlertMessage({
              message:
                "Can't start the session Please try again after some time!",
              color: "teal",
            })
          );
        } else if (response.success) {
          // await data.history.push('/session/new_session');
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error. Please try after some time.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(
        setAlertMessage({
          message: "",
          color: "",
        })
      );
    }, 3000);
  };
}

//---> exporting multiple functions and actions
export const actions = {
  setUpcomingAppointments,
  setPastAppointments,
  setSpinnerStatus,
  setAlertMessage,
  fetchPastBookings,
  fetchUpcomingBookings,
  fetchTodayBookings,
  fetchWeekBookings,
  setMenuHover,
  saveSessionData,
  setAskToJoinSpinner,
  initiateSession,
  setChannelId,
  setRequestSender,
  saveCallHistory,
  setCallDuration,
  setCallStatus,
  setCurrentSession  

};

//---> defining the initialState for state variables

const initialState = {
  todayAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  weekAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  pastAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  upcomingAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  spinner: false,
  sessionSpinner: false,
  updatedData: "",
  ongoingAppointments: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_APPOINTMENTS_BY_WEEK]: (state, action) => {
    return {
      ...state,
      weekAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },
  [SET_APPOINTMENTS_PAST_DATA]: (state, action) => {
    return {
      ...state,
      pastAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },
  [SET_APPOINTMENTS_TODAY_DATA]: (state, action) => {
    return {
      ...state,
      todayAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },
  [SET_APPOINTMENTS_UPCOMING_DATA]: (state, action) => {
    return {
      ...state,
      upcomingAppointments: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },

  [SET_ONGOING_APPOINTMENTS]: (state, action) => {
    let data = action.payload;
    let bookings = [];
    data.map((i) => {
      let startTime = new Date(
        i.booking_date.split("-")[0] +
          " " +
          i.booking_date.split("-")[1] +
          " " +
          i.booking_date.split("-")[2] +
          "," +
          i.slot
      );
      let currentdate = new Date();
      let minutes = +i.package.session_hours * 60 + +i.package.session_minutes;
      let endTime = new Date(startTime.getTime() + minutes * 60000);
      let newStartTime = new Date(startTime.getTime() - 5 * 60000);
      if (
        currentdate.getTime() >= newStartTime.getTime() &&
        currentdate.getTime() <= endTime.getTime()
      ) {
        bookings.push(i);
      }
    });

    return {
      ...state,
      ongoingAppointments: {
        data: bookings,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },
  [SET_APPOINTMENTS_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      spinner: action.payload,
    };
  },
  [SET_START_SESSION_SPINNER]: (state, action) => {
    return {
      ...state,
      sessionSpinner: action.payload,
    };
  },
};

export default function CAppointmentReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
