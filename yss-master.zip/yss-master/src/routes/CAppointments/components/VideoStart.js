import React, { Fragment } from "react";
import "../../../assets/video.css";
import Webcam from "react-webcam";
import Spinner from "../../../components/Spinner/Spinner";
import { Link } from "react-router-dom";
import { socket } from "../../../helpers/socketHelper";
import { connect } from "react-redux";
import { actions } from "../modules/CAppointment";

export class VideoStart extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      audio: true,
      video: true,
    };
    this.toggleVideo = this.toggleVideo.bind(this);
    this.initRequest = this.initRequest.bind(this);
    this.rejectCall = this.rejectCall.bind(this);
    this.toggleAudio = this.toggleAudio.bind(this);
    this.toggleVideo = this.toggleVideo.bind(this);
    const {
      sessionData: { to_id },
    } = this.props.selectState;

    if (to_id === undefined || to_id === "") {
      this.props.history.push("/dashboard/appointments");
    }
  }

  componentDidMount() {
    let body = document.body;
    body.className = "start_session";

    socket.on("stop_spinner", (data) => {
      if (data.success) {
        this.props.setAskToJoinSpinner(false);
        localStorage.setItem("call_status", "connected");
        this.props.setRequestSender(data.reciever);
        this.props.history.push("/session/new_session");
        this.props.setAlertMessage({
          message: "connecting...",
          color: "green",
        });
      } else {
        let {
          userData: { id },
          sessionData: { booking_id },
        } = this.props.selectState;
        this.props.saveCallHistory(
          "0",
          booking_id,
          id,
          "0",
          data.cut_by,
          "declined"
        );
        this.props.setAskToJoinSpinner(false);
        this.props.setAlertMessage({
          message: "Call declined !!",
          color: "teal",
        });
        localStorage.setItem("call_status", "declined");
      }
      setTimeout(() => {
        this.props.setAlertMessage({ message: "", color: "" });
      }, 5000);
    });
  }

  componentWillUnmount() {
    const { to_id, booking_id } = this.props.selectState.sessionData;
    if (to_id) {
      socket.emit("remove", {
        ...{ id: booking_id, reciever_id: to_id },
      });
    }
    this.props.setAskToJoinSpinner(false);
    this.setState({ video: false });
    const video = document.querySelector("video");
    if (video !== null) {
      const mediaStream = video.srcObject;
      if (mediaStream !== null) {
        const tracks = mediaStream.getTracks();
        tracks[0].stop();
        tracks.forEach((track) => track.stop());
      }
    }
    this.setState({ video: false });
  }

  initRequest() {
    const {
      from_id,
      to_id,
      session_hours,
      session_minutes,
      booking_id,
      username,
      c_id,
      slot,
    } = this.props.selectState.sessionData;

    let {
      userData: { avatar_id, id },
      sessionData,
    } = this.props.selectState;
    
    let minutes = +session_hours * 60 + +session_minutes;
    const channel = Math.random().toString(36).substring(2, 7);

    if (to_id !== undefined || to_id !== "") {
      let obj={
        id: booking_id,
        username: username,
        avatar: avatar_id,
        time: minutes,
        channel_id: channel,
        reciever_id: to_id,
        sender_id: from_id,
        slot: slot,
      }
      socket.emit("new-call", obj);
      this.props.setCurrentSession(obj);
      this.props.setAskToJoinSpinner(true);
      this.props.setChannelId(channel);
      this.props.setCallDuration(minutes);
      this.props.setCallStatus("initiator");
      setTimeout(() => {
        if (localStorage.getItem("call_status") === "ringing") {
          if (to_id) {
            socket.emit("remove", { id: booking_id, reciever_id: to_id });

            localStorage.setItem("call_status", "not_answered");
            this.props.setAlertMessage({
              message: "Call not answered!! Please try again",
              color: "teal",
            });
          }
          this.props.setAskToJoinSpinner(false);
          this.props.saveCallHistory("0", booking_id, id, "0", id, "declined");
        }
        setTimeout(() => {
          this.props.setAlertMessage({ message: "", color: "" });
        }, 5000);
      }, 1800000);
    }
  }

  rejectCall() {
    const { booking_id, to_id } = this.props.selectState.sessionData;
    let {
      userData: { id },
    } = this.props.selectState;
    if (to_id) {
      socket.emit("remove", {
        id: booking_id,
        reciever_id: to_id,
      });

      localStorage.setItem("call_status", "declined");
      this.props.saveCallHistory("0", booking_id, id, "0", id, "declined");
    }
    this.props.setAskToJoinSpinner(false);
  }

  toggleAudio(value) {
    this.setState({ audio: value });
  }

  toggleVideo(value) {
    this.setState({ video: value });
  }

  render() {
    let { sessionSpinner } = this.props.CAppointmentState;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Start <span>Session</span>
                </h3>
              </div>
              <div className="middle__content">
                <div className="video-call-join-session">
                  <div className="webcam__display">
                    <div className="webcam__view">
                      {this.state.video && <Webcam audio={false} />}
                    </div>
                    <div className="webcam--actions">
                      {this.state.audio ? (
                        <Link
                          to="#"
                          onClick={() => this.toggleAudio(false)}
                          className="mic-on cam-control"
                          title="Turn off Mic"
                        >
                          <img src="images/icons/mic-off.png" />
                        </Link>
                      ) : (
                        <Link
                          to="#"
                          onClick={() => this.toggleAudio(true)}
                          className="mic-off cam-control"
                          title="Turn on Mic"
                        >
                          <img src="images/icons/mic-on.png" />
                        </Link>
                      )}
                      {this.state.video ? (
                        <Fragment>
                          <Link
                            to="#"
                            onClick={() => this.toggleVideo(false)}
                            className="cam-on cam-control"
                            title="Turn off Camera"
                          >
                            <img src="images/icons/web-camera-off.png" />
                          </Link>
                        </Fragment>
                      ) : (
                        <Link
                          to="#"
                          onClick={() => this.toggleVideo(true)}
                          className="cam-off cam-control"
                          title="Turn on Camera"
                        >
                          <img src="images/icons/web-camera-on.png" />
                        </Link>
                      )}
                    </div>
                  </div>

                  <div className="video-call__actions">
                    {sessionSpinner ? (
                      <Fragment>
                        <Spinner text={"calling..."} />
                        <div className="call-button">
                          <Link
                            className="ml-2 cut-call"
                            onClick={() => this.rejectCall()}
                            to="#"
                          >
                            <img src="images/icons/cut_call.png" />
                          </Link>
                        </div>
                      </Fragment>
                    ) : (
                      <Fragment>
                        <div className="call-title">
                          <h3>Ready to Join?</h3>
                        </div>
                        <div className="call-button">
                          <Link to="#" onClick={this.initRequest}>
                            Start Call
                          </Link>
                          <Link
                            className="ml-2"
                            to="/coach/dashboard/appointments"
                            onClick={() => this.toggleVideo(false)}
                          >
                            Go back
                          </Link>
                        </div>
                      </Fragment>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  auth: state.auth,
  CAppointmentState: state.CAppointmentState,
});

export default connect(mapStateToProps, actions)(VideoStart);
