import CAppointments from './containers/CAppointmentContainer';
export { CAppointments };
export * from './modules/CAppointment';

export default CAppointments;
