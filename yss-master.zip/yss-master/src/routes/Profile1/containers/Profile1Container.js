import React from "react";
import { actions } from "../modules/Profile1";
import getUserData from "../../login/modules/auth";
import { bindActionCreators } from "redux";
import ProfileView1 from "../components/ProfileView1";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";
import { getCountryCode } from "../modules/Profile1";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ProfileState: state.ProfileState,
  auth: state.auth,
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {
    dispatch(getCountryCode());
  },
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(ProfileView1);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
