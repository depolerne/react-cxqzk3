import Profile1 from './containers/Profile1Container';
export { Profile1 };
export * from './modules/Profile1';

export default Profile1;
