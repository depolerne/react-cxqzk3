import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import _get from "lodash/get";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import Spinner from "../../../components/Spinner/Spinner";
import OtpModal from "../../../components/Modals/OtpModal";
import { NameValidator } from "../../../helpers/NameValidator";
import { ZoneList } from "../../../helpers/ZoneList";
import InsightBlock from "../../../components/InsightBlock/InsightBlock";
import Select from "react-select";

export class ProfileView1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tab: "profile",
      otp: null,
      update: false,
    };

    this.setProfile = this.setProfile.bind(this);
    this.profileHandler = this.profileHandler.bind(this);
    this.handlechange = this.handlechange.bind(this);
    this.changeAvatar = this.changeAvatar.bind(this);
    this.verifyPhone = this.verifyPhone.bind(this);
    this.onsubmitOtp = this.onsubmitOtp.bind(this);
    this.removeAvatar = this.removeAvatar.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleCountryCode=this.handleCountryCode.bind(this);
  }

  async componentDidMount() {
    this.props.setProfileHeader(["Profile"]);
    this._baseUrl = "https://api.soberlistic.com/";
    this.props.getBookingsLength();
    this.props.getUpcomingAppointments();
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  setProfile(tab = "profile") {
    this.setState({
      tab: tab,
    });
  }

  handleSelect(event) {
    let { userData } = this.props.selectState;
    userData["timezone"] = event.value;
    this.props.setUserDataInState(userData);
  }

  handleCountryCode(event){
    let { userData } = this.props.selectState;
    userData["country_code"] = event.value;
    this.props.setUserDataInState(userData);
  }

  handlechange(event) {
    let { userData } = this.props.selectState;
    (event);
    const name = event.target.name;
    const value = event.target.value;
    userData[name] = value;
    this.props.setUserDataInState(userData);
  }

  onsubmitOtp(otp) {
    this.props.verifyPhone({ otp, history: this.props.history });
    setTimeout(() => {
      this.setState({ openModal: false });
    }, 1000);
  }

  async changeAvatar(event) {
    let type = event.target.files[0];
    if (!type.name.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
      jQuery("input[type='file']").val("");
      this.props.setAlertMessage({
        message: "The Image type must be JPEG, JPG, PNG",
        color: "teal",
      });
    } else if (event.target.files[0].size > 12400000) {
      this.props.setAlertMessage({
        message: "The Image size must be less than 10 MB",
        color: "teal",
      });
      //---> Disappearing the Alert Message after 3 sec
    } else {
      const fd = new FormData();
      fd.append("image", event.target.files[0]);
      this._baseUrl = "https://api.soberlistic.com/";
      this.props.updateUserAvatar(fd);
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  verifyPhone() {
    let phFormat = /^[0-9]$/;
    let { userData } = this.props.selectState;
    if (userData.phone === null) {
      this.props.setAlertMessage({
        message: "Please enter a correct mobile number",
        color: "teal",
      });
    } else if (userData.phone.length != 10 || phFormat.test(userData.phone)) {
      this.props.setAlertMessage({
        message: "Please enter a correct mobile number",
        color: "teal",
      });
    } else if (
      userData.country_code == "undefined" ||
      userData.country_code === undefined
    ) {
      this.props.setAlertMessage({
        message: "please select the country code",
        color: "teal",
      });
    } else if (!userData.country_code) {
      this.props.setAlertMessage({
        message: "please select the country code",
        color: "teal",
      });
    } else {
      this.props.sendOtp({ ...userData, history: this.state.history });
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  profileHandler(event) {
    event.preventDefault();
    let { userData } = this.props.selectState;
    let regex = /[!@#$%^`&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
    if (!userData.name) {
      this.props.setAlertMessage({
        message: "Please enter a valid Name!",
        color: "teal",
      });
    } else if (NameValidator(userData.name.replace(/ /g, ""))) {
      this.props.setAlertMessage({
        message: "Name must starts with 3 alphabets",
        color: "teal",
      });
    } else if (userData.name.length > 32) {
      this.props.setAlertMessage({
        message: "Name can't be larger than 32 characters.",
        color: "teal",
      });
    } else if (regex.test(userData.name)) {
      this.props.setAlertMessage({
        message: "Name should not contain special characters.",
        color: "teal",
      });
    } else if (userData.name.replace(/ /g, "").length < 3) {
      // REMOVING whitespaces from the name and then measuring length
      this.props.setAlertMessage({
        message: "Name must contain 3 characters",
        color: "teal",
      });
    } else if (userData.timezone === "select") {
      this.props.setAlertMessage({
        message: "Please select the timezone!!",
        color: "teal",
      });
    } else {
      this.props.saveProfile({ ...userData, history: this.props.history });
    }
    //---> Disappearing the Alert Message after 3 sec

    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  removeAvatar() {
    this.props.deleteuserAvatar();
  }

  render() {
    const {
      countryCodes,
      otpSpinner,
      updateProfileSpinner,
      avatar_spinner,
      openModal,
      profileHeader,
      allBookingsLength,
      upcomingBookingLength,
    } = this.props.ProfileState;

    let codeData = Array.from(countryCodes);
    let { userData, userSpinner } = this.props.selectState;
    let { timezone,country_code } = userData;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            {openModal ? (
              <OtpModal
                sendOtp={this.onsubmitOtp}
                spinnerStatus={otpSpinner}
                cancelEvent={() => this.props.openOtpModal(false)}
              />
            ) : null}
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  {profileHeader[0]} <span>{profileHeader[1]}</span>
                </h3>
              </div>
              <div className="site__form middle__content">
                <div className="tabs__wrapper">
                  <div id="tabs" className="tabs">
                    <ul className="tab_lists">
                      <li
                        className={
                          this.state.tab === "profile"
                            ? "ui-tabs-active"
                            : "ui-tabs"
                        }
                      >
                        <Link
                          to="#"
                          onClick={() => {
                            this.setProfile("profile");
                            this.props.setProfileHeader(["My", "Profile"]);
                          }}
                        >
                          Profile
                        </Link>
                      </li>
                      <li
                        className={
                          this.state.tab === "changePwd"
                            ? "ui-tabs-active"
                            : "ui-tabs"
                        }
                      >
                        <Link
                          to="#"
                          onClick={() => {
                            this.setProfile("changePwd");
                            this.props.setProfileHeader(["Change", "Password"]);
                          }}
                        >
                          Change Password
                        </Link>
                      </li>
                    </ul>
                    <div id="tabs-1">
                      {this.state.tab === "profile" ? (
                        userSpinner ? (
                          <Spinner />
                        ) : (
                          <form
                            className="clearfix profile_form"
                            onSubmit={this.profileHandler}
                          >
                            <div className="form-item profile_pic_right">
                              <label />
                              <div className="pro_pic">
                                {avatar_spinner || userSpinner ? (
                                  <Spinner />
                                ) : (
                                  <img
                                    className="bg-nav w-full"
                                    src={
                                      userData.avatar_id === null
                                        ? "images/user_icon.svg"
                                        : this._baseUrl + userData.avatar_id
                                    }
                                  />
                                )}
                                <span
                                  className="bg-white rounded-full"
                                  onClick={() =>
                                    this.setState({ update: true })
                                  }
                                >
                                  <img src="/images/photograph.svg" />
                                </span>
                                {userData.avatar_id === null ? null : (
                                  <span className="pic_options">
                                    <Link
                                      to="#"
                                      title="Remove Profile Pic"
                                      onClick={this.removeAvatar}
                                    >
                                      <i className="far fa-trash-alt"></i>
                                    </Link>
                                  </span>
                                )}
                                <input
                                  type="file"
                                  name="avatar_id"
                                  onChange={this.changeAvatar}
                                />
                              </div>
                            </div>
                            <div className="form-item">
                              <label>Name</label>
                              <input
                                type="text"
                                placeholder="name"
                                name="name"
                                onChange={this.handlechange}
                                defaultValue={userData.name}
                              />
                            </div>
                            <div className="form-item">
                              <label>e-mail</label>
                              <input
                                type="email"
                                email="email"
                                placeholder="Your Email Address"
                                onChange={this.handlechange}
                                defaultValue={userData.email}
                                disabled={true}
                              />
                            </div>
                            {/* <div className="form-item">
                              <label>Time Zone</label>
                              <div className="first_slot slots">
                                <select
                                  name="timezone"
                                  onChange={this.handlechange}
                                  value={userData.timezone}
                                >
                                  <option>select</option>
                                  {ZoneList.map((item, i) => (
                                    <option key={i} value={item.value}>
                                      {item.label}
                                    </option>
                                  ))}
                                </select>
                              </div>
                            </div> */}
                            <div className="form-item">
                              <label>Time Zone</label>
                              <Select
                                options={ZoneList}
                                value={ZoneList.filter(function (option) {
                                  return option.value === timezone;
                                })}
                                onChange={this.handleSelect}
                              />
                            </div>
                            <div className="form-item">
                              <label>Phone number</label>
                              {/* <div className="first_slot slots">
                                <select
                                  name="country_code"
                                  onChange={this.handlechange}
                                  value={
                                    userData.country_code === null
                                      ? "select"
                                      : userData.country_code
                                  }
                                >
                                  <option>select</option>
                                  {codeData.map((item) => (
                                    <option
                                      key={item.id}
                                      value={item.phonecode}
                                    >
                                      {item.name} {item.phonecode}
                                    </option>
                                  ))}
                                </select>
                              </div> */}
                              <Select
                                options={codeData}
                                value={codeData.filter(function (option) {
                                  return option.phonecode === userData.country_code;
                                })}
                                onChange={this.handleCountryCode}
                              />
                              <input
                                type="number"
                                name="phone"
                                placeholder={"enter phone no."}
                                onChange={this.handlechange}
                                defaultValue={userData.phone}
                              />
                              {userData.is_phone_verified == 1 ? (
                                <img
                                  className="h-6 mx-2"
                                  src="images/green_tick.svg"
                                  alt="Mobile varify"
                                />
                              ) : null}
                              <div className="form-actions ">
                                <label />
                                <Link
                                  to="#"
                                  type="submit"
                                  onClick={() => this.verifyPhone()}
                                  className="px-6 py-2 text-white bg_blue"
                                >
                                  Verify
                                </Link>
                              </div>
                            </div>
                            <div className="form-grid">
                              <div className="form-item sync">
                                <label>Sync calendar</label>
                                <span>
                                  <Link to="/google-calender">
                                    Connect with Google calendar
                                  </Link>
                                  <Link to="/calender">
                                    Connect with icalendar
                                  </Link>
                                </span>
                              </div>
                              <div className="form-actions">
                                <label />
                                <button type="submit">
                                  {updateProfileSpinner ? (
                                    <LoadingSpinner />
                                  ) : (
                                    "Update"
                                  )}
                                </button>
                              </div>
                            </div>
                          </form>
                        )
                      ) : null}
                    </div>
                  </div>
                </div>

                {this.state.tab === "profile" ? (
                  <div className="static__blocks bg-white px-6 mt-3 clearfix">
                    <InsightBlock
                      heading={"Total"}
                      text={"Appointments"}
                      insightData={allBookingsLength}
                    />
                    <InsightBlock
                      heading={"Upcoming"}
                      text={"Appointments"}
                      insightData={upcomingBookingLength}
                    />
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default ProfileView1;
