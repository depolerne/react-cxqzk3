import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import _get from "lodash/get";
import { setLoginMode } from "../../login/modules/auth";
import {
  fetchNotification,
  setReadCount,
} from "../../Notification/modules/Notification";
import { checkCounsellorAvail } from "../../Listing/modules/Listing";

const mobileSize = {
  maxWidth: 1024,
  maxHeight: 1024,
};
import { socket } from "../../../helpers/socketHelper";

import {
  setCallStatus,
  setCurrentSession,
} from "../../VideoSession/modules/VideoSession";

export const GLOBAL_SET_IS_MOBILE_STATUS = "GLOBAL_SET_IS_MOBILE_STATUS";
export const SELECT_TOP_SET_MODAL = "SELECT_TOP_SET_MODAL";
export const SELECT_TOP_RESET_STATE = "SELECT_TOP_RESET_STATE";
export const SELECT_SET_USER_DATA = "SELECT_SET_USER_DATA";
export const SELECT_SET_ALERT_MESSAGE = "SELECT_SET_ALERT_MESSAGE";
export const SELECT_SET_GET_USER_SPINNER_STATUS =
  "SELECT_SET_GET_USER_SPINNER_STATUS";
export const SELECT_SET_PROFILE_PROGRESS = "SELECT_SET_PROFILE_PROGRESS";
export const SELECT_SET_GET_USER_REVENUE = "SELECT_SET_GET_USER_REVENUE";
export const SELECT_SET_SESSION_WRAPPER_CONTENT =
  "SELECT_SET_SESSION_WRAPPER_CONTENT";
export const SET_GLOBAL_WAITING_LIST = "SET_GLOBAL_WAITING_LIST";
export const SELECT_SET_COUNSELLOR_LOCATION = "SELECT_SET_COUNSELLOR_LOCATION";
export const GLOBAL_SET_MENU_STYLING = "GLOBAL_SET_MENU_STYLING";
export const SELECT_SET_REQUEST_SENDER_EMAIL =
  "SELECT_SET_REQUEST_SENDER_EMAIL";
export const SET_SAVE_SESSION_DATA = "SET_SAVE_SESSION_DATA";
export const SELECT_GLOBAL_SET_USER_CHANNEL_ID =
  "SELECT_GLOBAL_SET_USER_CHANNEL_ID";
export const SELECT_SET_COUNSELLOR_LISTINGS_DATA =
  "SELECT_SET_COUNSELLOR_LISTINGS_DATA";
export const SELECT_SET_VIDEO_SESSION_SLOT = "SELECT_SET_VIDEO_SESSION_SLOT";
export const SELECT_SET_CALL_DURATION_TIME = "SELECT_SET_CALL_DURATION_TIME";
export const SET_USER_HANDSHAKE_SOCKET_ID = "SET_USER_HANDSHAKE_SOCKET_ID";
export const SET_SELECT_RECIEVER_STATUS = "SET_SELECT_RECIEVER_STATUS";
export const SET_SELECT_CALL_BOOKING_ID = "SET_SELECT_CALL_BOOKING_ID";

export function setReciever(data) {
  return {
    type: SET_SELECT_RECIEVER_STATUS,
    payload: data,
  };
}

export function setCallBookingId(data) {
  return {
    type: SET_SELECT_CALL_BOOKING_ID,
    payload: data,
  };
}

export const setMenuHover = (value) => {
  return {
    type: GLOBAL_SET_MENU_STYLING,
    payload: value,
  };
};

export const setIsMobileStatus = (data) => {
  return {
    type: GLOBAL_SET_IS_MOBILE_STATUS,
    payload: data,
  };
};

export function setAlertMessage(value) {
  return {
    type: SELECT_SET_ALERT_MESSAGE,
    payload: value,
  };
}

export const setUserDataInState = (user) => {
  return {
    type: SELECT_SET_USER_DATA,
    payload: user,
  };
};

export const setModal = (data) => {
  return {
    type: SELECT_TOP_SET_MODAL,
    payload: data,
  };
};

export const resetState = () => {
  return {
    type: SELECT_TOP_RESET_STATE,
  };
};

export const setProfileProgress = (value) => {
  return {
    type: SELECT_SET_PROFILE_PROGRESS,
    payload: value,
  };
};

export const setGetUserSpinner = (flag) => {
  return {
    type: SELECT_SET_GET_USER_SPINNER_STATUS,
    payload: flag,
  };
};

export const setCounsellorRevenue = (revenue) => {
  return {
    type: SELECT_SET_GET_USER_REVENUE,
    payload: revenue,
  };
};

export const setSessionWrapper = (flag) => {
  return {
    type: SELECT_SET_GET_USER_REVENUE,
    payload: flag,
  };
};

export const setCounsellorLocation = (location) => {
  return {
    type: SELECT_SET_COUNSELLOR_LOCATION,
    payload: location,
  };
};

export const setWaitingList = (data) => {
  return {
    type: SET_GLOBAL_WAITING_LIST,
    payload: data,
  };
};

export const setRequestSender = (id) => {
  return {
    type: SELECT_SET_REQUEST_SENDER_EMAIL,
    payload: id,
  };
};

export const saveSessionData = (data) => {
  return {
    type: SET_SAVE_SESSION_DATA,
    payload: data,
  };
};

export const setChannelId = (id) => {
  return {
    type: SELECT_GLOBAL_SET_USER_CHANNEL_ID,
    payload: id,
  };
};

export const setCallHistoryData = (data) => {
  return {
    type: SELECT_SET_CALL_HISTORY_RECORD_DATA,
    payload: data,
  };
};

export function setManageListingData(data) {
  return {
    type: SELECT_SET_COUNSELLOR_LISTINGS_DATA,
    payload: data,
  };
}

export const setCallDuration = (data) => {
  return {
    type: SELECT_SET_CALL_DURATION_TIME,
    payload: data,
  };
};

export const setVideoSessionSlot = (data) => {
  return {
    type: SELECT_SET_VIDEO_SESSION_SLOT,
    payload: data,
  };
};

export const setHandshakeId = (data) => {
  return {
    type: SET_USER_HANDSHAKE_SOCKET_ID,
    payload: data,
  };
};

export function Accept(item) {
  let { id, name, channel_id, time, sender, slot } = item;
  return async (dispatch, getState) => {
    let {
      waitingList,
      userData: { id },
    } = getState().selectState;
    await dispatch(setChannelId(channel_id));
    await dispatch(setCallDuration(time));
    await dispatch(setVideoSessionSlot(slot));
    await dispatch(setRequestSender(sender));
    await dispatch(setCurrentSession(item));
    const index = waitingList
      .map(function (e) {
        return e.hello;
      })
      .indexOf(id);
    if (index > -1 && waitingList.includes(name)) {
      waitingList.splice(index, 1);
    }
    socket.emit("accept_call", { sender, success: true });
    console.log(new Date());
    localStorage.setItem("call_pick_time", new Date());
    await dispatch(setWaitingList(waitingList));
  };
}

export function Reject(item) {
  let { id, sender, reciever_id } = item;
  return async (dispatch, getState) => {
    let { waitingList, userData } = getState().selectState;
    const index = waitingList.findIndex((i) => i.id === id);
    socket.emit("remove", { id, reciever_id });

    if (index > -1) {
      waitingList.splice(index, 1);
    }
    await dispatch(setWaitingList(waitingList));
    socket.emit("accept_call", { sender, success: false, cut_by: userData.id });
  };
}

export const logOut = (history) => {
  return async (dispatch, getState) => {
    const token = auth.getAccessToken();
    if (token) {
      document.cookie = "";
      //socket.emit("unsubscribe");
      localStorage.removeItem("call_status");
      localStorage.removeItem("email");
      localStorage.removeItem("join_status");
      await auth.resetLoginStore();
      await dispatch(resetState());

      await history.push("/");
      window.location.reload();
    }
  };
};

//---> Fetching userDate and Saving the user data into the redux state
export function getUserData() {
  return async (dispatch, getState) => {
    await dispatch(setGetUserSpinner(true));
    const token = auth.getAccessToken();
    if (!navigator.onLine) {
      await dispatch(
        setAlertMessage({ message: "No internet connection", color: "teal" })
      );
    }

    if (token) {
      try {
        let result = await fetch(`${__API__}/details`, {
          method: "GET",
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setGetUserSpinner(false));
        } else if (response.success) {
          await dispatch(setUserDataInState(response.user));
          await socket.emit("subscribe", response.user.id);
          response.listing_data["gallery_images"] = [];
          await dispatch(setManageListingData(response.listing_data));
          await dispatch(setProfileProgress(response.user.profile_percentage));
          await dispatch(setGetUserSpinner(false));
          await dispatch(setCounsellorRevenue(response.revenue));
        }
      } catch (e) {
        await dispatch(setAlertMessage("Server error. Please try again"));
        await dispatch(setGetUserSpinner(false));
      }
    } else {
      await dispatch(setGetUserSpinner(false));
    }
  };
}

export function loadWaitingList() {
  const token = auth.getAccessToken();
  let arr = [];
  let obj = {};
  return async (dispatch, getState) => {
    if (token) {
      try {
        let result = await fetch(`${__API__}/waiting-list`, {
          method: "GET",
          headers: {
            "Content-Type": "application/drupal.single+json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          response.data.forEach((item) => {
            Object.keys(item["from_id"]).map((i) => {
              obj = {
                channel_id: item["channel_id"],
                id: item["booking"].id,
                username: item["from_id"].name,
                avatar: item["from_id"].avatar_id,
                sender: item["socket_id"],
                time: item["timing"],
              };
              if (arr.filter((i) => i["id"] === obj.id) == 0) {
                arr.push(obj);
              }
            });
          });
          await dispatch(setWaitingList(arr));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error!! Please refresh the page.",
            color: "teal",
          })
        );
        console.log(e);
      }
    } else {
    }
  };
}

export function saveCallHistory(
  call_duration,
  booking_id,
  init_by,
  pick_by,
  cut_by,
  status,
  duration=0
) {
  const token = auth.getAccessToken();
  return async (dispatch) => {
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/save/logs?call_duration=${call_duration}&booking_id=${booking_id}&init_by=${init_by}&pick_by=${pick_by}&cut_by=${cut_by}&status=${status}&duration=${duration}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/drupal.single+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        debugger
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error!! Please refresh the page.",
            color: "teal",
          })
        );
        console.log(e);
      }
    }
  };
}

export const getInvoice = (booking_id) => {
  return async (dispatch, getState) => {
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/invoice/${booking_id}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/drupal.single+json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setCallHistoryData(response.data));
          await dispatch(
            setAlertMessage({
              message: "Invoice has been sent on the mail",
              color: "green",
            })
          );
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      // await dispatch(setLoadingSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const actions = {
  setIsMobileStatus,
  logOut,
  setAlertMessage,
  getUserData,
  setUserDataInState,
  setWaitingList,
  setSessionWrapper,
  setMenuHover,
  setLoginMode,
  fetchNotification,
  setReadCount,
  setProfileProgress,
  loadWaitingList,
  setCounsellorLocation,
  setCallHistoryData,
  setManageListingData,
  setHandshakeId,
  Accept,
  Reject,
};

const initialState = {
  userData: "",
  isMobile: false,
  alertMessage: { message: "", color: "" },
  waitingList: [],
  profile_percentage: "",
  userSpinner: false,
  revenue: "",
  sessionWrapper: false,
  menu: "dashboard",
  c_location: "",
  channel_id: "",
  sender: "",
  call_duration: "",
  videoSessionSlot: "",
  handshake_id: "",
  reciever: false,
  sessionData: {
    from_id: "",
    to_id: "",
    session_hours: "",
    session_minutes: "",
    booking_id: "",
    username: "",
  },
};

const ACTION_HANDLERS = {
  [SELECT_SET_COUNSELLOR_LOCATION]: (state, action) => {
    return {
      ...state,
      c_location: action.payload,
    };
  },
  [GLOBAL_SET_MENU_STYLING]: (state, action) => {
    return {
      ...state,
      menu: action.payload,
    };
  },
  [SELECT_SET_GET_USER_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      userSpinner: action.payload,
    };
  },
  [GLOBAL_SET_IS_MOBILE_STATUS]: (state, action) => {
    return {
      ...state,
      isMobile: action.payload.width <= mobileSize.maxWidth,
    };
  },
  [SELECT_SET_ALERT_MESSAGE]: (state, action) => {
    return {
      ...state,
      alertMessage: action.payload,
    };
  },
  [SELECT_SET_USER_DATA]: (state, action) => {
    return {
      ...state,
      userData: action.payload,
    };
  },
  [SELECT_SET_PROFILE_PROGRESS]: (state, action) => {
    return {
      ...state,
      profile_percentage: action.payload,
    };
  },
  [SELECT_TOP_SET_MODAL]: (state, action) => {
    return {
      ...state,
      modal: {
        ...initialState.modal,
        ...action.payload,
      },
    };
  },
  [SELECT_TOP_RESET_STATE]: () => {
    return {
      ...initialState,
    };
  },
  [SELECT_SET_GET_USER_REVENUE]: (state, action) => {
    return {
      ...state,
      revenue: action.payload,
    };
  },
  [SELECT_SET_SESSION_WRAPPER_CONTENT]: (state, action) => {
    return {
      ...state,
      sessionWrapper: action.payload,
    };
  },
  [SET_GLOBAL_WAITING_LIST]: (state, action) => {
    return {
      ...state,
      waitingList: action.payload,
    };
  },
  [SELECT_SET_REQUEST_SENDER_EMAIL]: (state, action) => {
    return {
      ...state,
      sender: action.payload,
    };
  },
  [SET_SAVE_SESSION_DATA]: (state, action) => {
    return {
      ...state,
      sessionData: action.payload,
    };
  },
  [SELECT_GLOBAL_SET_USER_CHANNEL_ID]: (state, action) => {
    return {
      ...state,
      channel_id: action.payload,
    };
  },
  [SELECT_SET_COUNSELLOR_LISTINGS_DATA]: (state, action) => {
    return {
      ...state,
      listing_data: action.payload,
    };
  },
  [SELECT_SET_CALL_DURATION_TIME]: (state, action) => {
    return {
      ...state,
      call_duration: action.payload,
    };
  },
  [SELECT_SET_VIDEO_SESSION_SLOT]: (state, action) => {
    return {
      ...state,
      videoSessionSlot: action.payload,
    };
  },
  [SET_USER_HANDSHAKE_SOCKET_ID]: (state, action) => {
    return {
      ...state,
      handshake_id: action.payload,
    };
  },
  [SET_SELECT_CALL_BOOKING_ID]: (state, action) => {
    return {
      ...state,
      req_id: action.payload,
    };
  },
  [SET_SELECT_RECIEVER_STATUS]: (state, action) => {
    return {
      ...state,
      reciever: action.payload,
    };
  },
};

export default function selectReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
