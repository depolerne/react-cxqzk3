import React, { Fragment } from "react";
import { renderRoutes } from "react-router-config";
import PropTypes from "prop-types";
import _get from "lodash/get";
import _sortBy from "lodash/sortBy";
import auth from "../../../helpers/auth";
import Header from "../../../components/Header/Header";
import CHeader from "../../../components/Header/CHeader";
import NotificationBar from "../../../components/NotificationBar/NotificationBar";
import FooterBar from "../../../components/FooterBar/FooterBar";
import AlertBox from "../../../components/AlertBox/AlertBox";
import $ from "jquery";
import history from "../../../helpers/history";
import { socket } from "../../../helpers/socketHelper";
// import "../../../assets/main.css"

export class SelectWrapperView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      addServiceComponent: "",
      masqUser: "",
      value: "",
    };
    this.logOut = this.logOut.bind(this);
    this.updateIsMobile = this.updateIsMobile.bind(this);
  }

  async componentDidMount() {
    socket.on("new_request", (data) => {
      console.log(data);
      this.props.setWaitingList(data);
    });

    socket.on("connected",data=>{
      if(data.handshake_id){
       this.props.setHandshakeId(data.handshake_id);
      }
    })
    this.updateIsMobile();
    window.addEventListener("resize", this.updateIsMobile);
    await this.props.loadWaitingList()
    // $(document).ready(function () {
    //   $(".fa-times").hide();
    //   $(".mobile__main__nav").hide();

    //   $(".fa-times").click(function () {
    //     $(".mobile__main__nav").hide();
    //     $(".fa-times").hide();
    //     $(".fa-bars").show();
    //   });

    //   $(".fa-bars").click(function () {
    //     $(".mobile__main__nav").show();
    //     $(".fa-times").show();
    //     $(".fa-bars").hide();
    //   });

    //   $(".mobile_menu_icon").click(function () {
    //     $(".mobile__main__nav").hide();
    //     $(".fa-times").hide();
    //     $(".fa-bars").show();
    //   });
    // });
  }

  logOut() {
    this.props.logOut(this.props.history);
  }

  updateIsMobile() {
    this.props.setIsMobileStatus({
      width: window.innerWidth,
      height: window.innerHeight,
    });
  }

  render() {
    const userType = auth.getUserType();
    const { name, avatar_id } = this.props.selectState.userData;
    const { alertMessage, sessionWrapper } = this.props.selectState;
    return (
      <Fragment>
        {userType && userType === "User" ? (
          <Header
            logout={this.logOut}
            name={name}
            avatar={avatar_id !== undefined ? avatar_id : null}
          />
        ) : (
          <CHeader
            name={name}
            logout={this.logOut}
            avatar={avatar_id !== undefined ? avatar_id : null}
          />
        )}
        <NotificationBar history={history} />
        {alertMessage.message ? (
          <AlertBox
            color={alertMessage.color}
            AlertText={alertMessage.message}
            clickEvent={()=>this.props.setAlertMessage({message : '', color:''})}
          />
        ) : null}
        <Fragment>{renderRoutes(this.props.route.routes)}</Fragment>
        <FooterBar />
      </Fragment>
    );
  }
}

SelectWrapperView.propTypes = {
  route: PropTypes.object.isRequired,
  location: PropTypes.object.isRequired,
  history: PropTypes.object.isRequired,
  selectState: PropTypes.object.isRequired,
  setIsMobileStatus: PropTypes.func.isRequired,
  logOut: PropTypes.func.isRequired,
};

export default SelectWrapperView;
