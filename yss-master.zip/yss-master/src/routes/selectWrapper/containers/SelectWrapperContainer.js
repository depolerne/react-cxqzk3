import React from "react";
import {
  actions,
  setIsMobileStatus,
  getUserData,
} from "../modules/select";

import { bindActionCreators } from "redux";
import SelectWrapperView from "../components/SelectWrapperView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";
import auth from "../../../helpers/auth"; 

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  auth: state.auth,
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {
    await dispatch(
      setIsMobileStatus({
        width: window.innerWidth,
        height: window.innerHeight,
      })
    );
    if (auth.isAuthenticated) {
      await dispatch(getUserData());
      // await dispatch(getChannelData());
    }
  },
  ErrorComponent: ({ error }) => (__DEV__ ? <RedBox error={error} /> : null),
})(SelectWrapperView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
