import CreatePackage from './containers/CreatePackageContainer';
export { CreatePackage };
export * from './modules/CreatePackage';

export default CreatePackage;
