import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import _get from "lodash/get";
import PropTypes from "prop-types";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import { NameValidator } from "../../../helpers/NameValidator";
import { setTimeLable } from "../../../helpers/checkSlots";
import Select from "react-select";
import PackageTime from "../../../helpers/PackageSlot";

export class CreatePackageView extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.changeSession = this.changeSession.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.Redirectback = this.Redirectback.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.newPackage = this.props.CreatePackageState.newPackage;
    this.state = {
      errClass: "",
    };
  }

  handleChange(event) {
    const name = event.target.name;
    const value = event.target.value;
    this.newPackage[name] = value;
    this.props.setNewPackageData(this.newPackage);
  }

  handleSelect(selected, event) {
    this.newPackage[event.name] = selected.value;
    this.props.setNewPackageData(this.newPackage);
  }

  async changeSession(event) {
    let name = event.target.name;
    let value = event.target.value;
    if (event.target.value === "select") {
      this.newPackage[name] = "";
    } else {
      this.newPackage[name] = value;
    }
    this.props.setNewPackageData(this.newPackage);
  }

  Redirectback() {
    this.props.history.push("/coach/dashboard/package_lists");
    this.props.setNewPackageData({
      package_name: "",
      package_description: "",
      amount: "",
      session_minutes: "",
      session_hours: "",
    });
  }

  componentDidMount() {
    let body = document.body;
    body.className = "create_package";
  }

  componentWillUnmount() {
    this.props.setNewPackageData({
      package_name: "",
      package_description: "",
      amount: "",
      session_minutes: "",
      session_hours: "",
    });

    this.setState = (state, callback) => {
      return;
    };
  }

  submitHandler(event) {
    let { newPackage } = this.props.CreatePackageState;
    let format = /[!#$%^&*()_+\=\[\]{};':"\\|,`~<>\/?]+/;
    let amount = /[!@#$%^&*()_+\=\[\]{};':"\\|,`~<>\/?]+/;
    let amtFormat = /[a-zA-Z]$/;
    event.preventDefault();
    if (!newPackage.package_name.length) {
      this.props.setAlertMessage({
        message: "Package Name can't be empty.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (NameValidator(newPackage.package_name)) {
      this.props.setAlertMessage({
        message: "Package name should starts with 3 alphabets",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (format.test(newPackage.package_name)) {
      this.props.setAlertMessage({
        message: "Package name should not contain special characters.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (
      newPackage.package_name.length < 3 ||
      newPackage.package_name.length > 50
    ) {
      this.props.setAlertMessage({
        message: "Package name must contain characters between 3 and 50.",
        color: "teal",
      });
      this.setState({ errClass: "name" });
    } else if (!newPackage.package_description.length) {
      this.props.setAlertMessage({
        message: "Please enter the Package Description",
        color: "teal",
      });
      this.setState({ errClass: "desc" });
    } else if (newPackage.package_description.length < 250) {
      this.props.setAlertMessage({
        message: "Please enter the Package Description atleast 250 words long.",
        color: "teal",
      });
      this.setState({ errClass: "desc" });
    } else if (newPackage.session_minutes.length === 0) {
      this.props.setAlertMessage({
        message: "Please select the session minutes",
        color: "teal",
      });
    } else if (newPackage.session_hours.length === 0) {
      this.props.setAlertMessage({
        message: "Please select the session hours",
        color: "teal",
      });
    } else if (
      newPackage.session_hours === "00" &&
      newPackage.session_minutes === "00"
    ) {
      this.props.setAlertMessage({
        message: "Session timings can't be empty.",
        color: "teal",
      });
      this.setState({ errClass: "hours" });
    } else if (
      !newPackage.amount.length ||
      amtFormat.test(newPackage.amount) ||
      newPackage.amount > 999 ||
      newPackage.amount < 1
    ) {
      this.props.setAlertMessage({
        message: "Please enter the valid Package Amount",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else if (!parseFloat(newPackage.amount) > 0) {
      this.props.setAlertMessage({
        message: "Package amount must be grater than zero",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else if (newPackage.amount.length > 6 && newPackage.amount < 999) {
      this.props.setAlertMessage({
        message: "Please enter the correct Package Amount.",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else if (amount.test(newPackage.amount)) {
      this.props.setAlertMessage({
        message: "Package amount should not contain special characters",
        color: "teal",
      });
      this.setState({ errClass: "amount" });
    } else {
      this.props.addPackage({ ...newPackage, history: this.props.history });
    }
    setTimeout(() => {
      this.setState({ errClass: "" });
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  render() {
    const { spinnerStatus, newPackage } = this.props.CreatePackageState;
    const { errClass } = this.state;
    const { Hours, Mins,Counts } = PackageTime;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Create <span>Package</span>
                </h3>
              </div>
              <div className="site__form middle__content">
                <div className="create_package--form">
                  <form className="clearfix" onSubmit={this.submitHandler}>
                    <div className="form-item">
                      <div className="form-label">Package Name:</div>
                      <input
                        className={errClass == "name" ? "border-red-500" : ""}
                        type="text"
                        name="package_name"
                        placeholder="Package Name"
                        onChange={this.handleChange}
                        value={newPackage.package_name}
                        autoComplete="off"
                      />
                    </div>
                    <div className="form-item">
                      <div className="form-label">Package Description:</div>
                      <textarea
                        className={errClass == "desc" ? "border-red-500" : ""}
                        type="text"
                        name="package_description"
                        placeholder="Package Description"
                        value={newPackage.package_description}
                        onChange={this.handleChange}
                        autoComplete="off"
                      />
                    </div>

                    <div className="form-grid timeslot">
                      <div className="form-label">Duration: </div>
                      <div className="timeslot__slot--row-pack">
                        <div className="slots_row">
                          <div className="f_slot slots">
                            <Select
                              name={"session_hours"}
                              className="new_select"
                              options={Hours}
                              value={Hours.filter((option) => {
                                return option.value === newPackage.session_hours;
                              })}
                              onChange={this.handleSelect}
                              searchable={true}
                            />
                          </div>
                          <div className="s_slot slots ml-2">
                            <Select
                              name={"session_minutes"}
                              className="new_select"
                              options={Mins}
                              value={Mins.filter((option) => {
                                return option.value === newPackage.session_minutes;
                              })}
                              onChange={this.handleSelect}
                              searchable={true}
                            />
                          </div>
                        </div>
                        <div className="form-label">
                          {setTimeLable(
                            newPackage.session_hours,
                            newPackage.session_minutes
                          )
                            ? "Minutes"
                            : "Hours"}
                        </div>
                      </div>
                    </div>

                    <div className="form-grid timeslot">
                      <div className="form-label">No. of Sessions: </div>
                      <div className="slots_row">
                        <div className="first_slot slots">
                          {/* <select name="no_of_slots" onChange={this.handleChange}>
                            <option value="select">select</option>

                            <option value={"01"}>1</option>
                            <option value={"02"}>2</option>
                            <option value={"03"}>3</option>

                            <option value={"04"}>4</option>
                            <option value={"05"}>5</option>
                            <option value={"06"}>6</option>
                            <option value={"07"}>7</option>
                            <option value={"08"}>8</option>
                            <option value={"09"}>9</option>
                            <option value={"10"}>10</option>
                          </select> */}
                          <Select
                            name={"no_of_slots"}
                            className="new_select"
                            options={Counts}
                            value={Counts.filter((option) => {
                              return option.value === newPackage.no_of_slots;
                            })}
                            onChange={this.handleSelect}
                            searchable={true}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="form-item">
                      <div className="form-label">Package Amount:</div>
                      <input
                        className={errClass == "amount" ? "border-red-500" : ""}
                        type="number"
                        placeholder="Enter the amount"
                        step="any"
                        name="amount"
                        value={newPackage.amount}
                        onChange={this.handleChange}
                      />
                    </div>

                    <div className="form-actions">
                      <button type="submit">
                        {spinnerStatus ? <LoadingSpinner /> : "Create"}
                      </button>
                      <button type="cancel" onClick={this.Redirectback}>
                        Go Back
                      </button>
                    </div>
                  </form>
                  <div className="help__block">
                    <div className="page_title text-center">
                      <h1 className="text-xl">
                        <span className="text_nav_blue">How This Works</span>
                      </h1>
                    </div>
                    <div className="help__text">
                      <p>
                        Contrary to popular belief Lorem Ipsum is not simply
                        random.
                      </p>
                      <p>It has roots a piece classical Latin</p>
                      <p>
                        literature from 45 BC, making it over
                        <br /> 2000 years old. Richard McClintock, a Latin
                        professor at Hampden-Sydney College in Virginia,
                      </p>
                      <p>
                        looked up one of the more obscure
                        <br /> Latin words, consectetur, from a Lorem Ipsum <br />
                        passage, and going through the cites of the word in
                        classical literature, discovered the undoubtable source.
                        Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de
                        Finibus Bonorum et Malorum.
                      </p>
                      <p>
                        literature from 45 BC, making it over
                        <br /> 2000 years old. Richard McClintock, a Latin
                        professor at Hampden-Sydney College in Virginia,
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

CreatePackageView.propTypes = {
  addPackage: PropTypes.func.isRequired,
  setCreatePackageErr: PropTypes.func.isRequired,
};

export default CreatePackageView;
