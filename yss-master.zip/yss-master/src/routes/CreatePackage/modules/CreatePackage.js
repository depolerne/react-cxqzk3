import fetch from "isomorphic-fetch";
import auth from "../../../helpers/auth";
import { setAlertMessage,setUserDataInState } from "../../selectWrapper/modules/select";

export const CREATE_PACKAGE_P_SET_ERR_MESSAGE =
  "CREATE_PACKAGE_P_SET_ERR_MESSAGE";

export const CREATE_PACKAGE_P_SET_SPINNER_STATUS =
  "CREATE_PACKAGE_P_SET_SPINNER_STATUS";

export const CREATE_PACKAGE_P_SET_NEW_PACKAGE =
  "CREATE_PACKAGE_P_SET_NEW_PACKAGE";

export const setCreatePackageErr = (value) => {
  return {
    type: CREATE_PACKAGE_P_SET_ERR_MESSAGE,
    payload: value,
  };
};

export const setCreatePackageSpinnerStatus = (status) => {
  return {
    type: CREATE_PACKAGE_P_SET_SPINNER_STATUS,
    payload: status,
  };
};

export const setNewPackageData = (data) => {
  return {
    type: CREATE_PACKAGE_P_SET_NEW_PACKAGE,
    payload: data,
  };
};

//---> API to save packages

export function addPackage(data) {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setCreatePackageSpinnerStatus(true));

    const token = auth.getAccessToken();
    try {
      let result = await fetch(`${__API__}/create-package`, {
        method: "POST",
        cache: "no-cache",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          Accept: "application/json",
          Authorization: `Bearer ` + token,
        },
      });
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map(item=>{
          dispatch(setAlertMessage({message: response.errors[item][0],color: "teal"}))
        })
        await dispatch(setCreatePackageSpinnerStatus(false));
      } else if (response.success) {
        await dispatch(
          setAlertMessage({
            message: 'Package created successfully',
            color: "green",
          })
        );
        await dispatch(setUserDataInState(response.user))  
        await dispatch(setCreatePackageSpinnerStatus(false));
        await data.history.push("/coach/dashboard/package_lists");
      }
    } catch (e) {
      dispatch(
        setAlertMessage({
          message: "You need to login first",
          color: "red",
        })
      );

      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec

    await setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export const actions = {
  setCreatePackageErr,
  addPackage,
  setCreatePackageSpinnerStatus,
  setAlertMessage,
  setNewPackageData,
};

const initialState = {
  errMessage: { message: "", color: "" },
  spinnerStatus: false,
  newPackage: {
    package_name: "",
    package_description: "",
    amount: "",
    session_minutes: "",
    session_hours: "",
    no_of_slots:"01"
  },
};

const ACTION_HANDLERS = {
  [CREATE_PACKAGE_P_SET_ERR_MESSAGE]: (state, action) => {
    return {
      ...state,
      errMessage: action.payload,
    };
  },
  [CREATE_PACKAGE_P_SET_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      spinnerStatus: action.payload,
    };
  },
  [CREATE_PACKAGE_P_SET_NEW_PACKAGE]: (state, action) => {
    return {
      ...state,
      newPackage: {
        ...action.payload,
      },
    };
  },
};

export default function CreatePackageReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
