import React, { Fragment } from "react";
import { renderRoutes } from "react-router-config";
import PropTypes from "prop-types";
import _get from "lodash/get";
import _sortBy from "lodash/sortBy";
import SiteHeader from "../../../components/Header/SiteHeader";
import FooterBar from "../../../components/FooterBar/FooterBar";
import AlertBox from "../../../components/AlertBox/AlertBox";
import $ from "jquery";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";

export class SiteWrapperView extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.loadWaitingList();
    this.props.getUserData();
    window.addEventListener("resize", this.updateIsMobile);
    //await this.props.loadWaitingList()
    // $(document).ready(function () {
    //   $(".fa-times").hide();
    //   $(".mobile__main__nav").hide();

    //   $(".fa-times").click(function () {
    //     $(".mobile__main__nav").hide();
    //     $(".fa-times").hide();
    //     $(".fa-bars").show();
    //   });

    //   $(".fa-bars").click(function () {
    //     $(".mobile__main__nav").show();
    //     $(".fa-times").show();
    //     $(".fa-bars").hide();
    //   });

    //   $(".mobile_menu_icon").click(function () {
    //     $(".mobile__main__nav").hide();
    //     $(".fa-times").hide();
    //     $(".fa-bars").show();
    //   });
    // });
  }
  
  componentDidUpdate(prevProps) {
    if (
      this.props.location.pathname !== prevProps.location.pathname
    ) {
      window.scrollTo(0, 0);
    }
  }

  render() {
    const { siteAlertMessage } = this.props.siteState;
    return (
      <Fragment>
        <SiteHeader logout={() => this.props.siteLogOut(this.props.history)} />
        {siteAlertMessage.message ? (
          <AlertBox
            color={siteAlertMessage.color}
            AlertText={siteAlertMessage.message}
            clickEvent={() =>
              this.props.setSiteAlertMessage({ message: "", color: "" })
            }
          />
        ) : null}
        <Fragment>{renderRoutes(this.props.route.routes)}</Fragment>
        <FooterBar />
      </Fragment>
    );
  }
}

export default SiteWrapperView;
