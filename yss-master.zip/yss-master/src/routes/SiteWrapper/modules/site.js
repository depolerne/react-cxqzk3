import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import _get from "lodash/get";
import {logOut,getUserData} from '../../selectWrapper/modules/select'
import {loadWaitingList} from "../../selectWrapper/modules/select"
export const SITE_SET_ALERT_MESSAGE = "SITE_SET_ALERT_MESSAGE";

export function setSiteAlertMessage(value){
  return {
    type: SITE_SET_ALERT_MESSAGE,
    payload: value,
  };
};

export const siteLogOut=(history)=>{
  return async(dispatch)=>{
    await dispatch(logOut(history))
  }
}

//---> Fetching userDate and Saving the user data into the redux state

export const siteActions = {
  setSiteAlertMessage,
  logOut,
  siteLogOut,
  getUserData,
  loadWaitingList
};

const initialState = {
  sessionWrapper: false,
  menu: "dashboard",
  siteAlertMessage: {
    message: "",
    color: "",
  },
};

const ACTION_HANDLERS = {
  [SITE_SET_ALERT_MESSAGE]: (state, action) => {
    return {
      ...state,
      siteAlertMessage: action.payload,
    };
  }
};

export default function siteReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
