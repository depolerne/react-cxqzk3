import React from "react";
import {
  siteActions
} from "../modules/site";

import { bindActionCreators } from "redux";
import SiteWrapperView from "../components/SiteWrapperView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";
import auth from "../../../helpers/auth"; 
import { getUserData } from "../../selectWrapper/modules/select";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(siteActions, dispatch),
});

const mapStateToProps = (state) => ({
  siteState: state.siteState,
  auth: state.auth,
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {
  //  await dispatch(getUserData())
  },
  ErrorComponent: ({ error }) => (__DEV__ ? <RedBox error={error} /> : null),
})(SiteWrapperView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
