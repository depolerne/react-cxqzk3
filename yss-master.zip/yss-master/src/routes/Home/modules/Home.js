import { logOut } from "../../selectWrapper/modules/select";

export const SET_ADD_LISTINGS_SPINNER_STATUS =
  "SET_ADD_LISTINGS_SPINNER_STATUS";

//---> Fetching userDate and Saving the user data into the redux state

export const setAddListingSpinner = (flag) => {
  return {
    type: SET_ADD_LISTINGS_SPINNER_STATUS,
    payload: flag,
  };
};

export const actions = {
  logOut,
  setAddListingSpinner,
};

const initialState = {
  searchNowSpinner: false,
};

const ACTION_HANDLERS = {
  [SET_ADD_LISTINGS_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      searchNowSpinner: action.payload,
    };
  },
};

export default function HomeReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
