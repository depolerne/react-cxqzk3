import React from "react";
import { actions } from "../modules/Home";
import { bindActionCreators } from "redux";
import HomeView from "../components/HomeView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  HomeState: state.HomeState,
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {},
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(HomeView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);