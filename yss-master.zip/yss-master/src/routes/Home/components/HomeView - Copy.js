import React, { Fragment } from "react";
import Fade from "react-reveal/Fade";
import Carousel from "../../../components/Carousel/Carousel";
import { Link } from "react-router-dom";

export class HomeView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.handleChange = this.handleChange.bind(this);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "home_page";
  }

  handleChange(event) {
    this.setState({ email: event.target.value });
  }

  render() {
    return (
      <Fragment>
        <div className="main-content yss-site--main__content content__homepage">
          <div className="main-site__content">
            <div className="site__top-banner md:flex md:flex-wrap w-full relative items-center">
              <div className="banner__items md:w-1/3">
                <Carousel />
              </div>
              {/* <div className="banner__contents relative z-20 w-11/12 mx-auto md:w-auto  md:w-2/3 md:px-12 lg:px-24 py-24">
                <div className="section__title banner__title py-12 px-4">
                  <h2>
                    Your safe space.
                    <br />
                    coaching,counselling fitness,
                    <br />
                    nutrition, yoga &amp; much more.
                  </h2>
                </div>
                <div className="site__text">
                  <p>
                    All online,{" "}
                    <span className="text-blue-800">via your webcam,</span> in
                    soberlistic.
                  </p>
                </div>
                <div className="btn banner__btn site__btn">
                  <Link className="btn-blue" to="#">
                    Find out more
                  </Link>
                </div>
              </div>
              <div className="banner__bg--big--title">
                <span>Online</span>
              </div> */}
              <div className="banner__contents relative z-20 w-11/12 mx-auto md:w-2/3">
                <div className="section__title banner__title mb-6">
                  <h2>
                    Your safe space. coaching, counselling fitness, nutrition,
                    yoga &amp; much more.
                  </h2>
                </div>
                <div className="site__text">
                  <p className="para-mt-0 mt-0">
                    All online,{" "}
                    <span className="text-blue-800">via your webcam,</span> in
                    soberlistic.
                  </p>
                </div>
                <div className="btn banner__btn site__btn">
                  <a className="btn-blue" href="/connect">
                    Find out more
                  </a>
                </div>
              </div>
              <div className="banner__bg--big--title">
                <span>Online</span>
              </div>
            </div>

            <div className="center-heading-para">
              <p>
                "Your Safe Space is a holistic approach that means providing
                support that looks at the whole person, not just their symptoms"
              </p>
            </div>
            <div className="section__wrapper text-center">
              <div className="page__content">
                <div className="section__title">
                  <h2>how it works</h2>
                </div>
                <div className="section__subtitle">
                  <p>
                    research, search, book and begin, it’s that easy! find an
                    expert and connect in soberlistic.
                  </p>
                </div>
                <div className="d-section--feeds feed-style-1 mt-12 md:flex md:flex-wrap md:justify-between">
                  <div className="feed--list-col md:w-1/3">
                    <div className="feed--list max-w-lg mx-auto mb-12 md:mb-0">
                      <div className="feed--icon">
                        <i className="far fa-eye"></i>
                      </div>
                      <div className="section__title">
                        <h2>Research</h2>
                      </div>
                      <div className="feed--text">
                        <p>
                          Read some of our articles to find out what support
                          would best help you, such as counselling or coaching!
                        </p>
                      </div>
                    </div>
                    <div className="feed--list max-w-lg mx-auto mb-12 md:mb-0 md:mt-16">
                      <div className="feed--icon">
                        <i className="fas fa-search"></i>
                      </div>
                      <div className="section__title">
                        <h2>Search</h2>
                      </div>
                      <div className="feed--text">
                        <p>
                          Search through our experts to find the perfect person
                          to help you on your journey, it's never too early to
                          begin.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="feed--list-col md:w-1/3">
                    <div className="feed--list max-w-lg mx-auto mb-12 md:mb-0">
                      <div className="feed--icon">
                        <i className="far fa-calendar-alt"></i>
                      </div>
                      <div className="section__title">
                        <h2>Book</h2>
                      </div>
                      <div className="feed--text">
                        <p>
                          Once you have found your perfect support it's time to
                          make a booking. Click 'book now' to book your first
                          session.
                        </p>
                      </div>
                    </div>
                    <div className="feed--list max-w-lg mx-auto md:mt-16">
                      <div className="feed--icon">
                        <i className="far fa-heart"></i>
                      </div>
                      <div className="section__title">
                        <h2>Begin</h2>
                      </div>
                      <div className="feed--text">
                        <p>
                          The exciting part, start working with your new support
                          in your very own safe space. We're sure you will love
                          the experience.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="section__wrapper text-center d-section--feeds feed-style-2">
              <div className="mt-12 md:flex md:flex-wrap md:justify-between">
                <div className="feed--list has-feed--item md:w-1/3">
                  <div className="feed--item">
                    <img src="/images/feed-img-1.jpg" />
                  </div>
                </div>

                <div className="feed--list max-w-full mx-auto my-12 md:my-0 md:w-1/3 flex items-center">
                  <div className="feed--body">
                    <div className="section__title">
                      <h2>coaching &amp; counselling</h2>
                    </div>
                    <div className="feed--text">
                      <p>
                        Everyone needs help from time to time, and it really
                        does help to talk to a professional who can help.{" "}
                      </p>
                    </div>
                    <div className="btn feed--btn site__btn">
                      <a className="btn-blue" href="#">
                        Find out more
                      </a>
                    </div>
                  </div>
                </div>

                <div className="feed--list has-feed--item md:w-1/3">
                  <div className="feed--item">
                    <img src="/images/feed-img-2.jpg" />
                  </div>
                </div>

                <div className="feed--list max-w-full mx-auto my-12 md:my-0 md:w-1/3 flex items-center">
                  <div className="feed--body">
                    <div className="section__title">
                      <h2>fitness</h2>
                    </div>
                    <div className="feed--text">
                      <p>
                        Fitness plays a huge part in mental health, and we know
                        how har it can be to get motivated, our experts can
                        help.
                      </p>
                    </div>
                    <div className="btn feed--btn site__btn">
                      <a className="btn-blue" href="#">
                        Find out more
                      </a>
                    </div>
                  </div>
                </div>

                <div className="feed--list has-feed--item md:w-1/3">
                  <div className="feed--item item--full-width">
                    <img src="/images/feed-img-3.jpg" />
                  </div>
                </div>

                <div className="feed--list max-w-full mx-auto my-12 md:my-0 md:w-1/3 flex items-center">
                  <div className="feed--body">
                    <div className="section__title">
                      <h2>nutrition</h2>
                    </div>
                    <div className="feed--text">
                      <p>
                        Good nutrition along with fitness can create an amazing
                        change both physically and emotionally, let’s begin.
                      </p>
                    </div>
                    <div className="btn feed--btn site__btn">
                      <a className="btn-blue" href="#">
                        Find out more
                      </a>
                    </div>
                  </div>
                </div>

                <div className="feed--list has-feed--item md:w-1/3">
                  <div className="feed--item">
                    <img src="/images/feed-img-4.jpg" />
                  </div>
                </div>

                <div className="feed--list max-w-full mx-auto my-12 md:my-0 md:w-1/3 flex items-center">
                  <div className="feed--body">
                    <div className="section__title">
                      <h2>wellness</h2>
                    </div>
                    <div className="feed--text">
                      <p>
                        We have wellness experts ready to help you, from yoga to
                        meditation, connect with our experts today.
                      </p>
                    </div>
                    <div className="btn feed--btn site__btn">
                      <a className="btn-blue" href="#">
                        Find out more
                      </a>
                    </div>
                  </div>
                </div>

                <div className="feed--list has-feed--item md:w-1/3">
                  <div className="feed--item">
                    <img src="/images/feed-img-5.jpg" />
                  </div>
                </div>
              </div>
              <div></div>
            </div>

            <div className="section__wrapper text-center">
              <div className="page__content">
                <div className="section__title">
                  <h2>Inspiration for you.</h2>
                </div>
                <div className="section__subtitle">
                  <p>
                    Inspiration and motivation from soberlistic experts.
                  </p>
                </div>
                <div className="d-section--feeds feed-style-3 mt-12 md:flex md:flex-wrap md:justify-between">
                  <div className="feed--list max-w-lg mx-auto mb-12 md:mb-0 md:w-1/3">
                    <div className="feed--wrapper">
                      <div className="feed--item">
                        <img src="/images/feed-img-6.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="section__title">
                          <h2>Use Food to Ease Anxiety</h2>
                        </div>
                        <div className="feed--text">
                          <p>
                            Use Food to Ease Anxiety: For some, individuals,
                            feelings of anxiety are at an unsurpassed high. In
                            spite of the fact that we can’t totally
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="feed--list max-w-lg mx-auto mb-12 md:mb-0 md:w-1/3">
                    <div className="feed--wrapper">
                      <div className="feed--item">
                        <img src="/images/feed-img-7.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="section__title">
                          <h2>The Science Behind a Good Workout</h2>
                        </div>
                        <div className="feed--text">
                          <p>
                            The Science Behind a Good Workout: We’ve all been
                            there previously: an intense day at work, with the
                            children, or in school. We’re depleted, both
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="feed--list max-w-lg mx-auto md:w-1/3">
                    <div className="feed--wrapper">
                      <div className="feed--item">
                        <img src="/images/feed-img-8.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="section__title">
                          <h2>Difference in Diversity</h2>
                        </div>
                        <div className="feed--text">
                          <p>
                            Difference in Diversity We live in a diverse
                            society, and in order to counsel ethically and
                            effectively, it is important that we are mindful of
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="center-heading-para add_services mt-24">
              <div className="page__content">
                <div className="md:flex md:flex-wrap md:items-center md:justify-between">
                  <p className="para-white">
                    Add your amazing services to soberlistic.
                  </p>
                  <div className="site__btn btn mt-10 md:mt-0">
                    <a className="btn-white" href="#">
                      Find out more
                    </a>
                  </div>
                </div>
              </div>
            </div>
            <div className="section__wrapper text-center subscribe--section">
              <div className="page__content">
                <div className="section__title">
                  <h2>stay in touch</h2>
                </div>
                <div className="section__subtitle">
                  <p>
                    We are always adding new content, articles, and services, if
                    you’d like to be part of our growing community then
                    subscribe and get some great articles in your inbox.
                  </p>
                </div>
                <div className="subscribe__form">
                  <form className="mt-10 relative">
                    {/* <div className="form-item">
                      <input type="text" onChange={this.handleChange} />
                    </div> */}
                    <div className="form-actions"></div>
                  </form>
                  <button className="btn btn-blue px-4 py-3" type="submit">
                    Find Support
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default HomeView;
