import Profile from './container/ProfileContainer';
export { Profile };
export * from './modules/Profile';

export default Profile;
