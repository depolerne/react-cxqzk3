import React from "react";
import auth from "../../../helpers/auth";
import _without from "lodash/without";
import fetch from "isomorphic-fetch";
import {
  setUserDataInState,
  setAlertMessage,
  setMenuHover,
  setCounsellorLocation,
} from "../../selectWrapper/modules/select";

export const PROFILE_P_SET_SPINNER_STATUS = "PROFILE_P_SET_SPINNER_STATUS";
export const SET_COUNTRY_CODE = "SET_COUNTRY_CODE";
export const SET_OTP_SPINNER = "SET_OTP_SPINNER";
export const SET_UPDATE_PROFILE_SPINNER = "SET_UPDATE_PROFILE_SPINNER";
export const SET_PROFILE_AVATAR_SPINNER = "SET_PROFILE_AVATAR_SPINNER";
export const OPEN_OTP_MODAL = "OPEN_OTP_MODAL";
export const SET_PROFILE_USER_PASSWORDS = "SET_PROFILE_USER_PASSWORDS";
export const SET_TOP_PROFILE_HEADER = "SET_TOP_PROFILE_HEADER";
export const SET_PROFILE_ALL_APPOINTMENTS = "SET_PROFILE_ALL_APPOINTMENTS";
export const SET_PROFILE_GOOGLE_CALENDER_SPINNER =
  "SET_PROFILE_GOOGLE_CALENDER_SPINNER";
export const SET_PROFILE_UPCOMING_APPOINTMENTS_LENGTH =
  "SET_PROFILE_UPCOMING_APPOINTMENTS_LENGTH";

export const setProfileHeader = (arr) => {
  return {
    type: SET_TOP_PROFILE_HEADER,
    payload: arr,
  };
};

export const openOtpModal = (flag) => {
  return {
    type: OPEN_OTP_MODAL,
    payload: flag,
  };
};

export const setUpdateSpinnerStatus = (spinner) => {
  return {
    type: SET_UPDATE_PROFILE_SPINNER,
    payload: spinner,
  };
};

export const setOtpSpinner = (otpSpinner) => {
  return {
    type: SET_OTP_SPINNER,
    payload: otpSpinner,
  };
};

export const setProfileSpinnerStatus = (status) => {
  return {
    type: PROFILE_P_SET_SPINNER_STATUS,
    payload: status,
  };
};

export const setCountryCode = (codes) => {
  return {
    type: SET_COUNTRY_CODE,
    payload: codes,
  };
};

export const setAvatarSpinner = (value) => {
  return {
    type: SET_PROFILE_AVATAR_SPINNER,
    payload: value,
  };
};

export const setUserPassword = (data) => {
  return {
    type: SET_PROFILE_USER_PASSWORDS,
    payload: data,
  };
};

export const setAllAppointments = (data) => {
  return {
    type: SET_PROFILE_ALL_APPOINTMENTS,
    payload: data,
  };
};

export const setUpcomingBookingsLength = (length) => {
  return {
    type: SET_PROFILE_UPCOMING_APPOINTMENTS_LENGTH,
    payload: length,
  };
};

export const setGoogleCalendarSpinner = (flag) => {
  return {
    type: SET_PROFILE_GOOGLE_CALENDER_SPINNER,
    payload: flag,
  };
};

// ----> Updating User's Profile picture into the DB

export function updateUserAvatar(data) {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setAvatarSpinner(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/update/profile/image`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ` + token,
          },
          body: data,
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setAvatarSpinner(false));
        } else if (response.success) {
          await dispatch(setAvatarSpinner(false));
          await dispatch(
            setAlertMessage({
              message: "Profile picture updated successfully",
              color: "green",
            })
          );
          await dispatch(setUserDataInState(response.user));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setAvatarSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

// ---> API to Update the Name and Phone no.

export function saveProfile(data) {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    const token = auth.getAccessToken();
    await dispatch(setUpdateSpinnerStatus(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/profile-update?name=${data.name}&phone=${data.phone}&timezone=${data.timezone}&country_code=${data.country_code}`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setUpdateSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setUpdateSpinnerStatus(false));
          await dispatch(
            setAlertMessage({
              message: "Profile updated successfully",
              color: "green",
            })
          );
          await dispatch(setUserDataInState(response.user));
        }
      } catch (e) {
        await dispatch(setUpdateSpinnerStatus(false));
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
      await dispatch(setUpdateSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 10000);
  };
}

//--> Firing API to sent the OTP code to the User's phone no.
export const sendOtp = (data) => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setProfileSpinnerStatus(true));
    const token = auth.getAccessToken();
    let { country_code } = data;
    let code = country_code.split("+");
    country_code = "+" + code[1];
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/update/phone?phone=${data.phone}&country_code=${country_code}`,
          {
            method: "POST",
            headers: {
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setProfileSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setProfileSpinnerStatus(false));
          await dispatch(openOtpModal(true));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setProfileSpinnerStatus(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error! Please try again.",
          color: "teal",
        })
      );
      await dispatch(setCProfileSpinnerStatus(false));
      //---> Disappearing the Alert Message after 3 sec
      setTimeout(() => {
        dispatch(setAlertMessage({ message: "", color: "" }));
      }, 3000);
    }
  };
};

export const verifyPhone = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setOtpSpinner(true));
    const token = auth.getAccessToken();
    let { userData } = getState().selectState;
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/verify/phone?otp=${data.otp}&phone=${userData.phone}&country_code=${userData.country_code}`,
          {
            method: "POST",
            headers: {
              // 'Content-Type': 'application/vnd.api+json; charset=utf-8',
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(openOtpModal(false));
          await dispatch(setOtpSpinner(false));
        } else if (response.success) {
          await dispatch(openOtpModal(false));
          await dispatch(setUserDataInState(response.data));
          await dispatch(
            setAlertMessage({
              message: response.message,
              color: "green",
            })
          );
          await dispatch(setOtpSpinner(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setOtpSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({ message: "You need to login first", color: "teal" })
      );
      await dispatch(setOtpSpinner(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

//---> API to change the Password by the User
export const changePassword = (data) => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setOtpSpinner(true));
    const token = auth.getAccessToken();
    let params = { params: data };
    let bodyData = JSON.stringify(params);
    if (token) {
      try {
        let result = await fetch(`${__API__}/change-password`, {
          method: "POST",
          body: bodyData,
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setProfileSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(
            setAlertMessage({
              message: "Password changed successfully",
              color: "green",
            })
          );
          await dispatch(setProfileSpinnerStatus(false));
          await dispatch(
            setUserPassword({
              old_password: "",
              new_password: "",
              c_password: "",
            })
          );
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setProfileSpinnerStatus(false));
      }
    } else {
      await dispatch(
        setAlertMessage({ message: "You need to login first", color: "teal" })
      );
      await dispatch(setCProfileSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

// ---> Fethcing the country codes from the database
export const getCountryCode = () => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setProfileSpinnerStatus(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/countries`, {
          method: "GET",
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          await dispatch(
            setAlertMessage({
              message: response.errors.exception,
              color: "teal",
            })
          );
          await dispatch(setProfileSpinnerStatus(false));
        } else if (response.success) {
          await dispatch(setProfileSpinnerStatus(false));
          await dispatch(setCountryCode(response.countries));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setProfileSpinnerStatus(false));
      }
    } else {
      await dispatch(
        setAlertMessage({ message: "You need to login first", color: "teal" })
      );
      await dispatch(setCProfileSpinnerStatus(false));
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const deleteuserAvatar = () => {
  return async (dispatch) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setAvatarSpinner(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/delete/profile/image`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setAvatarSpinner(false));
        } else if (response.success) {
          await dispatch(setAvatarSpinner(false));
          await dispatch(
            setAlertMessage({
              message: "Profile picture deleted successfully",
              color: "green",
            })
          );
          await dispatch(setUserDataInState(response.user));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setAvatarSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error! Please refresh the page.",
          color: "teal",
        })
      );
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const getBookingsLength = () => {
  return async (dispatch) => {
    let token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/all/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        var response = await result.json();
        if (response.success) {
          dispatch(setAllAppointments(response.bookings));
        }
      } catch (e) {
        console.log(e);
      }
    }
  };
};

export const getUpcomingAppointments = () => {
  return async (dispatch) => {
    let token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        var response = await result.json();
        if (response.success) {
          dispatch(setUpcomingBookingsLength(response.upcoming.data));
        }
      } catch (e) {
        console.log(e);
      }
    }
  };
};

// ----------------Google calender  API---------------

export const connectGoogleCalendar = (data) => {
  console.log(data);
  return async (dispatch, getState) => {
    var gapi = window.gapi;
    var CLIENT_ID =
      "651841694791-i9lf1c41irrjenkj05b0e6o0jt29k7ck.apps.googleusercontent.com";
    var DISCOVERY_DOCS = [
      "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
    ];
    var SCOPES = "https://www.googleapis.com/auth/calendar.events";

    gapi.load("client:auth2", () => {
      gapi.client.init({
        apiKey: "",
        clientId: CLIENT_ID,
        discoveryDocs: DISCOVERY_DOCS,
        scope: SCOPES,
      });
    });

    let { upcomingBookings } = getState().ProfileState;
    gapi.auth2
      .getAuthInstance()
      .signIn()
      .then(() => {
        upcomingBookings.map((item) => {
          console.log(item);
          var request = gapi.client.calendar.events.insert({
            calendarId: "primary",
            resource: {
              summary: "Your Safe Space Appointment",
              location: item.counsellor.location,
              description: `counselling session with ${item.counsellor.name}`,
              start: {
                dateTime: new Date(
                  item.booking_date.split("-")[0] +
                    " " +
                    item.booking_date.split("-")[1] +
                    " " +
                    item.booking_date.split("-")[2] +
                    "," +
                    item.counsellor_timezone_slot
                ).toISOString(),
                timeZone: "America/Los_Angeles",
              },
              end: {
                dateTime: new Date(
                  item.booking_date.split("-")[0] +
                    " " +
                    item.booking_date.split("-")[1] +
                    " " +
                    item.booking_date.split("-")[2] +
                    "," +
                    item.counsellor_timezone_slot
                ).toISOString(),
                timeZone: item.user.timezone,
              },
              attendees: [
                { email: item.counsellor.email },
                { email: item.user.email },
              ],
              reminders: {
                useDefault: false,
                overrides: [
                  { method: "email", minutes: 24 * 60 },
                  { method: "popup", minutes: 10 },
                ],
              },
            },
          });

          request.execute((event) => {
            console.log(event);
            // window.open(event.htmlLink);
          });
        });
      });
  };
};

export const actions = {
  changePassword,
  saveProfile,
  updateUserAvatar,
  sendOtp,
  getCountryCode,
  verifyPhone,
  openOtpModal,
  setAlertMessage,
  setAvatarSpinner,
  setUserPassword,
  setUserDataInState,
  setProfileHeader,
  deleteuserAvatar,
  setAllAppointments,
  getBookingsLength,
  getUpcomingAppointments,
  setUpcomingBookingsLength,
  connectGoogleCalendar,
  setMenuHover,
  setCounsellorLocation,
};

const initialState = {
  profileSpinnerStatus: false,
  countryCodes: [],
  otpSpinner: false,
  openModal: false,
  updateProfileSpinner: false,
  avatar_spinner: false,
  profileHeader: ["MY", "Profile"],
  allBookings: [],
  upcomingBookings: [],
  googleSpinner: false,
  password: {
    old_password: "",
    new_password: "",
    c_password: "",
  },
};

const ACTION_HANDLERS = {
  [SET_PROFILE_UPCOMING_APPOINTMENTS_LENGTH]: (state, action) => {
    return {
      ...state,
      upcomingBookings: action.payload,
    };
  },
  [SET_PROFILE_ALL_APPOINTMENTS]: (state, action) => {
    return {
      ...state,
      allBookings: action.payload,
    };
  },
  [SET_UPDATE_PROFILE_SPINNER]: (state, action) => {
    return {
      ...state,
      updateProfileSpinner: action.payload,
    };
  },
  [SET_OTP_SPINNER]: (state, action) => {
    return {
      ...state,
      otpSpinner: action.payload,
    };
  },
  [PROFILE_P_SET_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      profileSpinnerStatus: action.payload,
    };
  },
  [OPEN_OTP_MODAL]: (state, action) => {
    return {
      ...state,
      openModal: action.payload,
    };
  },
  [SET_COUNTRY_CODE]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["name"];
      action.payload[i].value = action.payload[i]["phonecode"];
      delete action.payload[i].name;
      delete action.payload[i].phonecode;
    }
    return {
      ...state,
      countryCodes: action.payload,
    };
  },
  [SET_PROFILE_AVATAR_SPINNER]: (state, action) => {
    return {
      ...state,
      avatar_spinner: action.payload,
    };
  },
  [SET_PROFILE_USER_PASSWORDS]: (state, action) => {
    return {
      ...state,
      password: action.payload,
    };
  },
  [SET_TOP_PROFILE_HEADER]: (state, action) => {
    return {
      ...state,
      profileHeader: action.payload,
    };
  },
  [SET_PROFILE_GOOGLE_CALENDER_SPINNER]: (state, action) => {
    return {
      ...state,
      googleSpinner: action.payload,
    };
  },
};

export default function ProfileReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
