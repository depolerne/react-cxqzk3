import React from "react";
import { actions } from "../modules/Profile";
import getUserData from "../../login/modules/auth";
import { bindActionCreators } from "redux";
import ProfileView from "../components/ProfileView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";
import {getCountryCode} from '../modules/Profile'

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
    selectState: state.selectState,
    ProfileState: state.ProfileState,
    auth:state.auth
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => { 
        dispatch(getCountryCode())
    },
    /* eslint-disable */ ErrorComponent: ({ error }) => __DEV__ ? <RedBox error={error} /> : null,
})(ProfileView)

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
