import React from "react";
import { Fragment } from "react";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import { connect } from "react-redux";
import { actions } from "../modules/Profile";

export class ChangePassword extends React.Component {
  constructor(props) {
    super(props);
    this.handlechange = this.handlechange.bind(this);
    this.changePwdHandler = this.changePwdHandler.bind(this);
  }

  handlechange(e) {
    let { password } = this.props.ProfileState;
    let value = e.target.value;
    password[e.target.name] = value;
    this.props.setUserPassword(password);
  }

  componentWillUnmount(){
    this.props.setUserPassword({
      old_password: "",
      new_password: "",
      c_password: "",
    })
  }

  async changePwdHandler(event) {
    event.preventDefault();
    let { password } = this.props.ProfileState;
    if (!password.old_password.length) {
      this.props.setAlertMessage({
        message: "Old password can't be empty",
        color: "teal",
      });
    // } else if (
    //   password.old_password.length < 8 
    //   ) {
    //   this.props.setAlertMessage({
    //     message: "Incorrect old password",
    //     color: "teal",
    //   });
    } else if (password.old_password === password.new_password) {
      this.props.setAlertMessage({
        message: "Old password and New password should not match.",
        color: "teal",
      });
    } else if (password.new_password.search(/[a-z]/i) < 0) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (password.new_password.search(/[0-9]/) < 0) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (
      !/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(password.new_password)
    ) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
     } else if (password.new_password.search(/[0-9]/) < 0) {
        this.props.setAlertMessage({
          message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
          color: "teal",
        });  
    } else if (password.new_password.length<8) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else if (password.c_password !== password.new_password) {
      this.props.setAlertMessage({
        message: "New password must contain 8 characters at least 1 special character, 1 number and 1 letter",
        color: "teal",
      });
    } else {
      this.props.changePassword(password);
    }
    //---> Disappearing the Alert Message after 3 sec

    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  render() {
    let { password } = this.props.ProfileState;
    return (
      <Fragment>
        <form
          className="clearfix profile_form ch_pass-form"
          onSubmit={this.changePwdHandler}
        >
          <div className="form-item">
            <label>Old Password</label>
            <input
              className='placeholder-opacity-50	'
              type="password"
              placeholder="Old Password"
              name="old_password"
              value={password.old_password}
              onChange={this.handlechange}
            />
          </div>
          <div className="form-item">
            <label>New Password</label>
            <input
              placeholder="New Password"
              type="password"
              name="new_password"
              value={password.new_password}
              onChange={this.handlechange}
            />
          </div>
          <div className="form-item">
            <label>Confirm Password</label>
            <input
              type="password"
              placeholder="Confirm Password"
              name="c_password"
              value={password.c_password}
              onChange={this.handlechange}
            />
          </div>
          <div className="form-actions">
            <label />
            <button type="submit" className="user_profile-button">
              {this.props.spinner ? <LoadingSpinner /> : "Submit"}
            </button>
          </div>
        </form>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ProfileState: state.ProfileState,
});

export default connect(mapStateToProps, actions)(ChangePassword);