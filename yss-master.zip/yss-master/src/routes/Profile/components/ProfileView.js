import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import _get from "lodash/get";
import queryString from "query-string";
// import Select from "react-dropdown-select";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import Spinner from "../../../components/Spinner/Spinner";
import OtpModal from "../../../components/Modals/OtpModal";
import ChangePassword from "./ChangePassword";
import { NameValidator } from "../../../helpers/NameValidator";
import { ZoneList } from "../../../helpers/ZoneList";
import InsightBlock from "../../../components/InsightBlock/InsightBlock";
import Select from "react-select";

export class ProfileView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      tab: "profile",
      otp: null,
      update: false,
    };

    this.setProfile = this.setProfile.bind(this);
    this.profileHandler = this.profileHandler.bind(this);
    this.handlechange = this.handlechange.bind(this);
    this.changeAvatar = this.changeAvatar.bind(this);
    this.verifyPhone = this.verifyPhone.bind(this);
    this.onsubmitOtp = this.onsubmitOtp.bind(this);
    this.removeAvatar = this.removeAvatar.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleCountryCode = this.handleCountryCode.bind(this);
    this.connectWithGoogleCalender = this.connectWithGoogleCalender.bind(this);
  }

  async componentDidMount() {
    this.props.setProfileHeader(["Profile"]);
    this.props.getBookingsLength();
    this.props.getUpcomingAppointments();
    this.connectWithGoogleCalender();
    let params = await queryString.parse(this.props.location.search);
    if (params.code && params.scope) {
      this.props.connectWithGoogleCalender(params);
    }
    await this.props.setMenuHover("profile");
    let body = document.body;
    body.className = "dashboard_profile";
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  } 

  async connectWithGoogleCalender() {
    let params = await queryString.parse(this.props.location.search);
    if (params.code && params.scope) {
      console.log(params, "params");
      this.props.connectGoogleCalendar(params);
    }
  }

  setProfile(tab = "profile") {
    this.setState({
      tab: tab,
    });
  }

  handleSelect(selected, event) {
    let { userData } = this.props.selectState;
    userData[event.name] = selected.value;
    this.props.setUserDataInState(userData);
  }

  handleCountryCode(event) {
    let { userData } = this.props.selectState;
    userData["country_code"] = event.value;
    this.props.setUserDataInState(userData);
  }

  handlechange(event) {
    let { userData } = this.props.selectState;
    const name = event.target.name;
    const value = event.target.value;
    userData[name] = value;
    this.props.setUserDataInState(userData);
  }

  onsubmitOtp(otp) {
    this.props.verifyPhone({ otp, history: this.props.history });
    setTimeout(() => {
      this.setState({ openModal: false });
    }, 1000);
  }

  async changeAvatar(event) {
    let type = event.target.files[0];
    if (!type.name.match(/\.(jpg|jpeg|png|JPG|JPEG|PNG)$/)) {
      jQuery("input[type='file']").val("");
      this.props.setAlertMessage({
        message: "The Image type must be JPEG, JPG, PNG",
        color: "teal",
      });
    } else if (event.target.files[0].size > 12400000) {
      this.props.setAlertMessage({
        message: "The Image size must be less than 10 MB",
        color: "teal",
      });
      //---> Disappearing the Alert Message after 3 sec
    } else {
      const fd = new FormData();
      fd.append("image", event.target.files[0]);
      this.props.updateUserAvatar(fd);
    }
    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  verifyPhone() {
    let phFormat = /^[0-9]$/;
    // let { userData } = this.props.selectState;
    // } else {
    //   this.props.sendOtp({ ...userData, history: this.state.history });
    // }
  }

  profileHandler(event) {
    event.preventDefault();
    let { userData } = this.props.selectState;
    let phFormat = /^[0-9]$/;
    let regex = /[!@#$%^`&*()+\=\[\]{};':"\\|,<>\/?]+/;
    if (!userData.name) {
      this.props.setAlertMessage({
        message: "Please enter a valid Name!",
        color: "teal",
      });
    } else if (NameValidator(userData.name.replace(/ /g, ""))) {
      this.props.setAlertMessage({
        message: "Name must starts with 3 alphabets",
        color: "teal",
      });
    } else if (userData.name.length > 32) {
      this.props.setAlertMessage({
        message: "Name can't be larger than 32 characters.",
        color: "teal",
      });
    } else if (regex.test(userData.name)) {
      this.props.setAlertMessage({
        message: "Name should not contain special characters.",
        color: "teal",
      });
    } else if (userData.name.replace(/ /g, "").length < 3) {
      // REMOVING whitespaces from the name and then measuring length
      this.props.setAlertMessage({
        message: "Name must contain 3 characters",
        color: "teal",
      });
    } else if (userData.timezone === "select") {
      this.props.setAlertMessage({
        message: "Please select the timezone!!",
        color: "teal",
      });
    } /*else if (
      userData.phone &&
      (userData.phone.length != 10 || phFormat.test(userData.phone))
    ) {
      this.props.setAlertMessage({
        message: "Please enter a correct phone number",
        color: "teal",
      });
    } else if (!userData.phone && userData.country_code) {
      this.props.setAlertMessage({
        message: "Please enter the phone number",
        color: "teal",
      });
    } else if (
      userData.phone &&
      (!userData.country_code || userData.country_code == "select")
    ) {
      this.props.setAlertMessage({
        message: "Please select the country code.",
        color: "teal",
      });
    }*/ else {
      this.props.saveProfile({ ...userData, history: this.props.history });
    }
    //---> Disappearing the Alert Message after 3 sec

    setTimeout(() => {
      this.props.setAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  removeAvatar() {
    this.props.deleteuserAvatar();
  }

  render() {
    const {
      countryCodes,
      otpSpinner,
      updateProfileSpinner,
      avatar_spinner,
      openModal,
      profileHeader,
      allBookings,
      upcomingBookings,
      googleSpinner,
    } = this.props.ProfileState;

    let { userData, userSpinner } = this.props.selectState;
    let { timezone, country_code } = userData;

    return (
      <Fragment>
        <div className="main-content user_profile--dashboard">
          <div className="site__content">
            {openModal ? (
              <OtpModal
                sendOtp={this.onsubmitOtp}
                spinnerStatus={otpSpinner}
                cancelEvent={() => this.props.openOtpModal(false)}
              />
            ) : null}
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  {profileHeader[0]} <span>{profileHeader[1]}</span>
                </h3>
              </div>
              <div className="site__form middle__content">
                <div className="user__new--section">
                  <div className="tabs__wrapper">
                    <div id="tabs" className="tabs">
                      <ul className="tab_lists">
                        <li
                          className={
                            this.state.tab === "profile"
                              ? "ui-tabs-active"
                              : "ui-tabs"
                          }
                        >
                          <Link
                            to="#"
                            onClick={() => {
                              this.setProfile("profile");
                              this.props.setProfileHeader(["  Profile"]);
                            }}
                          >
                            Profile
                          </Link>
                        </li>
                        <li
                          className={
                            this.state.tab === "changePwd"
                              ? "ui-tabs-active"
                              : "ui-tabs"
                          }
                        >
                          <Link
                            to="#"
                            onClick={() => {
                              this.setProfile("changePwd");
                              this.props.setProfileHeader([
                                "Change",
                                "Password",
                              ]);
                            }}
                          >
                            Change Password
                          </Link>
                        </li>
                      </ul>
                      <div id="tabs-1">
                        {this.state.tab === "profile" ? (
                          userSpinner ? (
                            <Spinner />
                          ) : (
                            <form
                              className="clearfix profile_form"
                              onSubmit={this.profileHandler}
                            >
                              <div className="form-item profile_pic_right">
                                <label />
                                <div className="pro_pic">
                                  {avatar_spinner || userSpinner ? (
                                    <Spinner />
                                  ) : (
                                    userData && (
                                      <img
                                        className="bg-nav w-full"
                                        src={
                                          userData.avatar_id === null
                                            ? "images/user_icon.svg"
                                            : __IMG_URL__ + userData.avatar_id
                                        }
                                      />
                                    )
                                  )}
                                  <span
                                    className="rounded-full"
                                    onClick={() =>
                                      this.setState({ update: true })
                                    }
                                  >
                                    <img src="/images/photograph.svg" />
                                  </span>
                                  {userData.avatar_id === null ? null : (
                                    <span className="pic_options">
                                      <Link
                                        to="#"
                                        title="Remove Profile Pic"
                                        onClick={this.removeAvatar}
                                      >
                                        <i className="far fa-trash-alt"></i>
                                      </Link>
                                    </span>
                                  )}
                                  <input
                                    type="file"
                                    name="avatar_id"
                                    onChange={this.changeAvatar}
                                  />
                                </div>
                              </div>
                              <div className="form-item">
                                <label>Name</label>
                                <input
                                  type="text"
                                  placeholder="name"
                                  name="name"
                                  onChange={this.handlechange}
                                  defaultValue={userData.name}
                                />
                              </div>
                              <div className="form-item">
                                <label>Email</label>
                                <input
                                  type="email"
                                  email="email"
                                  placeholder="Your Email Address"
                                  onChange={this.handlechange}
                                  defaultValue={userData.email}
                                  disabled={true}
                                />
                              </div>
                              <div className="form-item">
                                <label>Time Zone</label>
                                <Select
                                  name={"timezone"}
                                  className="new_select"
                                  options={ZoneList}
                                  value={ZoneList.filter((option) => {
                                    return option.value === timezone;
                                  })}
                                  onChange={this.handleSelect}
                                  searchable={true}
                                />
                              </div>
                              <div className="form-item sync">
                                <label>Sync Calendar</label>
                                <span>
                                  <Link to="#" onClick={()=>this.props.connectGoogleCalendar()}>
                                    Connect with Google calendar
                                  </Link>

                                  {/* <Link to="/calender">
                                    Connect with iCalendar
                                  </Link> */}
                                </span>
                              </div>
                              <div className="form-actions mt-2">
                                <label />
                                <button
                                  type="submit"
                                  className="user_profile-button"
                                >
                                  {updateProfileSpinner ? (
                                    <LoadingSpinner />
                                  ) : (
                                    "Update"
                                  )}
                                </button>
                              </div>
                            </form>
                          )
                        ) : (
                          <ChangePassword />
                        )}
                      </div>
                    </div>
                  </div>
                  {this.state.tab === "profile" ? (
                    <div className="static__blocks bg-white clearfix md:-mx-3">
                      <InsightBlock
                        heading={"Total"}
                        text={"Appointments"}
                        insightData={allBookings.length}
                      />
                      <InsightBlock
                        heading={"Upcoming"}
                        text={"Appointments"}
                        insightData={upcomingBookings.length}
                      />
                    </div>
                  ) : null}
                </div>
                <div className="help__block">
                  <div className="page_title text-center">
                    <h1 className="text-xl">
                      <span className="text_nav_blue">How This Works</span>
                    </h1>
                  </div>
                  <div className="help__text">
                    <p>
                      Contrary to popular belief Lorem Ipsum is not simply
                      random.
                    </p>
                    <p>It has roots a piece classical Latin</p>
                    <p>
                      literature from 45 BC, making it over
                      <br /> 2000 years old. Richard McClintock, a Latin
                      professor at Hampden-Sydney College in Virginia,
                    </p>
                    <p>
                      looked up one of the more obscure
                      <br /> Latin words, consectetur, from a Lorem Ipsum <br />
                      passage, and going through the cites of the word in
                      classical literature, discovered the undoubtable source.
                      Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de
                      Finibus Bonorum et Malorum.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default ProfileView;
