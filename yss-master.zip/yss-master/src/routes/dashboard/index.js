import Dashboard from './containers/DashboardContainer';
export { Dashboard };
export * from './modules/dashboard';

export default Dashboard;
