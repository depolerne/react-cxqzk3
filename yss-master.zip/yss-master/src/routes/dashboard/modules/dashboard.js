import { setModal,setAlertMessage } from "../../selectWrapper/modules/select";
import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
// import { setup } from "mocha";

export const DASH_SET_ERR_MESSAGE = "DASH_SET_ERR_MESSAGE";
export const DASH_SPINNER_STATUS='DASH_SPINNER_STATUS';
export const SET_PAST_BOOKINGS='SET_PAST_BOOKINGS';
export const SET_TODAYS_BOOKING='SET_TODAYS_BOOKING';
export const SET_UPCOMING_BOOKINGS='SET_UPCOMING_BOOKINGS';
export const SET_ALL_BOOKINGS_DATA='SET_ALL_BOOKINGS_DATA';

export const setDashboardSpinner=(value)=> {
  return {
    type: DASH_SPINNER_STATUS,
    payload: value,
  };
}

export const setPastBookings=(bookings)=>{
  return {
    type: SET_PAST_BOOKINGS,
    payload: bookings,
  }
}

export const setTodaysBookings=(todaysBookings)=>{
  return {
    type: SET_TODAYS_BOOKING,
    payload: todaysBookings,
  }
}

export const setUpcomingBookings=(upcomingData)=>{
  return {
    type: SET_UPCOMING_BOOKINGS,
    payload: upcomingData,
  }
}

export const setDashboardErrMessage=(err)=> {
  return {
    type: DASH_SET_ERR_MESSAGE,
    payload: err,
  };
}

export const fetchBooking = () => {
  return async (dispatch) => {
    await dispatch(setDashboardSpinner(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/drupal.single+json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          await dispatch(setDashboardSpinner(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setTodaysBookings(response.todays.data));
          await dispatch(setPastBookings(response.past.data));
          await dispatch(setUpcomingBookings(response.upcoming.data));
          await dispatch(setDashboardSpinner(false));
        }
      } catch (e) {
        await dispatch(setDashboardErrMessage("Server error Please try again."));
        await dispatch(setDashboardSpinner(false));
        (e);
      }
    } else {
      await dispatch(setDashboardErrMessage("No account details available"));
      await dispatch(setDashboardSpinner(false));
    }
  };
};

export const actions = {
  setPastBookings,
  setTodaysBookings,  
  fetchBooking,
  setDashboardSpinner,
};

const initialState = {
  spinnerStatus:false,
  pastBookings:[],
  todaysBookings:[],
  upcomingBookings:[],
  dashboardErrMessage:'',
  allBookings:[]
};

const ACTION_HANDLERS = {
  // ADMIN_REDUCERS

  [SET_ALL_BOOKINGS_DATA]:(state,action)=>{
    return{
      ...state,
      allBookings:action.payload
    }
  },
  [SET_UPCOMING_BOOKINGS]:(state,action)=>{
    return{
      ...state,
      upcomingBookings:action.payload
    }
  },
  [SET_PAST_BOOKINGS]: (state, action) => {
    return {
      ...state,
      pastBookings: action.payload,
    };
  },
  [SET_TODAYS_BOOKING]:(state,action)=>{
    return {
      ...state,
      todaysBookings:action.payload    
    }
  },
  [DASH_SET_ERR_MESSAGE]:(state,action)=>{
    return {
      ...state,
      dashboardErrMessage: action.payload,
    }
  },
  [DASH_SPINNER_STATUS]:(state,action)=>{
    return {
      ...state,
      spinnerStatus: action.payload,
    }
  }
};


export default function homeReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
