import React, { Fragment } from "react";
import UserBookingBlock from "../../../components/UserBookingBlock/UserBookingBlock";
import Spinner from "../../../components/Spinner/Spinner";
import moment from "moment";
import { Calendar, momentLocalizer } from "react-big-calendar";
import "react-big-calendar/lib/css/react-big-calendar.css";
import auth from "../../../helpers/auth";

const localizer = momentLocalizer(moment);

var values = [];

export class DashboardView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      loadingSpinner: "",
      Bookings: "",
      events: [],
      name: "",
    };
    this.loadData = this.loadData.bind(this);
  }

  componentDidMount() {
    let body=document.body;
    body.className="dashboard"  
    this.loadData();
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  async loadData() {
    const token = auth.getAccessToken();
    this.setState({ loadingSpinner: true });
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/all/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        var response = await result.json();
        if (response.success) {
          this.setState({ Bookings: response.bookings, loadingSpinner: false });
        } else if (!response.success) {
          this.setState({ loadingSpinner: false });
        }
      } catch (e) {
        console.log(e);
        this.setState({ loadingSpinner: false });
      }
    }
    let { Bookings } = this.state;
    for (let i = 0; i < Bookings.length; i++) {
      let temp = {};
      let duration =
        +Bookings[i].package.session_hours * 60 +
        +Bookings[i].package.session_minutes;
      let bookingDate = Bookings[i].booking_date.split("-"); // removing dashes from the date
      let startvalue = new Date(
        bookingDate[0] +
          " " +
          bookingDate[1] +
          " " +
          bookingDate[2] +
          "," +
          Bookings[i].counsellor_timezone_slot
      );
      let endvalue = new Date(startvalue.getTime() + duration * 60000);
      temp = Object.assign(
        temp,
        { start: startvalue },
        { end: endvalue },
        { title: `${Bookings[i].counsellor.name}` }
      );
      if (
        values.length !== Bookings.length &&
        values.length <= Bookings.length
      ) {
        values.push(temp);
      } 
    } 
    this.setState({ events: values });
  }

  render() {
    const {
      pastBookings,
      todaysBookings,
      spinnerStatus,
      upcomingBookings,
    } = this.props.dashboardState;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            <div className="rounded-24 w-full mb-6 xl:mb-0 md:w-full xl:h-full xl:w-1/4 overflow-hidden">
              <div className="information_block overflow-y-auto">
                <div className="page_title">
                  <h1>
                    <span className="text_nav_blue">Dashboard</span>
                  </h1>
                </div>
                <div className="user_booking_detail bg-opacity-50">
                  <div className="enquiry_details clearfix">
                    <h2>Bookings</h2>
                    <h2>
                      <span className="text_nav_blue">
                        {todaysBookings.length}
                      </span>
                    </h2>
                  </div>
                  {spinnerStatus ? (
                    <Spinner />
                  ) : todaysBookings.length === 0 ? (
                    "No Appointments for today"
                  ) : (
                    todaysBookings.map((item, i) => (
                      <UserBookingBlock
                        key={i}
                        dr_name={item.counsellor.name}
                        Dr_type={"Coaching"}
                        time_slot={item.counsellor_timezone_slot}
                        booking_date={item.booking_date}
                      />
                    ))
                  )}
                </div>
                {/* <div className="user_booking_history">
                  <div className="enquiry_details appointments_details clearfix">
                    <h2>Booking History</h2>
                  </div>
                  {spinnerStatus ? (
                    <Spinner />
                  ) : pastBookings.length === 0 ? (
                    "No Booking history"
                  ) : (
                    pastBookings.map((item, i) => (
                      <UserBookingBlock
                        key={i}
                        dr_name={item.counsellor.name}
                        Dr_type={"Consultant"}
                        time_slot={item.slot}
                        booking_date={item.booking_date}
                      />
                    ))
                  )}
                </div> */}
              </div>
            </div>
            <div className="w-full mt-6 xl:pl-6 md:w-full xl:w-3/4 sm:mt-0">
              <div className="w-full">
                {/* ---> calender block---------- */}
                {this.state.loadingSpinner ? (
                  <Spinner />
                ) : (
                  <Calendar
                    localizer={localizer}
                    defaultDate={new Date()}
                    defaultView="month"
                    events={this.state.events}
                    style={{ height: "100vh" }}
                    tooltipAccessor={"Ibyte infomatics"}
                    views={['month', 'day', 'week']}
                  />
                )}

                {/* <div className="static__blocks bg-white px-6 py-3 md:p-6 mt-6 clearfix">
                  <InsightBlock
                    heading={"Total"}
                    text={"Appointments"}
                    insightData={this.state.events.length}
                  />
                  <InsightBlock
                    heading={"Upcoming"}
                    text={"Appointments"}
                    insightData={upcomingBookings.length}
                  />
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default DashboardView;
