import React from "react";
import { actions, fetchBooking } from "../modules/dashboard";
import { bindActionCreators } from "redux";
import DashboardView from "../components/DashboardView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState:state.selectState,
  dashboardState: state.dashboardState,
  auth:state.auth
});

const withJobComponent = withJob({
  work: async ({ dispatch }) => {
    dispatch(fetchBooking());
  },
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(DashboardView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
