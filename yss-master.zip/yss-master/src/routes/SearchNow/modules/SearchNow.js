import { setSiteAlertMessage } from "../../SiteWrapper/modules/site";

export const SET_SEARCH_NOW_SPINNER_STATUS = "SET_SEARCH_NOW_SPINNER_STATUS";
export const SET_LISTING_DATA_BY_SEARCH_NOW = "SET_LISTING_DATA_BY_SEARCH_NOW";
export const SET_SEARCH_NOW_LISTING_CATEGORY =
  "SET_SEARCH_NOW_LISTING_CATEGORY";
export const SET_SEARCH_NOW_LISTING_LABLES = "SET_SEARCH_NOW_LISTING_LABLES";
export const SET_SEARCH_NOW_CATEGORY_VALUE = "SET_SEARCH_NOW_CATEGORY_VALUE";
export const SET_SEARCH_NOW_LABEL_VALUE = "SET_SEARCH_NOW_LABEL_VALUE";
export const SET_SEARCH_NOW_FILTER_VALUE = "SET_SEARCH_NOW_FILTER_VALUE";
export const SET_SEARCH_NOW_COUNSELLOR_DETAILS_ON_MAP =
  "SET_SEARCH_NOW_COUNSELLOR_DETAILS_ON_MAP";
export const SET_FILTER_LISTING_REGIONS = "SET_FILTER_LISTING_REGIONS";
export const SET_SEARCH_NOW_FILTERS = "SET_SEARCH_NOW_FILTERS";
export const SET_SEARCH_NOW_MODAL_CLUSTERS_DATA =
  "SET_SEARCH_NOW_MODAL_CLUSTERS_DATA";
export const SET_SEARCH_NOW_CLUSTER_MODAL = "SET_SEARCH_NOW_CLUSTER_MODAL";

//---> Fetching userDate and Saving the user data into the redux state

export const setSearchNowSpinner = (flag) => {
  return {
    type: SET_SEARCH_NOW_SPINNER_STATUS,
    payload: flag,
  };
};

export const setListingsData = (data) => {
  return {
    type: SET_LISTING_DATA_BY_SEARCH_NOW,
    payload: data,
  };
};

export const setCategoryValue = (value) => {
  return {
    type: SET_SEARCH_NOW_CATEGORY_VALUE,
    payload: value,
  };
};

export const setLabelValue = (value) => {
  return {
    type: SET_SEARCH_NOW_LABEL_VALUE,
    payload: value,
  };
};

export const setFilterValue = (value) => {
  return {
    type: SET_SEARCH_NOW_FILTER_VALUE,
    payload: value,
  };
};

export const setListingCategories = (data) => {
  return {
    type: SET_SEARCH_NOW_LISTING_CATEGORY,
    payload: data,
  };
};

export const setLisitngLabels = (lables) => {
  return {
    type: SET_SEARCH_NOW_LISTING_LABLES,
    payload: lables,
  };
};

export const setDetailsOnMap = (flag) => {
  return {
    type: SET_SEARCH_NOW_COUNSELLOR_DETAILS_ON_MAP,
    payload: flag,
  };
};

export function setFilters(data) {
  return {
    type: SET_SEARCH_NOW_FILTERS,
    payload: data,
  };
}

export function setListingRegions(params) {
  return {
    type: SET_FILTER_LISTING_REGIONS,
    payload: params,
  };
}

export function setClusterModal(params){
  return {
    type:SET_SEARCH_NOW_CLUSTER_MODAL,
    payload:params
  }
}

export function setModalClustersData(data){
  return {
    type:SET_SEARCH_NOW_MODAL_CLUSTERS_DATA,
    payload:data
  }
}

export function searchListings(page, all) {
  return async (dispatch, getState) => {
    let {
      filters: { category, region, labels, sort_by, column, order },
    } = getState().searchNowState;
    await dispatch(setSearchNowSpinner(true));
    try {
      let result = await fetch(
        `${__API__}/search/listing?listing_category=${category}&column=${column}&order=${order}&sort_by=${sort_by}&listing_label=${labels}&all_records=${all}&page=${page}&regions=${region}`,
        {
          method: "GET",
          mode: "cors",
          headers: {
            "Content-Type": "application/drupal.single+json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item],
              color: "teal",
            })
          );
        });
        await dispatch(setSearchNowSpinner(false));
      } else if (response.success) {
        await dispatch(setListingsData(response.data));
        await dispatch(setSearchNowSpinner(false));
      }
    } catch (e) {
      await dispatch(setSearchNowSpinner(false));
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchCategory() {
  return async (dispatch) => {
    try {
      let category = await fetch(`${__API__}/get/listing/category`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await category.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
        await dispatch(setSearchNowSpinner(false));
      } else if (response.success) {
        await dispatch(setListingCategories(response.categories));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchLables() {
  return async (dispatch) => {
    try {
      let lables = await fetch(`${__API__}/get/listing/label`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await lables.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
        await dispatch(setSearchNowSpinner(false));
      } else if (response.success) {
        await dispatch(setLisitngLabels(response.labels));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function fetchRegions() {
  return async (dispatch) => {
    try {
      let category = await fetch(`${__API__}/get/listing/region`, {
        method: "GET",
        headers: {
          "Content-Type": "application/drupal.single+json; charset=utf-8",
          Accept: "application/json",
        },
      });
      let response = await category.json();

      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setSiteAlertMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
        await dispatch(setSearchNowSpinner(false));
      } else if (response.success) {
        await dispatch(setListingRegions(response.regions));
      }
    } catch (e) {
      await dispatch(
        setSiteAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export const actions = {
  searchListings,
  setSearchNowSpinner,
  setSiteAlertMessage,
  fetchCategory,
  setListingCategories,
  setLisitngLabels,
  fetchLables,
  setFilterValue,
  setLabelValue,
  setCategoryValue,
  setDetailsOnMap,
  fetchRegions,
  setFilters,
  setClusterModal,
  setModalClustersData
};

const initialState = {
  searchNowSpinner: false,
  categories: [],
  listings: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
    total: 0,
  },
  filters: {
    category: "",
    region: "",
    labels: [],
    sort_by: "",
    order: "desc",
    column: "id",
  },
  labels: [],
  regions: [],
  labelValue: [],
  showDetailsOnMap: false,
  reviews: [],
  selectedCluster: [],
  openCluster: false,
};

const ACTION_HANDLERS = {
  [SET_SEARCH_NOW_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      searchNowSpinner: action.payload,
    };
  },
  [SET_SEARCH_NOW_LISTING_CATEGORY]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["category_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].category_name;
      delete action.payload[i].id;
    }
    return {
      ...state,
      categories: action.payload,
    };
  },
  [SET_LISTING_DATA_BY_SEARCH_NOW]: (state, action) => {
    return {
      ...state,
      listings: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
        total: action.payload.total,
      },
    };
  },
  [SET_SEARCH_NOW_LISTING_LABLES]: (state, action) => {
    return {
      ...state,
      labels: action.payload,
    };
  },
  [SET_SEARCH_NOW_CATEGORY_VALUE]: (state, action) => {
    return {
      ...state,
      categoryValue: action.payload,
    };
  },
  [SET_SEARCH_NOW_LABEL_VALUE]: (state, action) => {
    return {
      ...state,
      labelValue: action.payload,
    };
  },
  [SET_SEARCH_NOW_FILTER_VALUE]: (state, action) => {
    return {
      ...state,
      filterValue: action.payload,
    };
  },
  [SET_SEARCH_NOW_COUNSELLOR_DETAILS_ON_MAP]: (state, action) => {
    return {
      ...state,
      showDetailsOnMap: action.payload,
    };
  },
  [SET_FILTER_LISTING_REGIONS]: (state, action) => {
    for (var i = 0; i < action.payload.length; i++) {
      action.payload[i].label = action.payload[i]["region_name"];
      action.payload[i].value = action.payload[i]["id"];
      delete action.payload[i].region_name;
      delete action.payload[i].id;
    }
    return {
      ...state,
      regions: action.payload,
    };
  },
  [SET_SEARCH_NOW_FILTERS]: (state, action) => {
    return {
      ...state,
      filters: action.payload,
    };
  },
  [SET_SEARCH_NOW_CLUSTER_MODAL]: (state, action) => {
    return {
      ...state,
      openCluster: action.payload,
    };
  },
  [SET_SEARCH_NOW_MODAL_CLUSTERS_DATA]: (state, action) => {
    return {
      ...state,
      selectedCluster: action.payload,
    };
  },
};

export default function searchNowReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
