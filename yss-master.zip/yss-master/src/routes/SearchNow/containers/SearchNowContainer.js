import React from "react";
import {
  actions
} from "../modules/SearchNow";
import { bindActionCreators } from "redux";
import SearchNowView from "../components/SearchNowView";
import { connect } from "react-redux";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  searchNowState: state.searchNowState,
  auth: state.auth,
});

export default connect(mapStateToProps, mapDispatchToProps)(SearchNowView);
