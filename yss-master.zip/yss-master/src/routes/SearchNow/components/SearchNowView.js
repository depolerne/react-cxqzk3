import React, { Fragment } from "react";
import MapContainer from "../../../components/MapContainer/MapContainer";
import Spinner from "../../../components/Spinner/Spinner";
import { Link } from "react-router-dom";
import Select from "react-select";
import ReactStars from "react-rating-stars-component";
import { sortBy } from "../../../helpers/SortBy";
let arr = [];
import ClusterModal from "../../../components/MapContainer/ClusterModal";

export class SearchNowView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errClass: "",
    };
    this.submitHandler = this.submitHandler.bind(this);
    this.handleSelect = this.handleSelect.bind(this);
    this.handleChecks = this.handleChecks.bind(this);
    this.handleFilters = this.handleFilters.bind(this);
    this.changePage = this.changePage.bind(this);
    this.prevPage = this.prevPage.bind(this);
    this.nextPage = this.nextPage.bind(this);
    this.handleSortBy = this.handleSortBy.bind(this);
  }

  componentDidMount() {
    arr = [];
    let body = document.body;
    body.className = "search_now";

    this.props.fetchCategory();
    this.props.fetchLables();
    this.props.fetchRegions();
    document.addEventListener("keyup", (e) => {
      if (e.keyCode === 27) {
        this.props.setDetailsOnMap(false);
        this.props.setClusterModal(false)
      }
    });
    let { filters } = this.props.searchNowState;
    filters["column"] = "id"
    filters["order"] = "desc"
    filters["sort_by"] = "newest"
    this.props.setFilters(filters);
    this.props.searchListings(1, 1);
  }

  handleFilters(e) {
    let { filters } = this.props.searchNowState;
    filters[e.target.name] = e.target.value;
    this.props.setFilters(filters);
  }

  handleSelect(selected, event) {
    let { filters } = this.props.searchNowState;
    filters[event.name] = selected.value;
    this.props.setFilters(filters);
  }

  handleSortBy(selected, event) {
    let { filters } = this.props.searchNowState;
    let {
      listings: { currentPage },
    } = this.props.searchNowState;

    if(selected.value == 'newest'){
      filters["column"] = "id"
      filters["order"] = "desc"
      filters["sort_by"] = "newest"

    }else if(selected.value == 'oldest') {
      filters["column"] = "id"
      filters["order"] = "asc"
      filters["sort_by"] = "oldest"

    }else if(selected.value == 'highest'){
      filters["column"] = "avg_rating"
      filters["order"] = "desc"
      filters["sort_by"] = "highest"

    }else if(selected.value == 'lowest'){
      filters["column"] = "avg_rating"
      filters["order"] = "asc"
      filters["sort_by"] = "lowest"
    }else{
      filters["column"] = "id"
      filters["order"] = "desc"
      filters["sort_by"] = "newest"
    }

    this.props.setFilters(filters);
    this.props.searchListings(1, "");
  }

  submitHandler(e) {
    let {
      listings: { currentPage },
    } = this.props.searchNowState;
    e.preventDefault();
    this.props.searchListings(1, "");
  }

  handleChecks(e) {
    let { filters } = this.props.searchNowState;
    let id = e.target.id;
    if (!arr.includes(id)) {
      arr.push(id);
    } else {
      let index = arr.indexOf(id);
      arr.splice(index, 1);
    }

    filters["labels"] = arr;
    this.props.setFilters(filters);
  }

  async prevPage(e) {
    let { listings } = this.props.searchNowState;

    let num = (await parseInt(listings.currentPage)) - 1;
    if (listings.currentPage > 1) {
      listings.currentPage = num;
    }
    this.props.searchListings(num, 1);
  }

  async nextPage() {
    let { listings } = this.props.searchNowState;
    let num = (await parseInt(listings.currentPage)) + 1;
    if (listings.currentPage < listings.last_page) {
      listings.currentPage = num;
    }
    this.props.searchListings(num, 1);
  }

  async changePage(e) {
    let { listings } = this.props.searchNowState;
    let value = await parseInt(e.target.name);
    listings["currentPage"] = value;

    this.props.searchListings(value, 1);
  }

  setPageClass(value) {
    let { listings } = this.props.searchNowState;
    if (listings.currentPage === value) {
      return true;
    } else {
      return false;
    }
  }

  componentWillUnmount() {
    this.props.setFilters({
      category: "",
      region: "",
      labels: [],
      sort_by: "",
    });
  }

  render() {
    let {
      searchNowSpinner,
      categories,
      labels,
      filters: { category, region, sort_by },
      regions,
      openCluster,
      listings: { data, last_page, currentPage, totalPage, total },
    } = this.props.searchNowState;

    return (
      <Fragment>
        <div className="main-content yss-site--main__content map-search--form-page lg:flex lg:flex-row">
          {openCluster ? <ClusterModal /> : null}

          <div className="site-location--map lg:w-2/5 overflow-hidden">
            {searchNowSpinner ? <Spinner /> : <MapContainer />}
          </div>
          <div className="site__form middle__content add-listing--form lg:w-3/5 lg:px-6 lg:mr-auto relative">
            <form className="clearfix" onSubmit={this.submitHandler}>
              <div className="form-item form-grid md:flex md:flex-wrap">
                <Select
                  name={"region"}
                  className="new_select"
                  options={regions}
                  placeholder={"Select Region"}
                  value={regions.filter((option) => {
                    return option.value === region;
                  })}
                  onChange={this.handleSelect}
                  searchable={true}
                />
                <Select
                  name={"category"}
                  className="new_select"
                  placeholder={"Category"}
                  options={categories}
                  value={categories.filter((option) => {
                    return option.value === category;
                  })}
                  onChange={this.handleSelect}
                  searchable={true}
                />
                {/* </div> */}
              </div>
              <div className="form-item">
                <label>Filter by label:</label>
                <div className="form-item--checkbox">
                  {labels.map((i) => (
                    <span key={i.id}>
                      <input
                        type="checkbox"
                        id={i.id}
                        onChange={this.handleChecks}
                      />
                      <label htmlFor={i.id}>{i.label_name}</label>
                    </span>
                  ))}
                </div>
                <div className="form-item--checkbox"></div>
              </div>
              <div className="form-actions ">
                <button type="submit">Update</button>
              </div>
              <div className="filter__counters">
                <p>
                  {data.length
                    ? `Showing ${data.length} Results out of ${total}`
                    : 'No data found'}
                </p>
                <div className="form-item first_slot slots">
                  <Select
                    name={"sort_by"}
                    className="new_select"
                    placeholder={"Sort by"}
                    options={sortBy}
                    value={sortBy.filter((option) => {
                      return option.value === sort_by;
                    })}
                    onChange={this.handleSortBy}
                    searchable={true}
                  />
                </div>
              </div>
            </form>
            {/*------------- Listings card ---------------------- */}
            {searchNowSpinner ? (
              <Spinner text={"fetching..."} />
            ) : (
              <div className="search__results">
                <ul className="result-lists">
                  {data.map((item, i) => (
                    <li key={item.id}>
                      <Link to={`/listing/${item.id}/${item.slug_url}`}>
                        <div className="result--details">
                          <div className="result-cover" 
						  style={{
						  backgroundImage: `url(${
							__IMG_URL__ + item.cover_img
						  })`,
						  }}
						  >
						  {/*{item.cover_img === "" ? null : (
                              <img src={__IMG_URL__ + item.cover_img} />
						  )}*/}
                          </div>
                          <div className="result__meta">
                            <h2 className="result-title">
                              {item.listing_name}
                            </h2>
                            <p className="result-loaction">{(item.location.length > 27) ? item.location.substring(0,27)+"..." : item.location}</p>
                            {/*item.phone && (
								<p className="result-number">
                                <i className="fas fa-phone-alt"></i>{" "}
                                {item.phone}
								</p>
                            )*/}
                          </div>
                          <div className="result-footer flex">
                            {item && (
                              <ReactStars
                                size={30}
                                edit={false}
                                isHalf={true}
                                value={parseFloat(item.avg_rating).toFixed(2)}
                                activeColor="#eb8a2f"
                                className="hellooo"
                              />
                            )}
                            {/* {item.avg_rating ? (
                              <h1 className="text-yellow-600 font-bold text-xl my-auto">
                                {"(" +
                                  parseFloat(item.avg_rating).toFixed(1) +
                                  ")"}
                              </h1>
                            ) : (
                              <h1 className="text-gray-600 font-bold text-xl my-auto">
                                {"(" + 0 + ")"}
                              </h1>
                            )} */}
                            <div className="result-avtaar">
                              {item.user.avatar_id ? (
                                <img src={__IMG_URL__ + item.user.avatar_id} />
                              ) : (
                                <img src="images/site-avatar.png" />
                              )}
                              {item.user &&
                                item.user.profile_percentage === 100 && (
                                  <span className="claimed-ribbon"></span>
                                )}
                            </div>
                          </div>
                        </div>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            )}
            {data.length == 0 || last_page == 1 ? null : (
              <div className="site_pagination">
                <ul>
                  <li className={currentPage > 1 ? "prev" : "disable"}>
                    <Link to="#" onClick={this.prevPage}>
                      &lt; Prev{" "}
                    </Link>
                  </li>
                  {totalPage.map((number, i) => {
                    return (
                      <li className="prev" key={i}>
                        <Link
                          to="#"
                          className={
                            this.setPageClass(number + 1)
                              ? "bg-blue-900 text-white"
                              : ""
                          }
                          name={number + 1}
                          onClick={this.changePage}
                        >
                          {number + 1}
                        </Link>
                      </li>
                    );
                  })}
                  <li className={currentPage < last_page ? "next" : "disable"}>
                    <Link to="#" onClick={this.nextPage}>
                      Next &gt;{" "}
                    </Link>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </div>
      </Fragment>
    );
  }
}

export default SearchNowView;
