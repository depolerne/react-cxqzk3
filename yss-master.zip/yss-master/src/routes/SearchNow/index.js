import SearchNow from './containers/SearchNowContainer';
export { SearchNow };
export * from './modules/SearchNow';

export default SearchNow;
