import React, { Fragment } from "react";
import { renderRoutes } from "react-router-config";
import auth from "../../helpers/auth";
import NotificationBar from "../../components/NotificationBar/NotificationBar";
import AlertBox from "../../components/AlertBox/AlertBox";
import { connect } from "react-redux";
import { actions} from "../selectWrapper/modules/select";
import { withJob } from "react-jobs";

export class SessionWrapper extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount() {
    this.props.getUserData();
  }

  render() {
    const { alertMessage } = this.props.selectState;
    return (
      <Fragment>
        {alertMessage.message ? (
          <AlertBox
            color={alertMessage.color}
            AlertText={alertMessage.message}
          />
        ) : null}
        <Fragment>{renderRoutes(this.props.route.routes)}</Fragment>

      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
    selectState: state.selectState,
    CDashboardState: state.CDashboardState,
  });
  
export default connect(mapStateToProps, actions)(SessionWrapper);
