import auth from "../../../helpers/auth";
import { setAlertMessage } from "../../selectWrapper/modules/select";
import { setBookingModal } from "../../Listing/modules/Listing";
import { setSiteAlertMessage } from "../../SiteWrapper/modules/site"
//---> Defining types for different actions

export const SET_CHECKOUT_DATA = "SET_CHECKOUT_DATA";
export const SET_CHECKOUT_ERR_MESSAGE = "SET_CHECKOUT_ERR_MESSAGE";
export const SET_LOADING_SPINNER_STATUS = "SET_LOADING_SPINNER_STATUS";
export const SET_COUNSELLOR_AVAILABILITY_SLOTS =
  "SET_COUNSELLOR_AVAILABILITY_SLOTS";
export const SET_SHOW_PACKAGE_MESSAGE = "SET_SHOW_PACKAGE_MESSAGE";
export const SET_SELECTED_SLOTS_BY_USER = "SET_SELECTED_SLOTS_BY_USER";
export const SET_TIME_AVAIL_VALUE = "SET_TIME_AVAIL_VALUE";
export const SET_DATE_AVAIL_VALUE='SET_DATE_AVAIL_VALUE';
export const SET_TOTAL_PACKAGE_AMOUNT='SET_TOTAL_PACKAGE_AMOUNT';
export const SET_LAST_SELECTED_DATE_BY_USER="SET_LAST_SELECTED_DATE_BY_USER"
//---> Defining Actions to set state variables

export function setShowPackageMessage(data) {
  return {
    type: SET_SHOW_PACKAGE_MESSAGE,
    payload: data,
  };
}

export function setCheckoutdata(data) {
  return {
    type: SET_CHECKOUT_DATA,
    payload: data,
  };
}

export function setLoadingSpinnerStatus(status) {
  return {
    type: SET_LOADING_SPINNER_STATUS,
    payload: status,
  };
}

export function setCounsellorAvailability(jsonData) {
  return {
    type: SET_COUNSELLOR_AVAILABILITY_SLOTS,
    payload: jsonData,
  };
}

export function setCheckoutErrMessage(message) {
  return {
    type: SET_CHECKOUT_ERR_MESSAGE,
    payload: message,
  };
}

export function setSelectedSlots(obj){
  return {
    type: SET_SELECTED_SLOTS_BY_USER,
    payload: obj,
  };
};

export const setTimeAvail = (time) => {
  return {
    type: SET_TIME_AVAIL_VALUE,
    payload: time,
  };
};

export const setDateAvail=(value)=>{
  return {
    type: SET_DATE_AVAIL_VALUE,
    payload: value,
  };
}

export const setFinalAmount=(amt)=>{
  return {
    type: SET_TOTAL_PACKAGE_AMOUNT,
    payload: amt
  }
}

export function setLastselectedDate(date){
  return {
    type: SET_LAST_SELECTED_DATE_BY_USER,
    payload: date
  }
}

export function checkout() {
  return async (dispatch) => {
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/api/Checkout`, {
          method: "GET",
          mode: "cors",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            "access-token": token,
          },
        });
        let json = await result.json();

        if (json.data.length) {
          await dispatch(setCheckoutdata(json.data));
        } else {
          await dispatch(setCheckoutErrMessage([]));
        }
      } catch (e) {
        await dispatch(setNews([]));
        console.log(e);
      }
    } else {
      await dispatch(setNews([]));
    }
  };
}

//---> API to fetch available time slots of counsellor

export const fetchAvailability = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setLoadingSpinnerStatus(true));
    let { user_id } = getState().ListingState.listing_data;
    let {userData}=getState().selectState;

    const token = auth.getAccessToken();
    var dateString;
    if (data.date === "" || data.date === undefined) {
      var dateString = new Date().toISOString().slice(0, 10);
    } else {
      dateString = new Date(
        data.date.year + " " + data.date.month + " " + data.date.day
      );
      let month = "" + (dateString.getMonth() + 1);
      let day = "" + dateString.getDate();
      let year = dateString.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;
      dateString = [year, month, day].join("-");
    }
    await dispatch(setDateAvail(dateString));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/break-packages?user_id=${userData.id}&package_id=${data.targetPackage.id}&date=${dateString}&counsellor_id=${user_id}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/vnd.api+json; et=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          await dispatch(setLoadingSpinnerStatus(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setCounsellorAvailability(response.data));

          // ------------------------------------
          if (response.data.length === 0) {
            await dispatch(
              setShowPackageMessage({
                message: "No slots are available",
                color: "teal",
              })
            );
          }
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        console.log(e);
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const AddSlots = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    await dispatch(setLoadingSpinnerStatus(true));
    let { counsellor_id } = getState().CListingState;
    if (data.targetPackage === "") {
      data.history.push(`/packages/${counsellor_id}`);
    }

    const token = auth.getAccessToken();
    let { c_zone } = getState().CListingState;
    var dateString;

    if (data.date === "" || data.date === undefined) {
      var dateString = new Date().toISOString().slice(0, 10);
    } else {
      dateString = new Date(
        data.date.year + " " + data.date.month + " " + data.date.day
      );
      // dateString = moment(
      //   new Date(data.date.year + "-" + data.date.month + "-" + data.date.day)).tz(c_zone).format("YYYY-MM-DD");
      let month = "" + (dateString.getMonth() + 1);
      let day = "" + dateString.getDate();
      let year = dateString.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;
      dateString = [year, month, day].join("-");
    }
    await dispatch(setDateAvail(dateString));
    if (token) {
      try {
        let result = await fetch(`${__API__}/add/packages?date=${dateString}`, {
          method: "GET",
          headers: {
            "Content-Type": "application/vnd.api+json; et=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          await dispatch(setLoadingSpinnerStatus(false));
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setCounsellorAvailability(response.data));

          // ------------------------------------
          if (response.data.length === 0) {
            await dispatch(
              setShowPackageMessage({
                message: "No slots are available",
                color: "teal",
              })
            );
          }
          await dispatch(setLoadingSpinnerStatus(false));
        }
      } catch (e) {
        console.log(e);
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setLoadingSpinnerStatus(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
      await dispatch(setLoadingSpinnerStatus(false));
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const saveSlotstoCart = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    let { counsellor_id } = getState().CListingState;
    const token = auth.getAccessToken();
    var dateString;
    if (data.date === "" || data.date === undefined) {
      var dateString = new Date().toISOString().slice(0, 10);
    } else {
      dateString = new Date(
        data.date.year + " " + data.date.month + " " + data.date.day
      );
      // dateString = moment(
      //   new Date(data.date.year + "-" + data.date.month + "-" + data.date.day)).tz(c_zone).format("YYYY-MM-DD");
      let month = "" + (dateString.getMonth() + 1);
      let day = "" + dateString.getDate();
      let year = dateString.getFullYear();

      if (month.length < 2) month = "0" + month;
      if (day.length < 2) day = "0" + day;
      dateString = [year, month, day].join("-");
    }
    await dispatch(setDateAvail(dateString));
    let { targetPackage } = getState().CListingState;
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/add/slots/to/cart?booking_date=${dateString}&counsellor_id=${counsellor_id}&package_id=${targetPackage.id}&slot=${data.time_avail}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/vnd.api+json; et=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setCounsellorAvailability(response.data));
        }
      } catch (e) {
        console.log(e);
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
      }
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

export const emptyCart = (data) => {
  return async (dispatch, getState) => {
    await dispatch(setAlertMessage(""));
    const token = auth.getAccessToken();
    let { counsellor_id } = getState().CListingState;
    let { targetPackage } = getState().CListingState;
    let params={params}
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/delete/slots/from/cart?booking_date=${data.date}&counsellor_id=${counsellor_id}&package_id=${targetPackage.id}&slot=${data.time_avail}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/vnd.api+json; et=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
        } else if (response.success) {
          await dispatch(setCounsellorAvailability(response.data));
        }
      } catch (e) {
        console.log(e);
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
      }
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

//---> exporting multiple functions and actions

export const CheckoutActions = {
  setCheckoutdata,
  setCheckoutErrMessage,
  fetchAvailability,
  setShowPackageMessage,
  setSiteAlertMessage,
  setSelectedSlots,
  setTimeAvail,
  AddSlots,
  setAlertMessage,
  saveSlotstoCart,
  emptyCart,
  setDateAvail,
  setFinalAmount,
  setBookingModal,
  setLastselectedDate
};

//---> defining the initialState for state variables

export const initialState = {
  availableSlots: "",
  checkoutErrMessage: { message: "", color: "" },
  packageMessage: { message: "", color: "" },
  loadingSpinner: false,
  time_avail: [],
  date_avail:null,
  selectedSlots:{},
  amount:0,
  lastSelectedDate:""
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_TOTAL_PACKAGE_AMOUNT]:(state, action)=>{
    return {
      ...state,
      amount: action.payload,
    };
  },
  [SET_DATE_AVAIL_VALUE]:(state,action)=>{
    return {
      ...state,
      date_avail: action.payload,
    };
  },
  [SET_TIME_AVAIL_VALUE]: (state, action) => {
    return {
      ...state,
      time_avail: action.payload,
    };
  },
  [SET_SELECTED_SLOTS_BY_USER]: (state, action) => {
    return {
      ...state,
      selectedSlots: action.payload,
    };
  },
  [SET_SHOW_PACKAGE_MESSAGE]: (state, action) => {
    return {
      ...state,
      packageMessage: action.payload,
    };
  },

  [SET_CHECKOUT_ERR_MESSAGE]: (state, action) => {
    return {
      ...state,
      checkoutErrMessage: action.payload,
    };
  },

  [SET_CHECKOUT_DATA]: (state, action) => {
    return {
      ...state,
      data: action.payload,
    };
  },

  [SET_COUNSELLOR_AVAILABILITY_SLOTS]: (state, action) => {
    return {
      ...state,
      availableSlots: action.payload,
    };
  },

  [SET_LOADING_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      loadingSpinner: action.payload,
    };
  },
  [SET_LAST_SELECTED_DATE_BY_USER]:(state,action)=>{
    return {
      ...state,
      lastSelectedDate: action.payload,
    };
  }
};

export default function CheckoutReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}