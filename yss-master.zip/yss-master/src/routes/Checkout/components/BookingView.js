import React, { Fragment } from "react";
import CheckoutModal from "./CheckoutView";
import Spinner from "../../../components/Spinner/Spinner";
import { Link } from "react-router-dom";
import "react-modern-calendar-datepicker/lib/DatePicker.css";
import { Calendar } from "react-modern-calendar-datepicker";
import { checkSlots } from "../../../helpers/checkSlots";
import { setTimeLable } from "../../../helpers/checkSlots";
import { CheckoutActions, fetchAvailability } from "../modules/Checkout";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";

import _ from "lodash";

let arr = [];
let dates = {};
let selected = 0;

class BookingView extends React.Component {
  constructor(props) {
    super(props);
    let month = new Date().getMonth() + 1;
    let day = new Date().getDate();
    let year = new Date().getFullYear();
    this.state = {
      checkout: false,
      date_avail: { year: year, month: month, day: day },
      disabledDays: [],
    };
    this.submitHandler = this.submitHandler.bind(this);
    this.setCheckoutState = this.setCheckoutState.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleDate = this.handleDate.bind(this);
    this.isSelected = this.isSelected.bind(this);
  }

  setCheckoutState(checkout) {
    this.setState({ checkout: checkout });
  }

  handleChange(e) {
    selected = 0;
    let { selectedSlots, lastSelectedDate } = this.props.CheckoutState;
    let value = e.target.value;
    let { date_avail } = this.state;
    let tempDate;
    if (date_avail === null) {
      tempDate = new Date().toISOString().slice(0, 10);
    } else {
      tempDate =
        date_avail.year + "-" + date_avail.month + "-" + date_avail.day;
    }

    if (Object.keys(selectedSlots).length === 0) {
      selectedSlots[lastSelectedDate] = [];
    }

    if (selectedSlots[tempDate].includes(value)) {
      let index = selectedSlots[tempDate].indexOf(value);
      selectedSlots[tempDate].splice(index, 1);
    } else {
      selectedSlots[tempDate].push(value);
    }

    Object.keys(selectedSlots).map((arr) => {
      selected = selected + selectedSlots[arr].length;
    });

    this.props.setTimeAvail(arr);
    this.props.setSelectedSlots(selectedSlots);
  }

  handleDate(date) {
    let { selectedSlots } = this.props.CheckoutState;
    let { targetPackage } = this.props.ListingState;
    this.setState({
      date_avail: { day: date.day, month: date.month, year: date.year },
    });

    let tempDate = date.year + "-" + date.month + "-" + date.day;
    this.props.setLastselectedDate(tempDate);
    if (!(tempDate in selectedSlots)) {
      selectedSlots[tempDate] = [];
    }
    this.props.setSelectedSlots(selectedSlots);
    this.props.fetchAvailability({
      ...this.state,
      date,
      ...{ targetPackage },
      history: this.props.history,
    });
  }

  isSelected = (time) => {
    let { date_avail } = this.state;
    let { selectedSlots } = this.props.CheckoutState;
    let tempDate;
    if (date_avail === null) {
      tempDate = new Date().toISOString().slice(0, 10);
    } else {
      tempDate =
        date_avail.year + "-" + date_avail.month + "-" + date_avail.day;
    }
    if (tempDate in selectedSlots) {
      if (selectedSlots[tempDate].includes(time)) {
        return true;
      }
    }
  };

  async componentDidMount() {
    let body = document.body;
    body.className = "booking_modal";
    //this.props.setCounsellorId(this.props.match.params.id);
    let { selectedSlots } = this.props.CheckoutState;
    let { targetPackage } = this.props.ListingState;
    this.props.fetchAvailability({
      ...this.state,
      ...{ targetPackage },
      history: this.props.history,
    });

    Object.keys(selectedSlots).map((arr) => {
      selected = selected + selectedSlots[arr].length;
    });

    let month = new Date().getMonth() + 1;
    let day = new Date().getDate();
    let year = new Date().getFullYear();

    this.props.setSelectedSlots(selectedSlots);
    this.props.setLastselectedDate(year + "-" + month + "-" + day);

    // getting the previous days of the current month
    var date = new Date(),
      y = date.getFullYear(),
      m = date.getMonth();
    var firstDay = new Date(y, m, 1);
    let n = date.getDate() - firstDay.getDate();
    for (let i = 1; i <= n; i++) {
      date.setDate(date.getDate() - 1);
      let tempDate = {
        year: date.getFullYear(),
        month: date.getMonth() + 1,
        day: date.getDate(),
      };
      this.state.disabledDays.push(tempDate);
    }
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
    selected = 0;
  }

  submitHandler() {
    let { selectedSlots } = this.props.CheckoutState;
    let { targetPackage } = this.props.ListingState;
    Object.keys(selectedSlots).map((i) => {
      if (selectedSlots[i].length === 0) {
        delete selectedSlots[i];
      }
    });
    if (Object.keys(selectedSlots).length === 0) {
      this.props.setSiteAlertMessage({
        message: "Please select the slot time!",
        color: "teal",
      });
    } else if (selected > 10 && parseInt(targetPackage.no_of_slots) == 1) {
      this.props.setSiteAlertMessage({
        message: "You can select only 10 slots at a time",
        color: "teal",
      });
    } else if (
      selected > parseInt(targetPackage.no_of_slots) &&
      parseInt(targetPackage.no_of_slots) > 1
    ) {
      this.props.setSiteAlertMessage({
        message: "Please select only " + targetPackage.no_of_slots + " slots.",
        color: "teal",
      });
    } else {
      Object.keys(selectedSlots).map((i) => {
        if (selectedSlots[i].length === 0) {
          this.props.setSiteAlertMessage({
            message: "Please select the slot time!",
            color: "teal",
          });
        } else {
          this.props.setBookingModal("checkout");
        }
      });
    }
    this.props.setFinalAmount(selected);
    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
    }, 7000);
  }

  render() {
    const {
      availableSlots,
      loadingSpinner,
      selectedSlots,
    } = this.props.CheckoutState;
    let { date_avail } = this.state;
    let { targetPackage } = this.props.ListingState;
    return (
      <Fragment>
        <div className="modal opacity fixed w-full h-full top-0 left-0 flex items-center justify-center z-10">
          <div className="modal-overlay absolute w-full h-full bg-gray-900 opacity-75" />
          <div className="modal-container bg-white w-11/12 md:w-9/12 mx-auto rounded shadow-lg z-50 overflow-y-auto">
            <div className="modal-content p-6 text-center">
              <div className="flex justify-end pb-3">
                <div
                  className="modal-close cursor-pointer z-50"
                  onClick={this.props.closeEvent}
                >
                  <svg
                    className="fill-current text-black"
                    xmlns="http://www.w3.org/2000/svg"
                    width={18}
                    height={18}
                    viewBox="0 0 18 18"
                  >
                    <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z" />
                  </svg>
                </div>
              </div>
              <div className="modal__body text-center">
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 mt-5">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4">
                      <div className="mt-2"></div>
                      <div className="main-content">
                        <div className="site__content">
                          <div className="page__content">
                            <div className="md:w-11/12 lg:w-10/12 md:flex md:select-none justify-center items-center ">
                              <div className="bg-white p-4 w-full book_appointment_popup">
                                <div className="block__info">
                                  <div className="block_title">
                                    <h3>Selected time slot:</h3>

                                    <div className="selected_time">
                                      {targetPackage.session_hours}
                                      {":"}
                                      {targetPackage.session_minutes}{" "}
                                      {setTimeLable(
                                        targetPackage.session_hours,
                                        targetPackage.session_minutes
                                      )
                                        ? "Minutes"
                                        : "Hours"}
                                      <span>{targetPackage.package_name}</span>
                                    </div>

                                    <div className="selected_time ml-1">
                                      {targetPackage.no_of_slots == "01"
                                        ? " Session"
                                        : " Sessions"}
                                      <span>
                                        {selected}
                                        {" selected"}
                                      </span>
                                    </div>
                                  </div>
                                </div>

                                <div className="block__info mt-10">
                                  <div className="booking_blocks">
                                    {/* -----------------Calender block------------------- */}
                                    <div className="left_block">
                                      <div className="block_title">
                                        <h3>Select a date and time</h3>
                                      </div>
                                      <div className="w-full">
                                        <Calendar
                                          onChange={this.handleDate}
                                          value={this.state.date_avail}
                                          disabledDays={this.state.disabledDays} // here we pass them
                                          onDisabledDayError={
                                            this.handleDisabledSelect
                                          }
                                          shouldHighlightWeekends
                                        />
                                      </div>
                                    </div>
                                    {/* ---------------------Slot-time block--------------------*/}
                                    <div className="right_block">
                                      <div className="block_title">
                                        <h3>
                                          Availability on{" "}
                                          {date_avail.day +
                                            "-" +
                                            date_avail.month +
                                            "-" +
                                            date_avail.year}
                                        </h3>
                                      </div>
                                      <div className="time_availability">
                                        {availableSlots.length === 0 ? (
                                          <p>No slots are available.</p>
                                        ) : null}

                                        {loadingSpinner ? (
                                          <Spinner />
                                        ) : (
                                          <form className="time_availability_form">
                                            {Object.keys(availableSlots).map(
                                              (keyName, i) => (
                                                // checkSlots(date_avail,keyName.split("-")[0]) || checkSlots(date_avail,keyName.split("-")[1])
                                                // ? (
                                                <div
                                                  className="form-item"
                                                  key={i}
                                                >
                                                  {/* <label>{keyName}</label> */}
                                                  <div
                                                    className="form-item-radio-advance"
                                                    onChange={this.handleChange}
                                                  >
                                                    {availableSlots[
                                                      keyName
                                                    ].map((item) =>
                                                      item.slot !== "" &&
                                                      checkSlots(
                                                        date_avail,
                                                        item.slot
                                                      ) ? (
                                                        <span key={item.slot}>
                                                          <input
                                                            id={item.slot.replace(
                                                              " ",
                                                              "-"
                                                            )}
                                                            type="checkbox"
                                                            name="time_avail"
                                                            value={item.slot}
                                                          />
                                                          <label
                                                            className={
                                                              item.enabled === 0
                                                                ? "text-gray-500 pointer-events-none"
                                                                : this.isSelected(
                                                                    item.slot
                                                                  )
                                                                ? "border-blue-800"
                                                                : ""
                                                            }
                                                            htmlFor={item.slot.replace(
                                                              " ",
                                                              "-"
                                                            )}
                                                          >
                                                            {item.slot}
                                                          </label>
                                                        </span>
                                                      ) : null
                                                    )}
                                                  </div>
                                                </div>
                                              )
                                              // ) :'No slots are available'
                                            )}
                                          </form>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="btn text-right float-right">
                                  <Link
                                    to="#"
                                    className="bg_blue text-white"
                                    onClick={() => this.submitHandler()}
                                  >
                                    Proceed For Booking
                                  </Link>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* </div> */}
      </Fragment>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(CheckoutActions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CheckoutState: state.CheckoutState,
  ListingState: state.ListingState,
});

export default connect(mapStateToProps, mapDispatchToProps)(BookingView);
