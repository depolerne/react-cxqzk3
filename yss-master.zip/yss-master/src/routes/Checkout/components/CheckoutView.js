import React, { Fragment } from "react";
import StripeCheckout from "react-stripe-checkout";
import { Link, Redirect } from "react-router-dom";
import auth from "../../../helpers/auth";
import Spinner from "../../../components/Spinner/Spinner";
import { connect } from "react-redux";
import { actions } from "../../selectWrapper/modules/select";
import { ZoneList } from "../../../helpers/ZoneList";
import { CheckoutActions } from "../modules/Checkout";
import { setTimeLable } from "../../../helpers/checkSlots";
import { socket } from "../../../helpers/socketHelper";

class CheckoutView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      checked: "",
      loadingSpinner: false,
      stripeUrl: "",
      redirect_url: "",
      notes: "",
    };
    this.handleToken = this.handleToken.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.checkValidate = this.checkValidate.bind(this);
  }

  handleChange(event) {
    if (event.target.type === "checkbox") {
      this.setState({ checked: event.target.checked });
    } else {
      this.setState({ notes: event.target.value });
    }
  }

  componentWillUnmount() {
    this.props.setFinalAmount(0);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "checkout_page";
  }

  async handleToken(token) {
    let { selectedSlots, amount } = this.props.CheckoutState;
    let { id } = this.props.ListingState.listing_data.user;
    let { targetPackage } = this.props.ListingState;
    let authToken = auth.getAccessToken();
    this.setState({ loadingSpinner: true });
    let data = {
      param: {
        counsellor_id: id,
        package_id: targetPackage.id,
        notes: this.state.notes,
        card_id: token.card.id,
        token: token.id,
        amount: targetPackage.amount * amount,
        selected_slots: selectedSlots,
      },
    };

    let result = await fetch(`${__API__}/make/booking`, {
      method: "POST",
      body: JSON.stringify(data),
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        Accept: "application/json",
        Authorization: `Bearer ` + authToken,
      },
    });
    let response = await result.json();
    if (!response.success) {
      Object.keys(response.errors).map((item) => {
        this.props.setSiteAlertMessage({
          message: response.errors[item][0],
          color: "teal",
        });
      });
      this.setState({
        loadingSpinner: false,
        checked: false,
      });
    } else if (response.success) {
      this.props.setSelectedSlots({});
      this.setState({
        loadingSpinner: false,
        // stripeUrl: response.data.next_action.redirect_to_url.url,
      });
      socket.emit("payment_success", { id: id, success: true });
      await this.props.history.push(`/dashboard/appointments`);
      this.props.setAlertMessage({
        message: "Your booking has been successful!",
        color: "green",
      });
      await this.props.setBookingModal("");
      await this.props.setSelectedSlots({});
    }
    setTimeout(() => {
      this.props.setAlertMessage({
        message: "",
        color: "",
      });
      this.props.setSiteAlertMessage({
        message: "",
        color: "",
      });
    }, 7000);
  }

  checkValidate() {
    this.props.setSiteAlertMessage({
      message: "Please accept the terms and conditions.",
      color: "teal",
    });
    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  render() {
    let { selectedSlots, amount } = this.props.CheckoutState;
    let { userData } = this.props.selectState;
    let { targetPackage, listing_data } = this.props.ListingState;
    return (
      <Fragment>
        <div className="modal opacity fixed w-full h-full top-0 left-0 flex items-center justify-center z-10">
          <div className="modal-overlay absolute w-full h-full bg-gray-900 opacity-75" />
          <div className="modal-container bg-white w-11/12 md:w-8/12 mx-auto rounded shadow-lg z-50 overflow-y-auto">
            <div className="modal-content p-6 text-center">
              <div className="flex justify-end pb-3">
                <div
                  className="modal-close cursor-pointer z-50"
                  onClick={() => {this.props.setBookingModal("");this.props.setSelectedSlots({})}}
                >
                  <svg
                    className="fill-current text-black"
                    xmlns="http://www.w3.org/2000/svg"
                    width={18}
                    height={18}
                    viewBox="0 0 18 18"
                  >
                    <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z" />
                  </svg>
                </div>
              </div>
              <div className="modal__body text-center">
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 mt-5">
                  <div className="sm:flex sm:items-start">
                    <div className="text-center sm:mt-0 sm:ml-4">
                      <div className="mt-2"></div>
                      <div className="login_form--page">
                        <div className="w-full md:flex md:select-none justify-center items-center ">
                          <div className="bg-white p-4 w-full book_appointment_popup checkout_popup">
                            <div className="block__info">
                              {/* <div className="cornor_circle bg-white">
                                <svg
                                  version="1.1"
                                  id="Capa_1"
                                  xmlns="http://www.w3.org/2000/svg"
                                  xmlnsXlink="http://www.w3.org/1999/xlink"
                                  x="0px"
                                  y="0px"
                                  viewBox="0 0 52 52"
                                  style={{
                                    enableBackground: "new 0 0 52 52",
                                  }}
                                  xmlSpace="preserve"
                                  fill="#30ce20"
                                >
                                  <g>
                                    <path d="M26,0C11.664,0,0,11.663,0,26s11.664,26,26,26s26-11.663,26-26S40.336,0,26,0z M40.495,17.329l-16,18 C24.101,35.772,23.552,36,22.999,36c-0.439,0-0.88-0.144-1.249-0.438l-10-8c-0.862-0.689-1.002-1.948-0.312-2.811 c0.689-0.863,1.949-1.003,2.811-0.313l8.517,6.813l14.739-16.581c0.732-0.826,1.998-0.9,2.823-0.166 C41.154,15.239,41.229,16.503,40.495,17.329z" />
                                  </g>
                                </svg>
                              </div> */}
                              <form className="checkout_details">
                                <div className="personal_details">
                                  <div className="block_title">
                                    <h3>Personal Details</h3>
                                  </div>
                                  <div className="checkout_fields">
                                    <div className="form-item">
                                      <input
                                        type="text"
                                        defaultValue={userData.name}
                                        placeholder="First Name"
                                        disabled
                                      />
                                    </div>
                                    <div className="form-item">
                                      <input
                                        type="email"
                                        defaultValue={userData.email}
                                        placeholder="abcd@gmail.com"
                                        disabled
                                      />
                                    </div>
                                    <div className="form-item">
                                      <input
                                        type="number"
                                        defaultValue={userData.phone}
                                        placeholder="Contact Number"
                                      />
                                    </div>
                                    <div className="form-item">
                                      <textarea
                                        placeholder="Add Notes"
                                        name="notes"
                                        onChange={this.handleChange}
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div className="personal_details">
                                  <div className="block_title">
                                    <h3>Booking Details</h3>
                                  </div>
                                  <div className="booking_details">
                                    <p className="itmes-center">
                                      <span>Coach Name :</span>
                                      <span>{listing_data.user.name}</span>
                                    </p>
                                    <span className="booking-date--time">
                                    <p>
                                      <span>Date and time :</span>
                                    </p>
                                    <span>
                                    {Object.keys(selectedSlots).map(
                                      (date, i) => (
                                        <p key={i}>
                                          <span>
                                            {date}
                                            {"  :  "}
                                          </span>
                                          <span>
                                          {selectedSlots[date].map(
                                            (j) =>
                                              j.toLowerCase() +
                                              (selectedSlots[date].indexOf(j) ==
                                              selectedSlots[date].length - 1
                                                ? " "
                                                : " ,  ")
                                          )}</span>
                                        </p>
                                      )
                                    )}
                                    <Link
                                      className="ml-3 text_nav_blue"
                                      to="#"
                                      onClick={() =>
                                        this.props.setBookingModal("booking")
                                      }
                                    >
                                      Change
                                    </Link>
                                    </span>
                                    </span>
                                    <p className="itmes-center">
                                      <span>Session Details :</span>
                                      <span>{targetPackage.session_hours}
                                      {":"}
                                      {targetPackage.session_minutes}{" "}
                                      {setTimeLable(
                                        targetPackage.session_hours,
                                        targetPackage.session_minutes
                                      )
                                        ? "Minutes"
                                        : "Hours"}</span>
                                    </p>
                                    <p>
                                      <span>Total Price :</span>
                                      <span>{"£"}
                                      {targetPackage.no_of_slots > 1
                                        ? targetPackage.amount
                                        : targetPackage.amount * amount}</span>
                                    </p>
                                    <div className="terms_field">
                                      <label>
                                        <input
                                          type="checkbox"
                                          onChange={this.handleChange}
                                        />{" "}
                                        I accept all <Link to="/terms-and-conditions" target="_blank">Terms and Conditions</Link>{" "}
                                        and <Link to="/privacy-policy" target="_blank">Privacy Policy.</Link>
                                      </label>
                                    </div>
                                    <div className="btn">
                                      {this.state.checked ? (
                                        <StripeCheckout
                                          stripeKey={__STRIPE_CLIENT_ID__}
                                          token={this.handleToken}
                                          name="Soberlistic"
                                          image="/images/yss_new_logo4x.svg"
                                        >
                                          <Link
                                            to="#"
                                            className="bg_blue text-white"
                                          >
                                            Proceed For Booking
                                          </Link>
                                        </StripeCheckout>
                                      ) : (
                                        <Link
                                          to="#"
                                          className="bg_blue text-white"
                                          onClick={this.checkValidate}
                                        >
                                          Proceed For Booking
                                        </Link>
                                      )}
                                    </div>
                                    <div className="card_option">
                                      <img src="images/cards_img.png" />
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* </div> */}
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CProfileState: state.CProfileState,
  CheckoutState: state.CheckoutState,
  ListingState: state.ListingState,
});

export default connect(mapStateToProps, CheckoutActions)(CheckoutView);
