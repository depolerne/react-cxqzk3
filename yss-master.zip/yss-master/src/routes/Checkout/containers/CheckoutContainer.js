import React from "react";

import BookingView from "../components/BookingView";
import { CheckoutActions ,fetchAvailability} from "../modules/Checkout";
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(CheckoutActions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CheckoutState: state.CheckoutState,
  ListingState: state.ListingState,
});

const withJobComponent = withJob({
  work: async ({ dispatch,CListingState:{targetPackage}, }) => {
    // dispatch(fetchAvailability(targetPackage));
  },
  /* eslint-disable */ ErrorComponent: ({ error }) =>
    __DEV__ ? <RedBox error={error} /> : null,
})(BookingView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
