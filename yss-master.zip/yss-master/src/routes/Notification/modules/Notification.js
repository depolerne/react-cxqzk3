import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import moment from "moment";
import { setAlertMessage } from "../../selectWrapper/modules/select";

export const SET_NOTIFICATION_DATA = "SET_NOTIFICATION_DATA";
export const SET_ERR_GET_NOTIFICATION_MESSAGE =
  "SET_ERR_GET_NOTIFICATION_MESSAGE";

export const SET_NOTIFICATION_LENGTH_ICON = "SET_NOTIFICATION_LENGTH_ICON";
export const SET_NOTIFICATION_LOADING_SPINNER_STATUS =
  "SET_NOTIFICATION_LOADING_SPINNER_STATUS";

export const SET_NOTIFICATION_READ_COUNT_STATUS =
  "SET_NOTIFICATION_READ_COUNT_STATUS";
export const SET_DELETE_NOTIFICATION__SPINNER_STATUS =
  "SET_DELETE_NOTIFICATION__SPINNER_STATUS";

export const setErrGetNotificationMessage = () => {
  return {
    type: SET_ERR_GET_NOTIFICATION_MESSAGE,
  };
};

export const setNotificationsData = (data) => {
  return {
    type: SET_NOTIFICATION_DATA,
    payload: data,
  };
};

export const setNotificationBadge = (flag) => {
  return {
    type: SET_NOTIFICATION_LENGTH_ICON,
    payload: flag,
  };
};

export const setLoadingSpinner = (flag) => {
  return {
    type: SET_NOTIFICATION_LOADING_SPINNER_STATUS,
    payload: flag,
  };
};

export const setReadCount = (num) => {
  return {
    type: SET_NOTIFICATION_READ_COUNT_STATUS,
    payload: num,
  };
};

export const setdeleteLoadingSpinner = (flag) => {
  return {
    type: SET_DELETE_NOTIFICATION__SPINNER_STATUS,
    payload: flag,
  };
};

export function fetchNotification(page, type) {
  return async (dispatch, getState) => {
    const token = auth.getAccessToken();
    const {authModal}=getState().ListingState;
    let count = 0;
    await dispatch(setLoadingSpinner(true));
    if (token && authModal=='') {
      try {
        let result = await fetch(
          `${__API__}/get/all/notification?page=${page}&type=${type}`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/vnd.api+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map(item=>{
            dispatch(setAlertMessage({message: response.errors[item][0],color: "teal"}))
          })
          await dispatch(setLoadingSpinner(false));
        } else if (response.success) {
          await dispatch(setNotificationsData(response.data));
          await dispatch(setLoadingSpinner(false));
          response.data.data.map((item) => {
            if (item.is_read == 0) {
              count++;
            }
          });
          await dispatch(setReadCount(count));
        }
      } catch (e) {
        await dispatch(setAlertMessage("Server error Please try again."));
        await dispatch(setLoadingSpinner(false));
      }
    }
  };
}

export function deleteNotification(id) {
  return async (dispatch, getState) => {
    const token = auth.getAccessToken();
    let count = 0;
    await dispatch(setdeleteLoadingSpinner(true));
    if (token) {
      try {
        let result = await fetch(
          `${__API__}/delete/notification?notification_id=${id}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/vnd.api+json; charset=utf-8",
              Accept: "application/json",
              Authorization: `Bearer ` + token,
            },
          }
        );
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setdeleteLoadingSpinner(false));
        } else if (response.success) {
          await dispatch(setNotificationsData(response.data));
          await dispatch(setdeleteLoadingSpinner(false));
          await dispatch(setReadCount(count));
          await dispatch(
            setAlertMessage({
              message: "Notification removed successfully!",
              color: "green",
            })
          );
        }
      } catch (e) {
        await dispatch(setAlertMessage("Server error Please try again."));
        await dispatch(setdeleteLoadingSpinner(false));
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error please refresh the page.",
          color: "teal",
        })
      );
      await dispatch(setdeleteLoadingSpinner(false));
    }
    setTimeout(async () => {
      await dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export const actions = {
  setNotificationsData,
  fetchNotification,
  setAlertMessage,
  deleteNotification,
  setdeleteLoadingSpinner,
};

const initialState = {
  notifications: {
    data: [],
    last_page: 0,
    currentPage: 1,
    totalPage: [],
  },
  read_count: 0,
  noti_spinner: false,
  delete_spinner: false,
};

const ACTION_HANDLERS = {
  [SET_NOTIFICATION_READ_COUNT_STATUS]: (state, action) => {
    return {
      ...state,
      read_count: action.payload,
    };
  },
  [SET_NOTIFICATION_LOADING_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      noti_spinner: action.payload,
    };
  },
  [SET_NOTIFICATION_DATA]: (state, action) => {
    return {
      ...state,
      notifications: {
        data: action.payload.data,
        last_page: action.payload.last_page,
        totalPage: [...Array(action.payload.last_page).keys()],
        currentPage: action.payload.current_page,
      },
    };
  },
  [SET_DELETE_NOTIFICATION__SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      delete_spinner: action.payload,
    };
  },
};

export default function NotificationReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
