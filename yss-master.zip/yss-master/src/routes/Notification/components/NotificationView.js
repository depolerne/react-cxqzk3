import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import { socket } from "../../../helpers/socketHelper";
import Spinner from "../../../components/Spinner/Spinner";
import SpinnerBlue from "../../../components/SpinnerBlue/SpinnerBlue";

export class NotificationView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      wList: [],
      Id: null,
    };
    this.prevPage = this.prevPage.bind(this);
    this.nextPage = this.nextPage.bind(this);
    this.changePage = this.changePage.bind(this);
    this.setPageClass = this.setPageClass.bind(this);
    this.handleDelete = this.handleDelete.bind(this);
  }

  componentDidMount() {

    let body=document.body;
    body.className="notifications";
    socket.on("Payment_notification", (data) => {});
  }

  async prevPage(e) {
    let { currentPage } = this.props.NotificationState.notifications;
    let num = (await parseInt(currentPage)) - 1;
    if (currentPage > 1) {
      currentPage = num;
      this.props.fetchNotification(currentPage, 1);
    }
  }

  async nextPage() {
    let { currentPage } = this.props.NotificationState.notifications;
    let num = (await parseInt(currentPage)) + 1;
    this.props.fetchNotification(num, 1);
  }

  async changePage(e) {
    let { currentPage } = this.props.NotificationState.notifications;
    let value = await e.target.name;
    currentPage = value;
    this.props.fetchNotification(currentPage, 1);
  }

  setPageClass(value) {
    let { currentPage } = this.props.NotificationState.notifications;
    if (value === currentPage) {
      return true;
    } else {
      return false;
    }
  }

  handleDelete(id) {
    this.setState({ Id: id });
    this.props.deleteNotification(id);
  }

  render() {
    let {
      data,
      last_page,
      currentPage,
      totalPage,
    } = this.props.NotificationState.notifications;
    let { noti_spinner, delete_spinner } = this.props.NotificationState;
    let { Id } = this.state;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            <div className="page__content">
              <div className="form__heading">
                <h3>
                  Your <span>Alerts</span>
                </h3>
              </div>
              {noti_spinner ? (
                <Spinner text={"fetching notifications..."} />
              ) : (
                <div className="middle__content">
                  {data.length == 0 ? (
                    "You don't have any new notification."
                  ) : (
                    <ul className="o-lists">
                      {data.map((item, i) => (
                        <li key={i} className="list-item">
                          {delete_spinner && item.id === Id ? (
                            <SpinnerBlue />
                          ) : (
                            <Link
                              to="#"
                              className="close_btn"
                              onClick={() => this.handleDelete(item.id)}
                            ></Link>
                          )}
                          <Link to="#" className="list_btn pointer-events-none">
                            {item.title}
                          </Link>
                          <div className="list_detail">
                            <div className="list_content">
                              <p dangerouslySetInnerHTML={{__html: item.body}}></p>
                              {/*<p>
                          <span>{'item.name'}</span> is waiting in Queue.
                        </p>*/}
                            </div>
                            <div className="list_highlight">
                              <p>{item.created_at}</p>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                  {data.length == 0 || last_page == 1 ? null : (
                    <div className="site_pagination">
                      <ul>
                        <li className={currentPage > 1 ? "prev" : "disable"}>
                          <Link to="#" onClick={this.prevPage}>
                            &lt; Prev{" "}
                          </Link>
                        </li>
                        {totalPage.map((number, i) => {
                          return (
                            <li className="prev" key={i}>
                              <Link
                                to="#"
                                className={
                                  this.setPageClass(number + 1)
                                    ? "bg-blue-900 text-white"
                                    : ""
                                }
                                name={number + 1}
                                onClick={this.changePage}
                              >
                                {number + 1}
                              </Link>
                            </li>
                          );
                        })}
                        <li
                          className={currentPage < last_page ? "next" : "disable"}
                        >
                          <Link to="#" onClick={this.nextPage}>
                            Next &gt;{" "}
                          </Link>
                        </li>
                      </ul>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default NotificationView;
