import React from "react";
import { actions } from "../modules/Notification";
import { bindActionCreators } from "redux";
import NotificationView from "../components/NotificationView";
import { connect } from "react-redux";
import { withJob } from "react-jobs";
import RedBox from "redbox-react";

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
    NotificationState: state.NotificationState,
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => {
        //dispatch(getUser());
    },
    ErrorComponent: ({ error }) => (__DEV__ ? <RedBox error={error} /> : null),
})(NotificationView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);
