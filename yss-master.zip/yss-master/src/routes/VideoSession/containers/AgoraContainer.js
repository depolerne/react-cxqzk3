import { actions } from "../modules/VideoSession";
import { withJob } from "react-jobs";
import { bindActionCreators } from "redux";
import Meeting from "../Components/Meeting";
import { connect } from "react-redux";

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),  
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  AgoraState: state.AgoraState,
  UserAppointmentState: state.UserAppointmentState,
  CDashboardState: state.CDashboardState
});

export default connect(mapStateToProps, mapDispatchToProps)(Meeting);
