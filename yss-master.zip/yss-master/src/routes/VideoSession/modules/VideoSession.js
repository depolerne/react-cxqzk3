//import { setAuthModal } from "../../CListing/modules/CListing";
import { setAlertMessage } from "../../selectWrapper/modules/select";
import { saveCallHistory } from "../../selectWrapper/modules/select";

//---> Defining types for different actions

export const SET_CALL_LOGS_DATA = "SET_CALL_LOGS_DATA";
export const SET_CURRENT_SESSION_DATA = "SET_CURRENT_SESSION_DATA";

//---> Defining Actions to set state variables

export function setCallStatus(params) {
  return {
    type: SET_CALL_LOGS_DATA,
    payload: params,
  };
}

export function setCurrentSession(params) {
  return {
    type: SET_CURRENT_SESSION_DATA,
    payload: params,
  };
}

export const actions = {
  saveCallHistory,
  setCallStatus,
  setAlertMessage,
  setCurrentSession,
};

//---> defining the initialState for state variables

const initialState = {
  callStatus: "",
  currentSession: {},
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_CALL_LOGS_DATA]: (state, action) => {
    return {
      ...state,
      callStatus: action.payload,
    };
  },
  [SET_CURRENT_SESSION_DATA]: (state, action) => {
    return {
      ...state,
      currentSession: action.payload,
    };
  },
};

export default function VideoReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];

  return handler ? handler(state, action) : state;
}
