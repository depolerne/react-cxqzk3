import React from 'react';
import {
    actions,fetchBooking
} from '../modules/CDashboard';
import { bindActionCreators } from 'redux';
import CDashboardView from '../components/CDashboardView';
import { connect } from 'react-redux';
import { withJob } from 'react-jobs';
import RedBox from 'redbox-react';

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});

const mapStateToProps = (state) => ({
    selectState:state.selectState,
    CDashboardState: state.CDashboardState,
    auth:state.auth
});

const withJobComponent = withJob({
    work: async ({ dispatch }) => {
        dispatch(fetchBooking())
    },
    /* eslint-disable */ ErrorComponent: ({ error }) => __DEV__ ? <RedBox error={error} /> : null,
})(CDashboardView);

export default connect(mapStateToProps, mapDispatchToProps)(withJobComponent);