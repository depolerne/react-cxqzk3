import auth from "../../../helpers/auth";
import fetch from "isomorphic-fetch";
import {
  setAlertMessage,
  loadWaitingList,
  setWaitingList,
  Accept
} from "../../selectWrapper/modules/select";

//---> Defining types for different actions.
export const SET_TODAY_APPOINTMENTS_DATA = "SET_APPOINTMENTS_DATA";
export const SET_UPCOMING_APPOINTMENT_DATA = "SET_UPCOMING_APPOINTMENT_DATA";
export const C_DASH_SPINNER_STATUS = "C_DASH_SPINNER_STATUS";
export const SET_ALL_BOOKINGS_DATA = "SET_ALL_BOOKINGS_DATA";

//---> Defining Actions to set state variables
export const setCDashSpinner = (data) => {
  return {
    type: C_DASH_SPINNER_STATUS,
    payload: data,
  };
};

export const setTodayAppointments = (appointments) => {
  return {
    type: SET_TODAY_APPOINTMENTS_DATA,
    payload: appointments,
  };
};

export const setUpcomingAppointments = (upcomingData) => {
  return {
    type: SET_UPCOMING_APPOINTMENT_DATA,
    payload: upcomingData,
  };
};

export const setAllBookings = (allBookings) => {
  return {
    type: SET_ALL_BOOKINGS_DATA,
    payload: allBookings,
  };
};

//--->fetching all the bookings tojoinSession show in the dashboard

export const fetchBooking = () => {
  return async (dispatch) => {
    await dispatch(setCDashSpinner(true));
    const token = auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/drupal.single+json; charset=utf-8",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          await dispatch(setCDashSpinner(false));
        } else if (response.success) {
          await dispatch(setTodayAppointments(response.todays.data));
          await dispatch(setUpcomingAppointments(response.upcoming.data));
          await dispatch(setCDashSpinner(false));
        }
      } catch (e) {
        await dispatch(
          setAlertMessage({
            message: "Server error Please try again.",
            color: "teal",
          })
        );
        await dispatch(setCDashSpinner(false));
        console.log(e);
      }
    } else {
      await dispatch(
        setAlertMessage({
          message: "Server error Please try again.",
          color: "teal",
        })
      );
      await dispatch(setCDashSpinner(false));
    }
    setTimeout(() => {
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
};

//---> exporting multiple functions and actions

export const actions = {
  loadWaitingList,
  setAlertMessage,
  fetchBooking,
  setAllBookings,
  setWaitingList,
  Accept
};

//---> defining the initialState for state variables

const initialState = {
  spinnerStatus: false,
  upcomingAppointments: {},
  todaysAppointments: {},
  allBookings: []
};

//--->  setting the values to the state variables by actions dispatched

const ACTION_HANDLERS = {
  [SET_ALL_BOOKINGS_DATA]: (state, action) => {
    return {
      ...state,
      allBookings: action.payload,
    };
  },
  [SET_TODAY_APPOINTMENTS_DATA]: (state, action) => {
    return {
      ...state,
      todaysAppointments: action.payload,
    };
  },
  [SET_UPCOMING_APPOINTMENT_DATA]: (state, action) => {
    return {
      ...state,
      upcomingAppointments: action.payload,
    };
  },
  
  [C_DASH_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      spinnerStatus: action.payload,
    };
  },
};

export default function CDashboardReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
