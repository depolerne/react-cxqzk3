import CDashboard from './containers/CDashboardContainer';
export { CDashboard };
export * from './modules/CDashboard';

export default CDashboard;
