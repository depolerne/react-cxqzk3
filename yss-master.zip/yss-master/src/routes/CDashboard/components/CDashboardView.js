import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import BookingTab from "../../../components/BookingTab/BookingTab";
import InsightBlock from "../../../components/InsightBlock/InsightBlock";
import WaitingBlock from "../../../components/WaitingBlock/WaitingBlock";
import Spinner from "../../../components/Spinner/Spinner";
import auth from "../../../helpers/auth";
import moment from "moment";
import { Calendar, momentLocalizer } from "react-big-calendar";
import "react-big-calendar/lib/css/react-big-calendar.css";
import { socket } from "../../../helpers/socketHelper";

var localizer = momentLocalizer(moment);
var values = [];

export class CDashboardView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      loadingSpinner: false,
      bookings: "",
      events: [],
      endpoint: "",
      wList: [],
      play: false,
    };
    this.loadBookings = this.loadBookings.bind(this);
    this.getMediaAccess = this.getMediaAccess.bind(this);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "dashboard";
    this.props.loadWaitingList();
    this.loadBookings();
  }

  getMediaAccess() {
    navigator.getUserMedia({ audio: true, video: true }, (stream) => {
      if (
        stream.getVideoTracks().length > 0 &&
        stream.getAudioTracks().length > 0
      ) {
        alert("No access to camera");
      }
    });
  }

  componentWillUnmount() {
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  async loadBookings() {
    this.setState({ loadingSpinner: true });
    const token = await auth.getAccessToken();
    if (token) {
      try {
        let result = await fetch(`${__API__}/get/all/bookings`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json",
            Authorization: `Bearer ` + token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          this.setState({ loadingSpinner: false });
        } else if (response.success) {
          await this.setState({
            bookings: response.bookings,
            loadingSpinner: false,
          });
        }
      } catch (e) {
        console.log(e);
      }
    }

    //---> modifying the response to set in this.state.events in array format
    let { bookings } = this.state;
    for (let i = 0; i < bookings.length; i++) {
      let temp = {};
      let duration =
        +bookings[i].package.session_hours * 60 +
        +bookings[i].package.session_minutes;
      let bookingDate = bookings[i].booking_date.split("-"); // removing dashes from the date
      let startvalue = new Date(
        bookingDate[0] +
          " " +
          bookingDate[1] +
          " " +
          bookingDate[2] +
          "," +
          bookings[i].slot
      );
      let endvalue = new Date(startvalue.getTime() + duration * 60000);
      temp = Object.assign(
        temp,
        { start: startvalue },
        { end: endvalue },
        { title: `${bookings[i].user.name}` }
      );
      if (
        values.length !== bookings.length &&
        values.length <= bookings.length
      ) {
        values.push(temp);
      }
    }
    this.setState({ events: values });
    this.props.setAllBookings(this.state.events);
  }

  render() {
    let { todaysAppointments, spinnerStatus } = this.props.CDashboardState;
    todaysAppointments = Array.from(todaysAppointments);
    let { waitingList } = this.props.selectState;
    return (
      <Fragment>
        <div className="main-content">
          <div className="site__content">
            <div className="w-full mb-6 xl:mb-0 md:w-full xl:w-1/4">
              <div className="information_block">
                <div className="page_title">
                  {/* <audio id="myAudio" autoPlay={true}>
                    <source src="audio/skype-23266.mp3" type="audio/mpeg"/>
                  </audio> */}
                  <h1>
                    <span className="text_nav_blue">Dashboard</span>
                  </h1>
                </div>

                <div className="enquiry_details clearfix">
                  <h2>Waiting List</h2>
                  <h2>
                    In queue{" "}
                    <span className="text_nav_blue">{waitingList.length}</span>
                  </h2>
                </div>
                {/* ----------------------- Waiting Lists ------------------------------*/}
                {waitingList.map((item, i) => (
                  <WaitingBlock
                    key={i}
                    userName={item.username}
                    AcceptEvent={() => this.props.Accept(item)}
                  />
                ))}
                <div className="enquiry_details appointments_details clearfix">
                  <h2>Today's Appointments</h2>
                </div>
                {/* -------------------------Today's Appointments------------------- */}
                {spinnerStatus ? (
                  <Spinner />
                ) : todaysAppointments.length === 0 ? (
                  "No Appointments for today"
                ) : (
                  todaysAppointments.map((item, i) => (
                    <BookingTab
                      key={i}
                      user_name={item.user.name}
                      slot_time={item.slot}
                    />
                  ))
                )}
                {todaysAppointments.length === 0 ? (
                  <div className="btn btn-blue">
                    <Link to="/coach/dashboard/appointments">
                      Manage All
                    </Link>
                  </div>
                ) : null}
              </div>
            </div>
            {/* ------------------------------Canlender Component------------------------- */}
            <div className="w-full mt-6 xl:pl-6 md:w-full xl:w-3/4 sm:mt-0">
              <div className="w-full">
                {this.state.loadingSpinner ? (
                  <Spinner />
                ) : (
                  <Calendar
                    localizer={localizer}
                    defaultDate={new Date()}
                    defaultView="month"
                    events={this.state.events}
                    style={{ height: "100vh" }}
                    tooltipAccessor={"Ibyte infomatics"}
                    views={["month", "day", "week"]}
                  />
                )}
                {/* -------------------------Insights-Block----------------------- */}
                {/* <div className="static__blocks bg-white px-6 py-3 md:p-6 mt-6 clearfix">
                  <InsightBlock
                    heading={"Total"}
                    text={"Appointments"}
                    insightData={this.state.events.length}
                    clickURL={"/coach/dashboard/appointments"}
                  />
                  <InsightBlock
                    heading={"Upcoming"}
                    text={"Appointments"}
                    insightData={upcomingAppointments.length}
                  />
                  <InsightBlock
                    heading={"Total"}
                    text={"Revenue"}
                    insightData={["£", revenue && revenue]}
                  />
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default CDashboardView;
