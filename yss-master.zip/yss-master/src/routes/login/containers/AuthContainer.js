import { connect } from 'react-redux';
import { actions } from '../modules/auth';
import { bindActionCreators } from 'redux';
import AuthView from '../components/AuthView';
import {setAlertMessage} from '../../selectWrapper/modules/select'

const mapDispatchToProps = (dispatch) => ({
    dispatch,
    ...bindActionCreators(actions, dispatch)
});

const mapStateToProps = (state) => ({
    auth: state.auth,
    Signup: state.Signup,
    ListingState: state.ListingState,
});

export default connect(mapStateToProps, mapDispatchToProps)(AuthView);