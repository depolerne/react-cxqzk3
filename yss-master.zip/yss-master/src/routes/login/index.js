import Auth from './containers/AuthContainer';
export { Auth };
export * from './modules/auth';

export default Auth;
