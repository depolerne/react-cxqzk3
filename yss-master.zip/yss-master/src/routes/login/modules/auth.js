import fetch from "isomorphic-fetch";
import auth from "../../../helpers/auth";
import {
  getUserData,
  setAlertMessage,
} from "../../selectWrapper/modules/select";
import {checkCounsellorAvail, setAuthModal,checkReviewStatus } from "../../Listing/modules/Listing";
import { setSignUpData } from "../../Signup/modules/Signup";
import { setSiteAlertMessage } from "../../SiteWrapper/modules/site";
import { socket } from "../../../helpers/socketHelper";


export const LOGIN_P_SET_ERR_LOGIN_MESSAGE = "LOGIN_P_SET_ERR_LOGIN_MESSAGE";
export const LOGIN_P_SET_LOGIN_SPINNER_STATUS =
  "LOGIN_P_SET_LOGIN_SPINNER_STATUS";
export const SET_FORGOT_PASSWORD_ERR = "SET_FORGOT_PASSWORD_ERR";
export const SET_USER_DATA_IN_STATE = "SET_USER_DATA_IN_STATE";
export const SET_FORGOT_PASSWORD_KEY = "SET_FORGOT_PASSWORD_KEY";
export const SET_FORGOT_PASSWORD_MODAL = "SET_FORGOT_PASSWORD_MODAL";
export const SET_USER_UNVERIFIED_EMAIL = "SET_USER_UNVERIFIED_EMAIL";
export const SET_LOGIN_USER_PAGE = "SET_LOGIN_USER_PAGE";
export const SET_USER_LOGIN_FIELDS_DATA = "SET_USER_LOGIN_FIELDS_DATA";
export const SET_USER_LOGIN_MODE = "SET_USER_LOGIN_MODE";
export const SET_LOGIN_OTP_ERROR_MESSAGE = "SET_LOGIN_OTP_ERROR_MESSAGE";
export const SET_AUTH_OTP_VALUE = "SET_AUTH_OTP_VALUE";

export const setLoginMode = (user) => {
  return {
    type: SET_USER_LOGIN_MODE,
    payload: user,
  };
};

export const setLoginUserPage = (value) => {
  return {
    type: SET_LOGIN_USER_PAGE,
    payload: value,
  };
};

export const setErrLoginMessage = (value) => {
  return {
    type: LOGIN_P_SET_ERR_LOGIN_MESSAGE,
    payload: value,
  };
};

export const setLoginSpinnerStatus = (value) => {
  return {
    type: LOGIN_P_SET_LOGIN_SPINNER_STATUS,
    payload: value,
  };
};

export const setUserDataInState = (data) => {
  return {
    type: SET_USER_DATA_IN_STATE,
    payload: data,
  };
};

export const setForgotPasswordModal = (flag) => {
  return {
    type: SET_FORGOT_PASSWORD_MODAL,
    payload: flag,
  };
};

export const setUserEmail = (email) => {
  return {
    type: SET_USER_UNVERIFIED_EMAIL,
    payload: email,
  };
};

export const setLoginData = (data) => {
  return {
    type: SET_USER_LOGIN_FIELDS_DATA,
    payload: data,
  };
};

export const setOTPErrorMessage = (err) => {
  return {
    type: SET_LOGIN_OTP_ERROR_MESSAGE,
    payload: err,
  };
};

export const setAuthOTPValue = (value) => {
  return {
    type: SET_AUTH_OTP_VALUE,
    payload: value,
  };
};

export function logIn(data) {
  return async (dispatch, getState) => {
    // await dispatch(setErrLoginMessage({ message: "", color: "" }));
    await dispatch(setLoginSpinnerStatus(true));
    await dispatch(setUserEmail(data.username));
    const token = `Basic ${btoa(`${data.username}:${data.password}`)}`;
    if (navigator.onLine) {
      try {
        const result = await fetch(`${__API__}/login`, {
          method: "POST",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
            Authorization: token,
          },
        });
        let response = await result.json();
        if (!response.success) {
          Object.keys(response.errors).map((item) => {
            dispatch(
              setAlertMessage({
                message: response.errors[item][0],
                color: "teal",
              })
            );
          });
          if (response.user == 3) {
            await dispatch(
              setErrLoginMessage({
                message:
                  "Your account is not verified please enter the OTP to verify it",
                color: "teal",
              })
            );
            await dispatch(setAuthModal("OTP"));
            await dispatch(setLoginSpinnerStatus(false));
          } else if (response.user === "0") {
            await dispatch(setLoginSpinnerStatus(false));
          } else {
            await dispatch(setLoginSpinnerStatus(false));
            Object.keys(response.errors).map((item) => {
              dispatch(
                setErrLoginMessage({
                  message: response.errors[item][0],
                  color: "teal",
                })
              );
            });
          }
        } else if (response.success) {
          await dispatch(setLoginSpinnerStatus(false));
          await dispatch(setUserDataInState(response.user));
          await auth.setTokens(response.token, response.user.roles.role,response.user.id);
          await socket.emit("subscribe", response.user.id);
          if (getState().ListingState.authModal === "login") {
            await dispatch(checkCounsellorAvail(response.user.id,response.token))
            await dispatch(setAuthModal(""));
            await dispatch(getUserData());
            await dispatch(
              setSiteAlertMessage({
                message: "Logged in successfully",
                color: "green",
              })
            );

            await dispatch(
              setAlertMessage({
                message: "Logged in successfully",
                color: "green",
              })
            );
            await dispatch(checkReviewStatus())
          } else {
            if (response.user.roles.role === "counsellor") {
              data.history.push("/coach/dashboard");
            } else {
              data.history.push("/dashboard");
            }
            await dispatch(
              setAlertMessage({
                message: "Logged in successfully",
                color: "green",
              })
            );
          }
        }
      } catch (e) {
        await dispatch(setLoginSpinnerStatus(false));
        await dispatch(
          setErrLoginMessage({
            message: "There is an error. Please try again.",
            color: "teal",
          })
        );
        console.log(e);
      }
    } else {
      await dispatch(
        setErrLoginMessage({
          message: "Please check your internet connection.",
          color: "teal",
        })
      );
    }
    setTimeout(() => {
      dispatch(setErrLoginMessage({ message: "", color: "" }));
      dispatch(setAlertMessage({ message: "", color: "" }));
      dispatch(setSiteAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export function verifyEmail(data) {
  return async (dispatch, getState) => {
    await dispatch(setOTPErrorMessage(""));
    await dispatch(setLoginSpinnerStatus(true));
    let userEmail = getState().auth.userEmail;
    try {
      const result = await fetch(
        `${__API__}/verify/register/account?email=${userEmail}&otp=${data.otp}`,
        {
          method: "POST",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        await dispatch(setAuthOTPValue(""));
        await dispatch(setLoginSpinnerStatus(false));
        Object.keys(response.errors).map((item) => {
          dispatch(setOTPErrorMessage(response.errors[item][0]));
        });
      } else if (response.success) {
        await dispatch(setUserDataInState(response.user));
        await auth.setTokens(response.token, response.user.roles.role);
        await socket.emit('subscribe',response.user.id)
        await dispatch(setLoginSpinnerStatus(false));
        await dispatch(getUserData());
        await dispatch(
          setSignUpData({
            name: "",
            email: "",
            password: "",
            c_password: "",
          })
        );

        if (getState().ListingState.authModal === "OTP") {
          await dispatch(checkCounsellorAvail(response.user.id,response.token))
          await dispatch(setAuthModal(""));
          if (location.href.split("/")[4] === "login") {
            await dispatch(
              setAlertMessage({
                message: "Logged In successfully!",
                color: "green",
              })
            );
            await data.history.push("/dashboard");
          } else if (location.href.split("/")[4] === "signup") {
            await data.history.push("/dashboard");
            await dispatch(
              setAlertMessage({
                message: "Account created successfully!",
                color: "green",
              })
            );
          } else if (location.href.split("/")[4] === "listing") {
            await dispatch(setSiteAlertMessage({
              message: "Account created successfully!",
              color: "green",
            }));
          }else {
            await dispatch(setSiteAlertMessage({
              message: "Logged In successfully!",
              color: "green",
            }));
          }
        }
      }
    } catch (e) {
      await dispatch(setLoginSpinnerStatus(false));
      await dispatch(
        setErrLoginMessage({
          message: "There is an error. Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    setTimeout(() => {
      dispatch(setErrLoginMessage({ message: "", color: "" }));
      dispatch(setAlertMessage({ message: "", color: "" }));
      dispatch(setSiteAlertMessage({ message: "", color: "" }))
    }, 5000);
  };
}

export function BridgeLogin(data) {
  return async (dispatch, getState) => {
    try {
      const result = await fetch(
        `${__API__}/login/with/email?email=${data.data.email_id}&user_id=${data.data.id}`,
        {
          method: "POST",
          cache: "no-cache",
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            Accept: "application/json",
          },
        }
      );
      let response = await result.json();
      if (!response.success) {
        Object.keys(response.errors).map((item) => {
          dispatch(
            setErrLoginMessage({
              message: response.errors[item][0],
              color: "teal",
            })
          );
        });
      } else if (response.success) {
        await dispatch(setUserDataInState(response.user));
        await auth.setTokens(response.token, response.user.roles.role);
        data.history.push("/");
        await dispatch(
          setAlertMessage({
            message: "logged in successfully",
            color: "green",
          })
        );
      }
    } catch (e) {
      await dispatch(setLoginSpinnerStatus(false));
      await dispatch(
        setErrLoginMessage({
          message: "There is an error. Please try again.",
          color: "teal",
        })
      );
      console.log(e);
    }
    setTimeout(() => {
      dispatch(setErrLoginMessage({ message: "", color: "" }));
      dispatch(setAlertMessage({ message: "", color: "" }));
    }, 3000);
  };
}

export const actions = {
  logIn,
  setErrLoginMessage,
  setUserDataInState,
  setAlertMessage,
  setForgotPasswordModal,
  setAuthModal,
  verifyEmail,
  setLoginUserPage,
  setLoginData,
  setLoginMode,
  setAuthOTPValue,
  setOTPErrorMessage,
  BridgeLogin,
};

export const initialState = {
  authToken: "",
  errLoginMessage: {
    message: "",
    color: "",
  },
  forgotModal: false,
  logInSpinnerstatus: false,
  forgotSpinner: false,
  userData: "",
  forgotErrMessage: {
    message: "",
    color: "",
  },
  userEmail: "",
  loginUser: "User",
  loginData: {
    username: "",
    password: "",
  },
  loginMode: "Standard",
  otp_err: "",
  otp: "",
};

const ACTION_HANDLERS = {
  [SET_AUTH_OTP_VALUE]: (state, action) => {
    return {
      ...state,
      otp: action.payload,
    };
  },
  [SET_LOGIN_OTP_ERROR_MESSAGE]: (state, action) => {
    return {
      ...state,
      otp_err: action.payload,
    };
  },
  [SET_USER_LOGIN_MODE]: () => {
    return {
      ...state,
      loginMode: action.payload,
    };
  },
  [SET_LOGIN_USER_PAGE]: (state, action) => {
    return {
      ...state,
      loginUser: action.payload,
    };
  },
  [LOGIN_P_SET_ERR_LOGIN_MESSAGE]: (state, action) => {
    return {
      ...state,
      errLoginMessage: action.payload,
    };
  },
  [LOGIN_P_SET_LOGIN_SPINNER_STATUS]: (state, action) => {
    return {
      ...state,
      logInSpinnerstatus: action.payload,
    };
  },
  [SET_USER_DATA_IN_STATE]: (state, action) => {
    return {
      ...state,
      userData: action.payload,
    };
  },
  [SET_FORGOT_PASSWORD_MODAL]: (state, action) => {
    return {
      ...state,
      forgotModal: action.payload,
    };
  },
  [SET_USER_UNVERIFIED_EMAIL]: (state, action) => {
    return {
      ...state,
      userEmail: action.payload,
    };
  },
  [SET_USER_LOGIN_FIELDS_DATA]: (state, action) => {
    return {
      ...state,
      loginData: { ...action.payload },
    };
  },
};

export default function authReducer(state = initialState, action) {
  const handler = ACTION_HANDLERS[action.type];
  return handler ? handler(state, action) : state;
}
