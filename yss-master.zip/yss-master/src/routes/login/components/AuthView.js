import React, { Fragment } from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";
import LoadingSpinner from "../../../components/LoadingSpinner/LoadingSpinner";
import AlertBox from "../../../components/AlertBox/AlertBox";
import AuthOTPModal from "../../Listing/components/AuthOTPModal";

export class AuthView extends React.Component {
  constructor(props) {
    super(props);
    this.handlechange = this.handlechange.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
    this.setModalState = this.setModalState.bind(this);
    this.state = {
      errorClass: "",
      remember: false,
    };
  }

  componentDidMount() {
    let body = document.body;
    body.className = "user_login";
    if (this.props.ListingState.authModal !== "login") {
      this.props.setAuthModal("");
    }
    if (localStorage.remember && localStorage.username !== "") {
      this.props.setLoginData({
        username: localStorage.getItem("username"),
        password: localStorage.getItem("password"),
      });
    }
    if (window.location.href.split("/")[3] === "counsellor") {
      let { email_id, id } = this.props.match.params;
      if (email_id && id) {
        this.props.BridgeLogin({
          data: this.props.match.params,
          history: this.props.history,
        });
      }
    }
  }

  componentWillUnmount() {
    this.props.setLoginData({ username: "", password: "" });
    // fix Warning: Can't perform a React state update on an unmounted component
    this.setState = (state, callback) => {
      return;
    };
  }

  setModalState(value) {
    this.setState({ modal: value });
  }

  handlechange(event) {
    let { loginData } = this.props.auth;
    const name = event.target.name;
    const value = event.target.value;
    if (event.target.type === "checkbox") {
      this.setState({ remember: event.target.checked });
    } else {
      loginData[name] = value;
      this.props.setLoginData(loginData);
    }
  }

  submitHandler(event) {
    event.preventDefault();
    let { loginData } = this.props.auth;
    let regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    const { remember } = this.state;
    if (!loginData.username.trim().length && !loginData.password.length) {
      this.props.setErrLoginMessage({
        message: "Email-address and password fields are required",
        color: "teal",
      });
      this.setState({ errorClass: "username" });
    } else if (!loginData.username.trim().length) {
      this.props.setErrLoginMessage({
        message: "Email field is required.",
        color: "teal",
      });
      this.setState({ errorClass: "username" });
    } else if (!regex.test(loginData.username.trim())) {
      this.props.setErrLoginMessage({
        message: "Enter a valid Email.",
        color: "teal",
      });
      this.setState({ errorClass: "username" });
    } else if (!loginData.password.length) {
      this.props.setErrLoginMessage({
        message: "Password field is required.",
        color: "teal",
      });
      this.setState({ errorClass: "password" });
    } else {
      if (remember) {
        localStorage.setItem("username", loginData.username);
        localStorage.setItem("password", loginData.password);
        localStorage.setItem("remember", remember);
      } else if (!remember) {
        null;
      }
      this.props.logIn({ ...loginData, history: this.props.history });
    }
    //---> Disappearing the Alert Message after 3 sec
    setTimeout(() => {
      this.props.setErrLoginMessage({ message: "", color: "" });
      this.setState({ errorClass: "" });
    }, 3000);
  }

  render() {
    const { errLoginMessage, logInSpinnerstatus, loginData } = this.props.auth;
    const { errSignupMessage } = this.props.Signup;
    const { authModal } = this.props.ListingState;
    let { errorClass } = this.state;
    return (
      <Fragment>
        {
          <div
            className={
              authModal === "login"
                ? "login_form w-full bg-white p-4 text-center"
                : "login_form md:w-1/2 bg-white p-4 text-center"
            }
          >
            {errSignupMessage.message ? (
              <AlertBox
                AlertText={errSignupMessage.message}
                color={errSignupMessage.color}
              />
            ) : null}
            {errLoginMessage.message ? (
              <AlertBox
                AlertText={errLoginMessage.message}
                color={errLoginMessage.color}
              />
            ) : null}
            {authModal === "OTP" ? (
              <AuthOTPModal
                cancelEvent={() => this.props.setAuthModal("")}
                history={this.props.history}
              />
            ) : null}
            <div className="site__logo w-24 m-auto">
              <Link to="/">
                <img
                  className="w-full"
                  src="images/soberlistic_small_logo.png"
                  alt="Site Logo"
                />
                <span>Soberlistic</span>
              </Link>
            </div>
            <div className="main_forms">
              <form className="login_form" onSubmit={this.submitHandler}>
                <div className="form_title font-bold">
                  <h3>Login</h3>
                </div>
                <div className="form-item">
                  <label>Email Address</label>
                  <input
                    className={errorClass == "username" ? "border-red-500" : ""}
                    type="text"
                    name="username"
                    onChange={this.handlechange}
                    value={loginData.username}
                  />
                  {errorClass == "username" ? (
                    <p className="err-message">{errLoginMessage.message}</p>
                  ) : (
                    ""
                  )}
                </div>
                <div className="form-item">
                  <label>Password</label>
                  <input
                    className={errorClass == "password" ? "border-red-500" : ""}
                    type="password"
                    name="password"
                    onChange={this.handlechange}
                    value={loginData.password}
                  />
                  {errorClass == "password" ? (
                    <p className="err-message">{errLoginMessage.message}</p>
                  ) : (
                    ""
                  )}
                </div>
                <div className="form-item form-item--checkbox">
                  <input
                    id="remember"
                    type="checkbox"
                    onChange={this.handlechange}
                  />
                  <label htmlFor="remember">Remember Me</label>
                </div>
                <div className="form-actions">
                  <button type="submit">
                    {logInSpinnerstatus ? <LoadingSpinner /> : "Submit"}
                  </button>
                </div>
              </form>
              {authModal !== "login" ? (
                <div className="forget_pwd">
                  {location.href.split("/")[3] == "user" ? (
                    <Fragment>
                      {" "}
                      Don't have an Account{" "}
                      <Link className="text_nav_blue" to="/user/signup">
                        SignUp here!
                      </Link>
                      <br />
                    </Fragment>
                  ) : null}
                  <Link
                    to="/user/forgot-password"
                    className="modal-open text_nav_blue"
                  >
                    Forgot Password?
                  </Link>
                </div>
              ) : null}
            </div>
          </div>
        }
        {authModal === "" ? (
          <div className="welcome_note text-white text-center md:w-1/2 p-6 md:px-8 lg:px-16">
            <div className="form_text--title">
              <h3>Heading</h3>
            </div>
            <div className="login__text">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua.
              </p>
              <p>
                Quis ipsum suspendisse ultrices gravida. Risus commodo viverra
                maecenas accumsan lacus vel facilisis. ommodo viverra maecenas
              </p>
            </div>
            <div className="btn login_text--btn">
              {location.pathname.slice(0, 5) === "/user" ? (
                <Link to="/coach/login">Login as Coach</Link>
              ) : (
                <Link to="/user/login">Login as User</Link>
              )}
            </div>
          </div>
        ) : null}
      </Fragment>
    );
  }
}

// AuthView.propTypes = {
//   history: PropTypes.object.isRequired,
//   auth: PropTypes.object.isRequired,
//   logIn: PropTypes.func.isRequired,
//   setErrLoginMessage: PropTypes.func.isRequired,
// };

export default AuthView;
