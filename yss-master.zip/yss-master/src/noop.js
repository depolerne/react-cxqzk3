
import React from 'react';

class ToastContainer extends React.Component {
    render () {
        return React.createElement('div');
    }
}

const ToastMessage = {};
export {
    ToastContainer, ToastMessage
};
