import React from 'react';
import PropTypes from 'prop-types';
import pure from 'recompose/pure';

export const Input = ({ name, value, className, onChange, options, openOnFocus, clearable }) => {
    return (
        <input
            className={className}
            type="text"
            name={name}
            onChange={onChange}
            defaultValue={value} 
        />
    );
};



export default pure(Input);
