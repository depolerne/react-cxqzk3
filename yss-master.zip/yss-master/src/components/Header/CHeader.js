import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { actions } from "../../routes/selectWrapper/modules/select";
import { bindActionCreators } from "redux";

export class CHeader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      menu_bar: false,
    };
    this.toggle = this.toggle.bind(this);
  }

  toggle() {
    this.setState({
      menu_bar: !this.state.menu_bar,
    });
  }

  render() {
    let { avatar } = this.props;
    let { menu } = this.props.selectState;
    let { menu_bar } = this.state;
    return (
      <Fragment>
		    <header className="yss-site__header hidden md:block border-b-1">
          <div className="yss-site__wrapper">
            <div className="yss-site__logo">
              <Link to="/" className="hover:text-gray-900">
                <img src="images/SoberListic_web_logo.png" />
              </Link>
            </div>
            <nav className="yss-site__nav">
              <Link to="/" className="hover:text-gray-900">
                Home
              </Link>
              <Link to="/about" className="hover:text-gray-900">
                About
              </Link>
              {/* <Link
                to="/how-it-works"
                className="hover:text-gray-900"
              >
                How It Works
              </Link> */}
              <Link to="/find-your-coach" className="hover:text-gray-900">
                Search Now
              </Link>
              {/* <Link to="/contact" className="hover:text-gray-900">
                Contact
              </Link> */}
              <Link
                to="/coach/dashboard/myprofile" className="hover:text-gray-900"
              >
                My Account
              </Link>
              <Link
                title="Notifications"
                to="/coach/dashboard/notifications" className="hover:text-gray-900"
              >
                <i className="fas fa-bell"></i>
              </Link>
              <Link 
                to="/"
                title="Logout"
                onClick={this.props.logout}
              >
                Logout
                {/*<svg xmlns="http://www.w3.org/2000/svg" width="210.093" height="210.366" viewBox="0 0 210.093 210.366">
                  <path id="icons8_logout_rounded_up" d="M109.046,3.969l-6.291,6.018L67.739,45,80.323,57.587l19.969-19.97V144.3H117.8V37.616l19.97,19.97L150.354,45,115.339,9.987ZM48.59,23.391a105.046,105.046,0,1,0,120.913,0L159.381,37.616a87.539,87.539,0,1,1-100.669,0Z" transform="translate(-4 -3.969)"/>
    </svg>*/}
              </Link>
            </nav>
          </div>
        </header>
        <nav className="site__navigations cons__nav">
          {/* Left side NavBar */}
			  {/*<div className="site__logo">
            <Link to="/">
              <img
                className="w-full"
                src="images/yss_new_logo4x.svg"
                alt="Site Logo"
              />
              <span>Your Safe Space</span>
            </Link>
			  </div>*/}
          <ul className="main__nav">
            {/* Links */}
            <li className={menu === "dashboard" ? "active" : ""}>
              <Link
                to="/coach/dashboard"
                onClick={() => this.props.setMenuHover("dashboard")}
              >
                <span className="menu_icon">
                  <img src="images/dashboard_icon.svg" />
                </span>
                <span>Dashboard</span>
              </Link>
            </li>
            <li className={menu === "bookings" ? "active" : ""}>
              <Link
                to="/coach/dashboard/appointments"
                onClick={() => this.props.setMenuHover("bookings")}
              >
                <span className="menu_icon">
                  <img src="images/appointments_icon.svg" />
                </span>
                <span>Appointments</span>
              </Link>
            </li>
            <li className={menu === "avail" ? "active" : ""}>
              <Link
                to="/coach/dashboard/availability"
                onClick={() => this.props.setMenuHover("avail")}
              >
                <span className="menu_icon">
                  <img src="images/bookings_icon.svg" />
                </span>
                <span>Availability</span>
              </Link>
            </li>
            <li className={menu === "packages" ? "active" : ""}>
              <Link
                to="/coach/dashboard/package_lists"
                onClick={() => this.props.setMenuHover("packages")}
              >
                <span className="menu_icon">
                  <img src="images/packages_icon.svg" />
                </span>
                <span>Packages</span>
              </Link>
            </li>
            <li className={menu === "profile" ? "active" : ""} hidden>
              <Link
                to="/coach/dashboard/myprofile"
                onClick={() => this.props.setMenuHover("profile")}
              >
                <span className="menu_icon">
                  <img src="images/profile_icon.svg" />
                </span>
                <span>Profile</span>
              </Link>
            </li>
            <li className={menu === "profile" ? "active" : ""}>
              <Link to="/coach/dashboard/myprofile"
                onClick={() => this.props.setMenuHover("profile")}>
                <span className="profile__pic">
                  {avatar === null ? (
                    <img
                      className="profile_avatar"
                      src="images/user_icon.svg"
                    />
                  ) : (
                    <img src={__IMG_URL__ + avatar} />
                  )}
                </span>
                <span>
                  {this.props.name}
                  <br />
                  <span className="text_nav_blue"></span>
                </span>
              </Link>
            </li>
            {/*<li className="auth_links">
              <a
                className="items-center flex"
                to="/"
                onClick={this.props.logout}
              >
                <span className="svg-icon">
                  <svg
                    className="w-3 mr-1"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="#ffffff"
                    viewBox="0 0 20 20"
                  >
                    <path d="M4.16 4.16l1.42 1.42A6.99 6.99 0 0 0 10 18a7 7 0 0 0 4.42-12.42l1.42-1.42a9 9 0 1 1-11.69 0zM9 0h2v8H9V0z" />
                  </svg>
                </span>
                <span className="leading-5" style={{ cursor: "pointer" }}>
                  Logout
                </span>
              </a>
                  </li>*/}
          </ul>
        </nav>
        {/* -------------------------Mobile Header-------------------------- */}
        <header className="mobile__header">
          <div className="mobile_top__bar">
            <div className="yss-site__logo">
              <Link to="/" className="hover:text-gray-900">
                <img src="images/SoberListic_web_logo.png" />
              </Link>
            </div>
            <button
              className="text-3xl focus:outline-none"
              onClick={() => this.toggle()}
            >
              {menu_bar ? (
                <i className="fas fa-times" id="fa-times" />
              ) : (
                <i className="fas fa-bars" id="fa-bars" />
              )}
            </button>
          </div>
          {/* Dropdown Nav */}
          {menu_bar ? (
            <nav className="flex flex-col pt-4">
              <ul className="mobile__main__nav" id="mobile__nav">
                {/* Links */}
                <li className="mobile_menu_icon">                  
                  <Link
                    to="/coach/dashboard"
                    className="clearfix"
                  >
                    <span className="nav__title">Dashboard</span>
                  </Link>
                  <ul className="nav__sub-menu">
                    <li className="mobile_menu_icon">
                      <Link
                        to="/coach/dashboard/appointments"
                        className="clearfix"
                        onClick={() => this.toggle()}
                      >
                        <span className="menu_icon">
                          <img src="images/appointments_icon.svg" />
                        </span>
                        <span className="nav__title">Appointments</span>
                      </Link>
                    </li>
                    <li className="mobile_menu_icon">
                      <Link
                        to="/coach/dashboard/availability"
                        className="clearfix"
                        onClick={() => this.toggle()}
                      >
                        <span className="menu_icon">
                          <img src="images/bookings_icon.svg" />
                        </span>
                        <span className="nav__title">Availability</span>
                      </Link>
                    </li>
                    <li className="mobile_menu_icon">
                      <Link
                        to="/coach/dashboard/package_lists"
                        className="clearfix"
                        onClick={() => this.toggle()}
                      >
                        <span className="menu_icon">
                          <img src="images/packages_icon.svg" />
                        </span>
                        <span className="nav__title">
                          Client Packages
                        </span>
                      </Link>
                    </li>
                    <li className="mobile_menu_icon">
                      <Link
                        to="/coach/dashboard/myprofile"
                        className="clearfix"
                        onClick={() => this.toggle()}
                      >
                        <span className="menu_icon">
                          <img src="images/profile_icon.svg" />
                        </span>
                        <span className="nav__title">My Account</span>
                      </Link>
                    </li>
                    {/*<li className="mobile_menu_icon pointer-events-none">
                      <Link to="#" className="clearfix">
                        <span className="profile__pic">
                          {avatar === null ? (
                            <img
                              className="profile_avatar"
                              src="images/user_icon.svg"
                            />
                          ) : (
                            <img src={__IMG_URL__ + avatar} />
                          )}
                        </span>
                        <span className="nav__title">
                          {this.props.name} <br />{" "}
                          <span className="text_nav_blue"></span>
                        </span>
                      </Link>
                          </li>*/}
                  </ul>
                </li>
                <li className="mobile_menu_icon">
                  <Link to="/" className="hover:text-gray-900">
                    <i className="fas fa-home"></i>
                    Home
                  </Link>
                </li>
                <li className="mobile_menu_icon">
                  <Link to="/about" className="hover:text-gray-900">
                    <i className="far fa-heart"></i>
                    About
                  </Link>
                </li>
                {/* <li className="mobile_menu_icon">
                  <Link
                    to="/how-it-works"
                    className="hover:text-gray-900"
                  >
                    <i className="far fa-question-circle"></i>
                    How It Works
                  </Link>
                </li> */}
                <li className="mobile_menu_icon">
                  <Link to="/find-your-coach" className="hover:text-gray-900">
                    <i className="fas fa-search"></i>
                    Search Now
                  </Link>
                </li>
                {/* <li className="mobile_menu_icon">
                  <Link to="/contact" className="hover:text-gray-900">
                    <i className="far fa-star"></i>
                    Contact
                  </Link>
                </li> */}
                <li className="mobile_menu_icon">
                  <Link
                    to="/coach/dashboard/notifications" className="hover:text-gray-900"
                  >
                    <i className="fas fa-bell"></i>
                    Notifications
                  </Link>
                </li>
                <li className="mobile_menu_icon">
                  <Link
                    className="items-center flex"
                    to="#"
                    onClick={this.props.logout}
                  >
                    <span className="svg-icon">
                      <svg
                        className="w-3 mr-1"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="#ffffff"
                        viewBox="0 0 20 20"
                      >
                        <path d="M4.16 4.16l1.42 1.42A6.99 6.99 0 0 0 10 18a7 7 0 0 0 4.42-12.42l1.42-1.42a9 9 0 1 1-11.69 0zM9 0h2v8H9V0z" />
                      </svg>
                    </span>
                    Logout
                  </Link>
                </li>
              </ul>
            </nav>
          ) : null}
        </header>
      </Fragment>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CDashboardState: state.CDashboardState,
});

export default connect(mapStateToProps, mapDispatchToProps)(CHeader);
