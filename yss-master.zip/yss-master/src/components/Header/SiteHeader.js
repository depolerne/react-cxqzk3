import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import auth from "../../helpers/auth";
//import { actions } from "../../routes/Listing/modules/Listing";
import { connect } from "react-redux";
import { actions } from "../../routes/selectWrapper/modules/select";
import WaitingPopUp from "../WaitiingPopUp/WaitingPopUp";
import { socket } from "../../helpers/socketHelper";

export class SiteHeader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      logout: false,
      menu_bar: false,
    };
    this.toggle = this.toggle.bind(this);
  }

  componentDidMount() {
    
    socket.on("new_request", (data) => {
      this.props.setWaitingList(data);
    });
    let rootEle = document.getElementById("adam");
    rootEle.classList.add("yss-web");
  }

  componentWillUnmount() {
    let rootEle = document.getElementById("adam");
    rootEle.classList.remove("yss-web");
  }

  toggle() {
    this.setState({
      menu_bar: !this.state.menu_bar,
    });
  }

  render() {
    let { waitingList } = this.props.selectState;
    let { menu_bar } = this.state;
    return (
      <Fragment>
        <header className="yss-site__header">
          {waitingList.length
            ? waitingList.map((item, i) => (
                <WaitingPopUp
                  key={i}
                  name={item.username}
                  clickEvent={() => this.props.Reject(item)}
                  acceptEvent={() => this.props.Accept(item)}
                  avatar={item.avatar}
                />
              ))
            : null}
          <div className="yss-site__wrapper">
            <div className="yss-site__logo">
              <Link to="/" className="hover:text-gray-900">
                <img src="images/SoberListic_web_logo.png" />
              </Link>
            </div>
            <nav className="yss-site__nav">
              <Link to="/" className="hover:text-gray-900">
                Home
              </Link>
              <Link to="/about" className="hover:text-gray-900">
                About
              </Link>
              {/* <Link
                to="/how-it-works"
                className="hover:text-gray-900"
              >
                How It Works
              </Link> */}
              <Link to="/find-your-coach" className="hover:text-gray-900">
                Search Now
              </Link>
              {/* <Link to="/contact" className="hover:text-gray-900">
                Contact
              </Link> */}
              {auth.isAuthenticated ? (
                <Link
                  to={
                    auth.getUserType() === "counsellor"
                      ? "/coach/dashboard/myprofile"
                      : "/dashboard/myprofile"
                  }
                  className="hover:text-gray-900"
                >
                  {/*<i className="fas fa-user"></i>*/}
                  My Account
                </Link>
              ) : (
                <Link
                  to="/add-your-listings"
                  className="hover:text-gray-900"
                >
                  {/*<i className="fas fa-plus"></i>*/}
                  Add Your Listing
                </Link>
              )}
              {!auth.isAuthenticated ? (
                <Link to="/user/login" className="hover:text-gray-900">
                  Login
                </Link>
              ) : (
                <div className="flex">
                  <Link
                    to={
                      auth.getUserType() === "counsellor"
                        ? "/coach/dashboard/notifications"
                        : "/dashboard/notifications"
                    }
                    title="Notifications"
                    className="hover:text-gray-900"
                  >
                    <i className="fas fa-bell"></i>
                  </Link>
                  <Link
                    onClick={() => this.props.logout()}
                    to="#"
                    title="Logout"
                    className="hover:text-gray-900"
                  >
                    Logout
                  </Link>
                </div>
              )}
            </nav>
          </div>
        </header>

        <header className="site--mobile__header mobile__header">
          <div className="mobile_top__bar">
            <div className="yss-site__logo">
              <Link to="/">
                <img src="images/SoberListic_web_logo.png" />
              </Link>
            </div>
            <button
              className="text-3xl focus:outline-none"
              onClick={() => this.toggle()}
            >
              {menu_bar ? (
                <i className="fas fa-times" />
              ) : (
                <i className="fas fa-bars" />
              )}
            </button>
          </div>
          {/* Dropdown Nav */}
          {menu_bar ? (
            <nav className="flex flex-col">
              <ul className="mobile__main__nav">
                {/* Links */}
                <li>
                  <Link
                    to="/"
                    className="hover:text-gray-900"
                    onClick={() => this.toggle()}
                  >
                    <i className="fas fa-home"></i>
                    Home
                  </Link>
                </li>
                <li>
                  <Link
                    to="/about"
                    className="hover:text-gray-900"
                    onClick={() => this.toggle()}
                  >
                    <i className="far fa-heart"></i>
                    About
                  </Link>
                </li>
                {/* <li>
                  <Link
                    to="/how-it-works"
                    className="hover:text-gray-900"
                    onClick={() => this.toggle()}
                  >
                    <i className="far fa-question-circle"></i>
                    How It Works
                  </Link>
                </li> */}
                <li>
                  <Link
                    to="/find-your-coach"
                    className="hover:text-gray-900"
                    onClick={() => this.toggle()}
                  >
                    <i className="fas fa-search"></i>
                    Search Now
                  </Link>
                </li>
                {/* <li>
                  <Link
                    to="/contact"
                    className="hover:text-gray-900"
                    onClick={() => this.toggle()}
                  >
                    <i className="far fa-star"></i>
                    Contact
                  </Link>
                </li> */}
                <li>
                  {auth.isAuthenticated ? (
                    <Link
                      to={
                        auth.getUserType() === "counsellor"
                          ? "/coach/dashboard/myprofile"
                          : "/dashboard/myprofile"
                      }
                      className="hover:text-gray-900"
                      onClick={() => this.toggle()}
                    >
                      <i className="fas fa-user"></i>
                      My Account
                    </Link>
                  ) : (
                    <Link
                      to="/add-your-listings"
                      className="hover:text-gray-900"
                      onClick={() => this.toggle()}
                    >
                      <i className="fas fa-plus"></i>
                      Add Your Listing
                    </Link>
                  )}
                </li>
                <li>
                  {!auth.isAuthenticated ? (
                    <Link to="/user/login" className="hover:text-gray-900">
                      Log In
                    </Link>
                  ) : (
                    <Link
                      onClick={() => this.props.logout()}
                      to="#"
                      className="hover:text-gray-900"
                    >
                      Log Out
                    </Link>
                  )}
                </li>
              </ul>
            </nav>
          ) : null}
        </header>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CDashboardState: state.CDashboardState,
  NotificationState: state.NotificationState,
});

export default connect(mapStateToProps, actions)(SiteHeader);
