import React from "react";
import { Link } from "react-router-dom";
import { Fragment } from "react";
//import CookieConsent from "react-cookie-consent";
import CookieBot from "react-cookiebot";
const domainGroupId = 'baf0527d-c294-4ea2-b55a-90eb4002709b';

export class FooterBar extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    
    return (
      <Fragment>
        <div className="site__footer clearfix">
			<div className="page__content">
          <div className="footer_content">
            <p>©2021 Wellness Tech Ltd - 13156843. All rights reserved.</p>
          </div>
          <div className="footer__nav">
            <ul>
              <li>
                <Link to="/privacy-policy">Privacy Policy</Link>
              </li>
              <li>
                <Link to="/terms-and-conditions">Terms and Conditions</Link>
              </li>
              <li>
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
              </li>
              <li>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
              </li>
            </ul>
          </div>
		  </div>
        </div>

        <CookieBot domainGroupId={domainGroupId} />
        
      </Fragment>
    );
  }
}

export default FooterBar;
