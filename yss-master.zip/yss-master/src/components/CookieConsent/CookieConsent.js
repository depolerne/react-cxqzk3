import React, { Fragment } from "react";
import { Link } from "react-router-dom";

class CookieConsent extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    let body = document.body;
    body.className = "cookies_consent";
  }

  render() {
    return (
      <Fragment>
        {" "}
        <div className="main-content yss-site--main__content">
          <div className="main-site__content">
            <div className="page__content">
              <div className="section--wrapper">
                <div className="section--width">
                  <div className="information_block block--para--lists">
                    <div className="block--title">
                      <h2>Cookies Consent</h2>
                    </div>
                    <div className="block--text">
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default CookieConsent;
