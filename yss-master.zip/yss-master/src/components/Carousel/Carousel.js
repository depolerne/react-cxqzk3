import React, { Fragment } from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";
import "./style.css";

export class Carousel extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const settings = {
      dots: true,
      fade: true,
      infinite: true,
      speed: 1000,
      slidesToShow: 1,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 5000,
      arrows: false,
    };

    return (
      <Fragment>
        <Slider {...settings}>
          <div>
            <img src="images/slider1.jpg" className="slider1" />
          </div>
          <div>
            <img src="images/slider2.jpg" className="slider2" />
          </div>
          <div>
            <img src="images/slider3.jpg" className="slider3" />
          </div>
          <div>
            <img src="images/slider4.jpg" className="slider4" />
          </div>
          <div>
            <img src="images/slider5.jpg" className="slider5" />
          </div>
         </Slider>
      </Fragment>
    );
  }
}

export default Carousel;
