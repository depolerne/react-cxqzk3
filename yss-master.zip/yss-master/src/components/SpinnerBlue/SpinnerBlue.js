import React, { Fragment } from "react";
import "./spinnerblue.css";

export const SpinnerBlue = (height, width) => {
  return (
    <div className="sb-fading-circle">
      <div className="sb-circle1 sb-circle"></div>
      <div className="sb-circle2 sb-circle"></div>
      <div className="sb-circle3 sb-circle"></div>
      <div className="sb-circle4 sb-circle"></div>
      <div className="sb-circle5 sb-circle"></div>
      <div className="sb-circle6 sb-circle"></div>
      <div className="sb-circle7 sb-circle"></div>
      <div className="sb-circle8 sb-circle"></div>
      <div className="sb-circle9 sb-circle"></div>
      <div className="sb-circle10 sb-circle"></div>
      <div className="sb-circle11 sb-circle"></div>
      <div className="sb-circle12 sb-circle"></div>
    </div>
  );
};

export default SpinnerBlue;
