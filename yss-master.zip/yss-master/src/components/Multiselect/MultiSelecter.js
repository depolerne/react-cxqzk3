import React, { Fragment, useEffect, useRef } from "react";
import { Multiselect } from "multiselect-react-dropdown";
import $ from "jquery";

export class MultiSelecter extends React.Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.multiRef=React.createRef();
  }

  handleChange = (selected) => {
    let id=this.multiRef.current.props.id;
    this.props.fireData(id, selected);
  };

  render() {
    const {displayValue,Options,id,selectedValue}=this.props;
    return (
      <Fragment>
        <Multiselect
              options={Options}
              displayValue={displayValue}
              id={id}
              ref={this.multiRef}
              onSelect={this.handleChange}
              onRemove={this.handleChange}
              selectedValues={selectedValue}
              style={{
                chips: { background: "#34558b" },
                searchBox: {
                  border: "none",
                  borderBottom: "1px solid #dfdfdf",
                  borderRadius: "0px",
                },
              }}
              selectionLimit={3}
            />
      </Fragment>
    );
  }
}
export default MultiSelecter;
