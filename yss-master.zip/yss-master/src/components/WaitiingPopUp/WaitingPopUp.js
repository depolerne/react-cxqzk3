import React from "react";
import {Link} from 'react-router-dom'

export class WaitingPopUp extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="video-invite-popup">
        <div className="popup-content">
          <div className="invite-user">
            <img src="images/profile_black_icon.svg" />
          </div>
          <div className="invite-detail">
            <p className="invite-title">
              {this.props.name} wants to join the call
            </p>
            <p className="invite-name">{this.props.name}</p>
            <p></p>
          </div>
        </div>
        <div className="invite-actions">
          <p>
            {/* As the host, you can remove anyone at any time{" "} */}
            <Link to="#" className="call-remove" onClick={this.props.clickEvent}>
              Deny entry
            </Link>{" "}
            <Link to="/startSession/session" className="call-accept" onClick={this.props.acceptEvent}>
              Admit
            </Link>
          </p>
        </div>
      </div>
    );
  }
}

export default WaitingPopUp;