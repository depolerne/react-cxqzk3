import React, { Fragment } from "react";
import "./style.css";

export class Calender extends React.Component {
  constructor(props){
    super(props);
  }
  componentDidMount(){
      
  }
    render() {
    return <Fragment>

    </Fragment>;
  }
}

export default Calender;
