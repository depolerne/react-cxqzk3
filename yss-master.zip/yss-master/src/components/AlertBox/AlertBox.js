import React, { Fragment } from "react";
import { connect } from "react-redux";
import { actions } from "../../routes/selectWrapper/modules/select";

export class AlertBox extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let { color } = this.props;
    return (
      <Fragment>
        <div className="alert-toast fixed top-0 right-0 items-center mr-8 mt-4 w-5/6 md:w-full max-w-sm">
          <label
            className={`close cursor-pointer flex items-start justify-between w-full p-2 bg-white border-solid border-1 border-red-300 h-15 shadow-lg text-black`}
            title="close"
            htmlFor="footertoast"
          >
            {' '}{color === "teal" ? (
              <img src="images/cancel_cross.svg" className="w-6" />
            ) : (
              <img src="images/green_tick.svg" className="w-6" />
            )}
            {this.props.AlertText}
            <svg
              onClick={this.props.clickEvent}
              className="fill-current text-black"
              xmlns="http://www.w3.org/2000/svg"
              width={18}
              height={18}
              viewBox="0 0 18 18"
            >
              <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z" />
            </svg>
          </label>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
});

export default connect(mapStateToProps, actions)(AlertBox);
