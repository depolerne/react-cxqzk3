import React, { Fragment } from "react";
import ModalBody from "../ModalBody";
import { actions } from "../../../routes/Listing/modules/Listing";
import { connect } from "react-redux";
// import {  } from "module";
import ReactStars from "react-rating-stars-component";

export class EditReview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {borderColor:"#e5e5e5"};
    this.handleChange = this.handleChange.bind(this);
    this.handleRating = this.handleRating.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
  }

  componentDidMount() {
    document.body.classList.add("edit_review");
  }

  componentWillUnmount(){
    document.body.classList.remove("edit_review");
  }

  handleChange(e) {
    let { updatedReviewData } = this.props.ListingState;
    updatedReviewData[e.target.name] = e.target.value;
    this.props.setUpdatedReviewData(updatedReviewData);
  }

  handleRating(value) {
    let { updatedReviewData } = this.props.ListingState;
    updatedReviewData["rating"] = value;
    this.props.setUpdatedReviewData(updatedReviewData);
  }

  submitHandler(e) {
    debugger;
    e.preventDefault();

    let {
      updatedReviewData,
      updatedReviewData: { rating },
      updatedReviewData: {review}
    } = this.props.ListingState;
    if (rating === 0) {
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({ message: "Please select the ratings." });
    } else if (review == null || review ==""){
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({
        message: "Review should contain at least 50 characters.",
        color: "teal",
      });
    }else if (review.length < 50) {
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({
        message: "Review should contain at least 50 characters.",
        color: "teal",
      });
    } else if (review.length > 250) {
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({
        message: "Review should not contain more than 250 characters.",
        color: "teal",
      });
    }else {
      this.setState({borderColor:"#e5e5e5"});
      this.props.updateReview(updatedReviewData);
    }

    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
    }, 3000);
  }

  render() {
    let {
      updatedReviewData: { rating, review },
    } = this.props.ListingState;
    return (
      <Fragment>
        <ModalBody closeEvent={() => this.props.setReviewModal("")}>
          <form className="review__form" onSubmit={this.submitHandler}>
            <div className="form-item">
              <div className="form-label">Review:</div>
              <textarea
                className="border-blue-800"
                type="text"
                name="review"
                placeholder="Write a review"
                value={review}
                onChange={this.handleChange}
                autoComplete="off"
                style={{borderColor: this.state.borderColor}}
              />
            </div>
            <div className="form-item">
              <div className="form-label">Rating:</div>
              <ReactStars
                size={40}
                count={5}
                color={"grey"}
                activeColor="#eb8a2f"
                value={rating}
                a11y={true}
                isHalf={true}
                onChange={this.handleRating}
              />
            </div>
            <span className="flex w-full mx-auto rounded-md shadow-sm sm:w-auto">
              <button
                // onClick={this.props.actionEvent}
                type="submit"
                className="remove__button"
              >
                Update
              </button>
            </span>
          </form>
        </ModalBody>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ListingState: state.ListingState,
});

export default connect(mapStateToProps, actions)(EditReview);
