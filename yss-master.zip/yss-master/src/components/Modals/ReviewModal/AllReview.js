import React, { Fragment } from "react";
import ModalBody from "../ModalBody";
import { actions } from "../../../routes/Listing/modules/Listing";
import { connect } from "react-redux";
import ReactStars from "react-rating-stars-component";
import { Link } from "react-router-dom";

let arr=[]
class AllReview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      readmore: [],
    };
    this.EditModal = this.EditModal.bind(this);
    this.setReadMore=this.setReadMore.bind(this);
  }

  EditModal(item) {
    this.props.setReviewModal("edit");
    this.props.setUpdatedReviewData(item);
  }

  componentDidMount() {
    document.body.classList.add("modal--open");
  }

  componentWillUnmount() {
    document.body.classList.remove("modal--open");
  }

  setReadMore(id) {
    arr.push(id);
    this.setState({readmore:arr})
  }

  render() {
    let { reviews } = this.props.ListingState;
    let { userData } = this.props.selectState;
    let { readmore } = this.state;
    return (
      <Fragment>
        <ModalBody closeEvent={() => this.props.setReviewModal("")}>
          <div className="packages__list md:flex md:flex-wrap">
            <ul>
              {reviews.data.map((item) => (
                <li className="mb-6" key={item.id}>
                  <div className="pack__info">
                    <div className="pack__detail">
                      <div className="pack__title">
                        <h3>{item.user.name}</h3>
                      </div>
                      <div className="pack__text">
                        <p>
                          {readmore.includes(item.id)
                            ? item.review
                            : (item.review) ? item.review.slice(0, 150) : null}
                          {readmore.includes(item.id) ? null : (
                            <Link
                              className="read_more"
                              to="#"
                              onClick={() => {
                                this.setReadMore(item.id);
                              }}
                            >
                              {(item.review) ? item.review.length > 150
                                ? "... read more"
                                : null : null}
                            </Link>
                          )}
                        </p>
                        {item.user.id === userData.id && (
                          <button
                            onClick={() => this.EditModal(item)}
                            className="bg_blue text-white font-semibold py-2 px-4 mt-4 review__edit--btn"
                          >
                            Edit
                          </button>
                        )}
                      </div>
                      <div className="mt-4 listing-rating listing-rating--card">
                        {/* {item.rating ? (
                          <h1 className="text-yellow-700 font-bold text-xl my-auto">
                            {"(" +
                              parseFloat(item.rating).toFixed(1) +
                              ")"}
                          </h1>
                        ) : (
                          <h1 className="text-gray-600 font-bold text-xl my-auto">
                            {"(" + 0 + ")"}
                          </h1>
                        )} */}
                        <ReactStars
                          edit={false}
                          size={30}
                          isHalf={true}
                          value={parseFloat(item.rating)}
                          activeColor="#eb8a2f"
                        />
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </ModalBody>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ListingState: state.ListingState,
});

export default connect(mapStateToProps, actions)(AllReview);
