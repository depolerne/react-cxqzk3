import React from "react";
import ModalBody from "../ModalBody";
import { actions } from "../../../routes/Listing/modules/Listing";
import { connect } from "react-redux";
import ReactStars from "react-rating-stars-component";

class ReadReview extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const { readReviewData } = this.props.ListingState;
    return (
      <ModalBody closeEvent={() => this.props.setReviewModal("")}>
        <li className="mb-6">
          <div className="pack__info review_modal--text">
            <div className="pack__detail">
              <div className="pack__title">
                <h3>{readReviewData.user.name}</h3>
              </div>
              <div className="pack__text">
                <p>{readReviewData.review}</p>
              </div>
              <div className="mt-4 listing-rating listing-rating--card">
                {/* {readReviewData.rating ? (
                  <h1 className="text-yellow-700 font-bold text-xl my-auto">
                    {"(" + parseFloat(readReviewData.rating).toFixed(1) + ")"}
                  </h1>
                ) : (
                  <h1 className="text-gray-600 font-bold text-xl my-auto">
                    {"(" + 0 + ")"}
                  </h1>
                )} */}
                <ReactStars
                  edit={false}
                  size={30}
                  isHalf={true}
                  activeColor="#eb8a2f"
                  value={parseFloat(readReviewData.rating).toFixed(2)}
                />
              </div>
            </div>
          </div>
        </li>
      </ModalBody>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  ListingState: state.ListingState,
});

export default connect(mapStateToProps, actions)(ReadReview);
