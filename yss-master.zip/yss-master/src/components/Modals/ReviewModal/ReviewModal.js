import React, { Children, Fragment } from "react";
import ReactStars from "react-rating-stars-component";
import { actions } from "../../../routes/Listing/modules/Listing";
import { connect } from "react-redux";
import ModalBody from "../ModalBody";

export class ReviewModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rating: 0,
      review: "",
      borderColor:"#e5e5e5"
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleRating = this.handleRating.bind(this);
    this.submitHandler = this.submitHandler.bind(this);
  }

  componentDidMount() {
    document.body.classList.add("review_modal");
  }

  componentWillUnmount() {
    document.body.classList.remove("review_modal");
  }

  handleRating = (value) => {
    this.setState({ rating: value });
  };

  handleChange = (e) => {
    this.setState({ review: e.target.value });
  };

  submitHandler(e) {
    e.preventDefault();
    const { rating, review } = this.state;
    if (review.length < 50) {
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({
        message: "Review should contain at least 50 characters.",
        color: "teal",
      });
    } else if (rating === 0) {
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({
        message: "Please give a star rating.",
        color: "teal",
      });
    } else if (review.length > 250) {
      this.setState({borderColor:"red"});
      this.props.setSiteAlertMessage({
        message: "Review should not contain more than 250 characters.",
        color: "teal",
      });
    } else {
      this.setState({borderColor:"#e5e5e5"});
      this.props.saveReviewRating({ ...this.state });
    }

    setTimeout(() => {
      this.props.setSiteAlertMessage({ message: "", color: "" });
    }, 3000);

  }

  render() {
    let { rating } = this.state;

    return (
      <Fragment>
        <ModalBody closeEvent={() => this.props.setReviewModal("")}>
          <form className="review__form" onSubmit={this.submitHandler}>
            <div className="form-item">
              <div className="form-label">Review:</div>
              <textarea
                className="border-blue-800"
                type="text"
                name="review"
                placeholder="Write a review"
                //   value={package_description}
                onChange={this.handleChange}
                autoComplete="off"
                style={{borderColor: this.state.borderColor}}
              />
            </div>
            <div className="form-item">
              <div className="form-label">Rating:</div>

              <ReactStars
                size={40}
                count={5}
                color={"grey"}
                activeColor="#eb8a2f"
                value={rating}
                a11y={true}
                isHalf={true}
                onChange={this.handleRating}
              />
            </div>
            <span className="flex w-full mx-auto rounded-md shadow-sm sm:w-auto">
              <button
                onClick={this.props.actionEvent}
                type="submit"
                className="remove__button"
              >
                Submit
              </button>
            </span>
          </form>
        </ModalBody>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  UserAppointmentState: state.UserAppointmentState,
});

export default connect(mapStateToProps, actions)(ReviewModal);
