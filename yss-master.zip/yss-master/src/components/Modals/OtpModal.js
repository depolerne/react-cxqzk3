import React, { Children, Fragment } from "react";
import LoadingSpinner from "../LoadingSpinner/LoadingSpinner";
import { actions } from "../../routes/selectWrapper/modules/select";
import { connect } from "react-redux";

export class OtpModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      otp: "",
      err: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentDidMount(){
    document.body.classList.add("modal--open");
  }

  componentWillUnmount(){
    document.body.classList.remove("modal--open");
  }

  onSubmit(event) {
    event.preventDefault();
    if (this.state.otp == "") {
      this.setState({ err: "otp" });
    } else if (this.state.otp.length < 4) {
      this.setState({ err: "otp" });
    } else {
      this.props.sendOtp(this.state.otp);
      this.setState({ otp: "" });
    }
    // setTimeout(() => {
    //   this.setState({ err: "" });
    // }, 3000);
  }

  handleChange(event) {
    this.setState({ otp: event.target.value });
  }

  limitText(event) {
    if (event.target.value.length > 4) {
      event.target.value = event.target.value.substring(0, 4);
    }
  }

  render() {
    let { err } = this.state;
    return (
      <Fragment>
        <div className="modal opacity fixed w-full h-full top-0 left-0 flex items-center justify-center z-10">
          <div className="modal-overlay absolute w-full h-full bg-gray-900 opacity-75" />
          <div className="modal-container bg-white w-11/12 md:w-9/12 lg:w-4/12 mx-auto z-50 overflow-y-auto">
            {/* Add margin if you want to see some of the overlay behind the modal*/}
            <div className="modal-content p-6 text-left">
              {/*Title*/}
              <div className="flex justify-end pb-3">
                <div
                  className="modal-close cursor-pointer z-50"
                  onClick={this.props.cancelEvent}
                >
                  <svg
                    className="fill-current text-black"
                    xmlns="http://www.w3.org/2000/svg"
                    width={18}
                    height={18}
                    viewBox="0 0 18 18"
                  >
                    <path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z" />
                  </svg>
                </div>
              </div>
              {/*Body*/}
              <div className="modal__body text-center">
                <div className="site__logo w-24 m-auto">
                  <Link to="/">
                    <img
                      className="w-full"
                      src="images/yss_new_logo4x.svg"
                      alt="Site Logo"
                    />
                    <span>Soberlistic</span>
                  </Link>
                </div>
                {/* -------- */}
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 mt-5">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                      <div className="mt-2">
                        <p className="block mt-2 text-base font-light text-center text-gray-700">
                          We sent a One Time Password (OTP) to Your No.
                        </p>
                        <form onSubmit={this.onSubmit} className="otp__form">
                          <div className="flex px-16 mt-6">
                            <input
                              type="number"
                              className="h-16 text-center border-2 m-auto"
                              onChange={this.handleChange}
                              onKeyDown={(e) => this.limitText(e)}
                              onKeyUp={(e) => this.limitText(e)}
                            />
                          </div>
                          {/* {this.state.err ? ( 
                            <p className="err-message mx-auto">{this.state.err}</p>
                           ) : null} */}
                          <div className="px-6 mt-6">
                            <button
                              type="submit"
                              className="block w-full px-6 py-3 text-white uppercase bg-blue-500 rounded-lg shadow-lg focus:bg-blue-600 hover:bg-blue-600"
                            >
                              {this.props.spinnerStatus ? (
                                <LoadingSpinner />
                              ) : (
                                "Continue"
                              )}
                            </button>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
});

export default connect(mapStateToProps, actions)(OtpModal);
