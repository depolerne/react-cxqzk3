import React from "react";
import {
  withGoogleMap,
  GoogleMap,
  withScriptjs,
  InfoWindow,
  Marker,
} from "react-google-maps";
import Geocode from "react-geocode";
import Autocomplete from "react-google-autocomplete";

Geocode.setApiKey(__GOOGLE_MAP_KEY__);
Geocode.enableDebug();

class MapInput extends React.Component {
  state = {
    address: "",
    city: "",
    area: "",
    state: "",
    zoom: 15,
    map: {
      lat: 0,
      lng: 0,
    },
    marker: {
      lat: 0,
      lng: 0,
    },
  };

  componentDidMount() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.setState(
          {
            map: {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            },
            marker: {
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            },
          },
          () => {
            Geocode.fromLatLng(
              position.coords.latitude,
              position.coords.longitude
            ).then(
              (response) => {
                const address = response.results[0].formatted_address,
                  addressArray = response.results[0].address_components;
                this.setState({
                  address: address ? address : "",
                });
              },
              (error) => {
                console.error(error);
              }
            );
          }
        );
      });
    } else {
      console.error("Geolocation is not supported by this browser!");
    }
  }

  shouldComponentUpdate(nextProp, nextState) {
    return this.state === nextState ? false : true;
  }

  onMarkerDragEnd = (event) => {
    let newLat = event.latLng.lat(),
      newLng = event.latLng.lng();

    Geocode.fromLatLng(newLat, newLng).then(
      (response) => {
        const address = response.results[0].formatted_address;
        this.setState({
          address: address ? address : "",
          marker: {
            lat: newLat,
            lng: newLng,
          },
          map: {
            lat: newLat,
            lng: newLng,
          },
        });
        this.props.fireData(address, newLat, newLng);
      },
      (error) => {
        console.error(error);
      }
    );
  };

  onPlaceSelected = (place) => {
    const address = place.formatted_address,
      latValue = place.geometry.location.lat(),
      lngValue = place.geometry.location.lng();
    // Set these values in the state.
    this.setState({
      address: address ? address : "",
      marker: {
        lat: latValue,
        lng: lngValue,
      },
      map: {
        lat: latValue,
        lng: lngValue,
      },
    });
    this.props.fireData(address, latValue, lngValue);
  };

  render() {
    console.log("rendered");
    const AsyncMap = withScriptjs(
      withGoogleMap((props) => (
        <GoogleMap
          defaultZoom={this.state.zoom}
          defaultCenter={{
            lat: this.state.map.lat,
            lng: this.state.map.lng,
          }}
        >
          {/* InfoWindow on top of marker */}

          {/*Marker*/}
          <Marker
            google={this.props.google}
            name={"Dolores park"}
            draggable={true}
            onDragEnd={this.onMarkerDragEnd}
            position={{
              lat: this.state.marker.lat,
              lng: this.state.marker.lng,
            }}
          />
          <InfoWindow
            onClose={this.onInfoWindowClose}
            position={{
              lat: this.state.marker.lat + 0.0018,
              lng: this.state.marker.lng,
            }}
          >
            <div>
              <span style={{ padding: 0, margin: 0 }}>
                {this.state.address}
              </span>
            </div>
          </InfoWindow>
          <Marker />

          {/* For Auto complete Search Box */}
          <Autocomplete
            style={{
              width: "100%",
              height: "40px",
              paddingLeft: "16px",
              marginTop: "5px",
              marginBottom: "2rem",
              border: "1px solid #34558b",
            }}
            onPlaceSelected={this.onPlaceSelected}
            types={["(regions)"]}
          />
        </GoogleMap>
      ))
    );

    return (
      <div style={{ padding: "1rem", margin: "0 auto", maxWidth: 1000 }}>
        {/* <Descriptions bordered>
                    <Descriptions.Item label="Address">{this.state.address}</Descriptions.Item>
                </Descriptions> */}

        <AsyncMap
          googleMapURL={`https://maps.googleapis.com/maps/api/js?key=${__GOOGLE_MAP_KEY__}&libraries=places`}
          loadingElement={<div style={{ height: `80%` }} />}
          containerElement={<div style={{ height: this.props.height }} />}
          mapElement={<div style={{ height: `100%` }} />}
        />
      </div>
    );
  }
}

export default MapInput;
