import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import auth from '../../helpers/auth';

export class InsightBlock extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      link:this.props.clickURL
    };
  }

  render() {
    
    return (
      <Fragment>
        <div className="insightBlock__section">
          <div className={this.props.text==='Revenue' ? 'static-blocks-data' : 'static-blocks-data'}>
            <h3> 
              {this.props.heading}
              <Link to={this.props.text==='Appointments' ? (auth.getUserType()==='counsellor' ? '/coach/dashboard/appointments' :'/dashboard/appointments'):'#' } className="block text_nav_blue">{this.props.text}</Link>
            </h3>
            <p className="numbers">{this.props.insightData}</p>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default InsightBlock;