import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import auth from "../../helpers/auth";
import { connect } from "react-redux";
import { actions } from "../../routes/selectWrapper/modules/select";
import { CircularProgressbar, buildStyles } from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import ReactTooltip from "react-tooltip";
import WaitingPopUp from "../WaitiingPopUp/WaitingPopUp";
import { bindActionCreators } from "redux";
import { socket } from "../../helpers/socketHelper";

let audio;

export class NotificationBar extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      play: false,
      count: 5,
    };
    //this.Reject = this.Reject.bind(this);
    //this.Accept = this.Accept.bind(this);
    this.playAudio = this.playAudio.bind(this);
    this.handleRead = this.handleRead.bind(this);
    audio = new Audio("audio/skype-23266.mp3");
  }

  componentDidMount() {
    socket.on("payment_notification", (count) => {
      this.props.setReadCount(count);
    });
    let { currentPage } = this.props.NotificationState.notifications;
    this.props.fetchNotification(currentPage, 1);
    audio.addEventListener("ended", () => this.setState({ play: false }));
    let { waitingList } = this.props.selectState;
    if (waitingList.length > 0) {
      this.playAudio();
    } else if (waitingList === 0) {
      this.playAudio();
    }
  }

  handleRead() {
    let { currentPage } = this.props.NotificationState.notifications;
    this.props.fetchNotification(currentPage, 2);
  }

  playAudio() {
    this.setState({ play: !this.state.play }, () => {
      this.state.play ? audio.play() : audio.pause();
    });
  }

  render() {
    let { waitingList, userData } = this.props.selectState;
    let { read_count } = this.props.NotificationState;
    return (
      <Fragment>
        <div className="user__dashboard">
          <div className="top_header">
            {/* -------------Profile Progress Bar ------------ */}
            {auth.getUserType() === "counsellor" ? (
              <Fragment>
                <div className="w-12 h-12 progress__circle" data-tip data-for="profile-tip">
                  {userData.profile_percentage && (
                    <CircularProgressbar
                      value={userData.profile_percentage}
                      text={`${userData.profile_percentage}%`}
                      styles={buildStyles({
                        textSize: "25px",
                      })}
                    />
                  )}
                </div>
                <ReactTooltip id="profile-tip" place="top" effect="solid">
                  Progress Bar for Profile completion.
                </ReactTooltip>
              </Fragment>
            ) : null}
            {/* --------------------------------------------- */}
            {waitingList.length
              ? waitingList.map((item, i) => (
                  <WaitingPopUp
                    key={i}
                    name={item.username}
                    clickEvent={() =>
                      this.props.Reject(item)
                    }
                    acceptEvent={() =>
                      this.props.Accept(item)
                    }
                    avatar={item.avatar}
                  />
                ))
              : null}
            <div className="noti__block">
              <span className="leading-5">
                You have {read_count} New
                <br />
                notifications
              </span>
              <Link
                onClick={this.handleRead}
                to={
                  auth.getUserType() === "User"
                    ? "/dashboard/notifications"
                    : "/coach/dashboard/notifications"
                }
              >
                <svg
                  className="h-8 w-8"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M15 17H20L18.5951 15.5951C18.2141 15.2141 18 14.6973 18 14.1585V11C18 8.38757 16.3304 6.16509 14 5.34142V5C14 3.89543 13.1046 3 12 3C10.8954 3 10 3.89543 10 5V5.34142C7.66962 6.16509 6 8.38757 6 11V14.1585C6 14.6973 5.78595 15.2141 5.40493 15.5951L4 17H9M15 17V18C15 19.6569 13.6569 21 12 21C10.3431 21 9 19.6569 9 18V17M15 17H9"
                    stroke="#34558b"
                    strokeWidth={1}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                {/* <svg>

            <img src="images/notification_icon.svg" alt="Site Logo" />
            </svg> */}
                {read_count == 0 ? null : (
                  <span className="noti__number">{read_count}</span>
                )}
              </Link>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapDispatchToProps = (dispatch) => ({
  dispatch,
  ...bindActionCreators(actions, dispatch),
});

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CDashboardState: state.CDashboardState,
  NotificationState: state.NotificationState,
});

export default connect(mapStateToProps, mapDispatchToProps)(NotificationBar);
