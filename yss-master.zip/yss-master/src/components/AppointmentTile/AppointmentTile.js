import React, { Fragment } from "react";
import { Link } from "react-router-dom";

const AppointmentTile = ({
  user_name,
  slot,
  booking_date,
  location,
  user_type,
  cancelEvent,
  status,
  id
}) => {
  const confirm=(Id)=>{
    
  }
  return (
    <Fragment>
      
    </Fragment>
  );
};

export default AppointmentTile;
