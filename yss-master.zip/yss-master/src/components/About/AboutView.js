import React, { Fragment } from "react";
import { Link } from "react-router-dom";

class AboutView extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    let body = document.body;
    body.className = "what_we_do";
  }

  render() {
    return (
      <Fragment>
        <div className="main-content yss-site--main__content content__homepage">
          <div className="main-site__content">
            <div className="site__top-banner md:flex md:flex-wrap w-full relative items-center"
            style={{
              backgroundImage: 'url(/images/new_yss/about-banner-bg.jpg)',
            }}>
              <div className="banner__contents relative z-20 w-11/12 mx-auto md:w-2/3">
                <div className="section__title banner__title mb-6">
                  <h1 className="text-white">SoberListic</h1>
                </div>
                <div className="site__text">
                  <p>Soberlistic was developed to help those in need of connection to experts.</p> 
                  <p>Addiction is usually a symptom, and as such we aim to help you find the cause.</p>
                </div>
                <div className="btn banner__btn site__btn">
                  <a className="btn-blue" href="/find-your-coach">
                    Search Now
                  </a>
                </div>
              </div>
            </div>   
            
            <div className="section--wrapper wrapper--feed-section">
              <div className="section--width section--bg-style bg-white neg-t-margin">
                <div className="section--content">
                  <div className="section--feeds">
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/search-icon.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Search</p>
                        </div>
                        <div className="feed--text">
                          <p>Search through our experts to find the perfect person to help you on your journey, it’s never too early to begin.</p>
                        </div>
                      </div>
                    </div>
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/book-icon.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Book</p>
                        </div>
                        <div className="feed--text">
                          <p>Once you have found your perfect support it’s time to make a booking. Click ‘book now’ to book your first session.</p>
                        </div>
                      </div>
                    </div>
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/heart-icon.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Begin</p>
                        </div>
                        <div className="feed--text">
                          <p>The exciting part, start working with your new support in your very own safe space. We’re sure you will love the experience.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>  
            </div>

            <div className="section--wrapper wrapper--media-section">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--media">
                    <div className="media--body">
                      <div className="media--title section--title">
                        <h2>Holistic, coolistic, soberlistic</h2>
                      </div>
                      <div className="media--text">
                        <p>Our director suffered from chronic alcoholism for over a decade. It took years, multiple hospital admissions, and 2 rehabs to finally find the tools needed to get sober! And, even then, still relapsed.</p>
                        <p>A couple more years passed and finally what had been learned took hold and stuck. But, the problem didn’t end there… He had learned how not to drink, but now he had to learn how to live. This is why we advocate treating the cause so that we may enjoy our life free of addiction, but more importantly free of the thing that caused the problem in the first place.</p>
                      </div>
                      <div className="media--btn btn site__btn">
                        <a className="btn-blue" href="/find-your-coach">Get Help Now</a>
                      </div>
                    </div>
                    <div className="media--item">
                      <img src="/images/new_yss/media-1-1.jpg" />
                    </div>
                  </div>
                </div>
              </div>  
            </div> 

            <div className="section--wrapper wrapper--feed-section feed--section-style--1 section--bg-style grey--light__exbg">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--title">
                    <h2>How we will help</h2>
                  </div>
                  <div className="section--text">
                    <p>Soberlistic is a holistic approach that means providing support that looks at the whole person, not just their symptoms. Recovery from addiction is so much more than stopping using a substance.</p>
                  </div>
                  <div className="section--feeds">
                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-1.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Recovery Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>Everyone needs help from time to time, and it really does help to talk to a professional.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>

                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-2.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Fitness Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>Fitness plays a huge part in mental health, and we know how har it can be to get motivated.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-3.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Nutritional Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>Good nutrition can create an amazing change both physically and emotionally.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-4.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Wellness Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>We have wellness experts ready to help you, from yoga to meditation.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="section--wrapper wrapper--media-section">
              <div className="section--width">
                <div className="section--content">
                  <div className="blockquote--section section--media">
                    <div className="media--body">
                      <blockquote>
                        <span className="quote__icon">
                          <img src="/images/new_yss/5.svg" />
                        </span>
                        <p>Addiction treatment has a failure rate of over 90%. A major reason for this is that treatment fails to identify addictive behaviors as symptoms of an underlying problem.</p>
                        <figcaption>– Soberlistic</figcaption>
                      </blockquote>
                    </div>
                    <div className="media--item">
                      <figure>
                        <img src="/images/new_yss/media-2-1.jpg" />
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="section--wrapper wrapper--feed-section feed--section-style--2 section--bg-style grey--light__exbg">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--title">
                    <h2>Our Experience is How We Help</h2>
                  </div>
                  <div className="section--text">
                    <p>Experiential knowledge is when you are taught something from people who know the subject which comes from a person’s personal experiences, in conjunction with professional training.</p>
                  </div>
                  <div className="section--feeds">
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/4.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Experiential <br/> Knowledge</p>
                        </div>
                        <div className="feed--text">
                          <p>Our coaches have ‘lived experience’ which helps them understand & help</p>
                        </div>
                      </div>
                    </div>

                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/3.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Worldwide <br /> Coaches</p>
                        </div>
                        <div className="feed--text">
                          <p>Coaches from all over the world helping with diversity to give you the best support</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/2.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Affordable <br /> Support</p>
                        </div>
                        <div className="feed--text">
                          <p>You control the cost by having as many sessions as you need in soberlistic</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/1.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>24/7 <br /> Sessions</p>
                        </div>
                        <div className="feed--text">
                          <p>We have coaches in several countries working in different time zones</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="btn site__btn">
                    <a className="btn-blue" href="/find-your-coach">
                      Search Now
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="section--wrapper wrapper--media-section">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--media">
                    <div className="media--body">
                      <div className="media--title section--title max-w-34">
                        <h2>Let's find the cause, and work on that!</h2>
                      </div>
                      <div className="media--text">
                        <p>The need for love and connection is a fundamental human desire.</p>
                        <p>People who are addicted to substances or behaviors often feel disconnected from others, which can lead them into isolation.</p>
                        <p>The good news is that people can recover from the causes of addiction and go on to have happy lives full of meaningful relationships with partners, friends, and family members, we did it, you can too.</p>
                      </div>
                      <div className="media--btn btn site__btn">
                        <a className="btn-blue" href="/find-your-coach">Start Today</a>
                      </div>
                    </div>
                    <div className="media--item">
                      <img src="/images/new_yss/media-3-1.jpg" />
                    </div>
                  </div>
                </div>
              </div>  
            </div> 

          </div>
        </div>
      </Fragment>
    );
  }
}

export default AboutView;
