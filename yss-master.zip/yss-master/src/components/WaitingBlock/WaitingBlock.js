import React, { Fragment } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import { actions } from "../../routes/selectWrapper/modules/select";

export class WaitingBlock extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <Fragment>
        <div className="clearfix user-detail">
          <div className="svg_user_icon">
          <img src='images/profile_black_icon.svg' className="w-4"/>
          </div>
          <div className="float-left">
            <p>{this.props.userName}</p>
          </div>
          <div className="float-right">
            <Link to="/startSession/session" onClick={this.props.AcceptEvent}>
              Accept
            </Link>
          </div>
        </div>
      </Fragment>
    );
  }
}

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CDashboardState: state.CDashboardState,
});

export default connect(mapStateToProps, actions)(WaitingBlock);
