import React, { Fragment } from "react";
import "./style.css";

export const Spinner = ({text}) => {
  if(!text){
    text='Loading...'
  }
  return (
    <div className="spinner">
      <h4>{text==='' ? 'Loading...': text }</h4>
      <div className="bounce1"></div>
      <div className="bounce2"></div>
      <div className="bounce3"></div>
    </div>
  );
};

export default Spinner;