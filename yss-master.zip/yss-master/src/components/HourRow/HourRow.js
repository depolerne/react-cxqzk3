import React, { Fragment } from "react";
import { Link } from "react-router-dom";

const HourRow = ({
    dayname,handleChange,openid,closeid,from,to
}) => {
    if(from===undefined){
        var from='openAt'
    }
    if(to===undefined){
        var to='closeAt'
    }
    return (
        <div className="slots_row">
            <div className="first_slot slots">
                <select
                name="open"
                className={dayname}
                onChange={handleChange}
                id={openid}
                defaultValue={from}
                >
                <option value='-1'>Select time</option>
                <option>00:00 AM</option>
                <option>00:15 AM</option>
                <option>00:30 AM</option>
                <option>00:45 AM</option>
                <option>01:00 AM</option>
                <option>01:15 AM</option>
                <option>01:30 AM</option>
                <option>01:45 AM</option>
                <option>02:00 AM</option>
                <option>02:15 AM</option>
                <option>02:30 AM</option>
                <option>02:45 AM</option>
                <option>03:00 AM</option>
                <option>03:15 AM</option>
                <option>03:30 AM</option>
                <option>03:45 AM</option>
                <option>04:00 AM</option>
                <option>04:15 AM</option>
                <option>04:30 AM</option>
                <option>04:45 AM</option>
                <option>05:00 AM</option>
                <option>05:15 AM</option>
                <option>05:30 AM</option>
                <option>05:45 AM</option>
                <option>06:00 AM</option>
                <option>06:15 AM</option>
                <option>06:30 AM</option>
                <option>06:45 AM</option>
                <option>07:00 AM</option>
                <option>07:15 AM</option>
                <option>07:30 AM</option>
                <option>07:45 AM</option>
                <option>08:00 AM</option>
                <option>08:15 AM</option>
                <option>08:30 AM</option>
                <option>08:45 AM</option>
                <option>09:00 AM</option>
                <option>09:15 AM</option>
                <option>09:30 AM</option>
                <option>09:45 AM</option>
                <option>10:00 AM</option>
                <option>10:15 AM</option>
                <option>10:30 AM</option>
                <option>10:45 AM</option>
                <option>11:00 AM</option>
                <option>11:15 AM</option>
                <option>11:30 AM</option>
                <option>11:45 AM</option>
                <option>12:00 PM</option>
                <option>12:15 PM</option>
                <option>12:30 PM</option>
                <option>12:45 PM</option>
                <option>01:00 PM</option>
                <option>01:15 PM</option>
                <option>01:30 PM</option>
                <option>01:45 PM</option>
                <option>02:00 PM</option>
                <option>02:15 PM</option>
                <option>02:30 PM</option>
                <option>02:45 PM</option>
                <option>03:00 PM</option>
                <option>03:15 PM</option>
                <option>03:30 PM</option>
                <option>03:45 PM</option>
                <option>04:00 PM</option>
                <option>04:15 PM</option>
                <option>04:30 PM</option>
                <option>04:45 PM</option>
                <option>05:00 PM</option>
                <option>05:15 PM</option>
                <option>05:30 PM</option>
                <option>05:45 PM</option>
                <option>06:00 PM</option>
                <option>06:15 PM</option>
                <option>06:30 PM</option>
                <option>06:45 PM</option>
                <option>07:00 PM</option>
                <option>07:15 PM</option>
                <option>07:30 PM</option>
                <option>07:45 PM</option>
                <option>08:00 PM</option>
                <option>08:15 PM</option>
                <option>08:30 PM</option>
                <option>08:45 PM</option>
                <option>09:00 PM</option>
                <option>09:15 PM</option>
                <option>09:30 PM</option>
                <option>09:45 PM</option>
                <option>10:00 PM</option>
                <option>10:15 PM</option>
                <option>10:30 PM</option>
                <option>10:45 PM</option>
                <option>11:00 PM</option>
                <option>11:15 PM</option>
                <option>11:30 PM</option>
                <option>11:45 PM</option>
                </select>
            </div>
            
            <div className="second_slot slots">
                <select
                name="close"
                className={dayname}
                onChange={handleChange}
                id={closeid}
                defaultValue={to}
                >
                <option value='-1'>Select time</option>
                <option>00:00 AM</option>
                <option>00:15 AM</option>
                <option>00:30 AM</option>
                <option>00:45 AM</option>
                <option>01:00 AM</option>
                <option>01:15 AM</option>
                <option>01:30 AM</option>
                <option>01:45 AM</option>
                <option>02:00 AM</option>
                <option>02:15 AM</option>
                <option>02:30 AM</option>
                <option>02:45 AM</option>
                <option>03:00 AM</option>
                <option>03:15 AM</option>
                <option>03:30 AM</option>
                <option>03:45 AM</option>
                <option>04:00 AM</option>
                <option>04:15 AM</option>
                <option>04:30 AM</option>
                <option>04:45 AM</option>
                <option>05:00 AM</option>
                <option>05:15 AM</option>
                <option>05:30 AM</option>
                <option>05:45 AM</option>
                <option>06:00 AM</option>
                <option>06:15 AM</option>
                <option>06:30 AM</option>
                <option>06:45 AM</option>
                <option>07:00 AM</option>
                <option>07:15 AM</option>
                <option>07:30 AM</option>
                <option>07:45 AM</option>
                <option>08:00 AM</option>
                <option>08:15 AM</option>
                <option>08:30 AM</option>
                <option>08:45 AM</option>
                <option>09:00 AM</option>
                <option>09:15 AM</option>
                <option>09:30 AM</option>
                <option>09:45 AM</option>
                <option>10:00 AM</option>
                <option>10:15 AM</option>
                <option>10:30 AM</option>
                <option>10:45 AM</option>
                <option>11:00 AM</option>
                <option>11:15 AM</option>
                <option>11:30 AM</option>
                <option>11:45 AM</option>
                <option>12:00 PM</option>
                <option>12:15 PM</option>
                <option>12:30 PM</option>
                <option>12:45 PM</option>
                <option>01:00 PM</option>
                <option>01:15 PM</option>
                <option>01:30 PM</option>
                <option>01:45 PM</option>
                <option>02:00 PM</option>
                <option>02:15 PM</option>
                <option>02:30 PM</option>
                <option>02:45 PM</option>
                <option>03:00 PM</option>
                <option>03:15 PM</option>
                <option>03:30 PM</option>
                <option>03:45 PM</option>
                <option>04:00 PM</option>
                <option>04:15 PM</option>
                <option>04:30 PM</option>
                <option>04:45 PM</option>
                <option>05:00 PM</option>
                <option>05:15 PM</option>
                <option>05:30 PM</option>
                <option>05:45 PM</option>
                <option>06:00 PM</option>
                <option>06:15 PM</option>
                <option>06:30 PM</option>
                <option>06:45 PM</option>
                <option>07:00 PM</option>
                <option>07:15 PM</option>
                <option>07:30 PM</option>
                <option>07:45 PM</option>
                <option>08:00 PM</option>
                <option>08:15 PM</option>
                <option>08:30 PM</option>
                <option>08:45 PM</option>
                <option>09:00 PM</option>
                <option>09:15 PM</option>
                <option>09:30 PM</option>
                <option>09:45 PM</option>
                <option>10:00 PM</option>
                <option>10:15 PM</option>
                <option>10:30 PM</option>
                <option>10:45 PM</option>
                <option>11:00 PM</option>
                <option>11:15 PM</option>
                <option>11:30 PM</option>
                <option>11:45 PM</option>
                </select>
            </div>
            {/* <a className="time_delete" href="/"/> */}
        </div>
    );
};

export default HourRow;