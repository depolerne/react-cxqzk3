import React, { Fragment } from 'react';

export const NotificationTile=({})=>{
    return (
        <Fragment>
            <li className="list-item">
                                        <a
                                            href="#"
                                            className="close_btn"
                                        />
                                        <a
                                            href="#"
                                            className="list_btn"
                                        >
                                            New Appointment
                                        </a>
                                        <div className="list_detail">
                                            <div className="list_content">
                                                <p>
                                                    You have a New Appointment
                                                    on{" "}
                                                    <span>
                                                        03rd August, 2020
                                                    </span>{" "}
                                                    at <span>10:30 AM</span>
                                                </p>
                                                <p>
                                                    <span>Patient Name</span> on
                                                    Video Call
                                                </p>
                                            </div>
                                            <div className="list_highlight">
                                                <p>
                                                    16th July, 2020 at 8:40 PM
                                                </p>
                                            </div>
                                        </div>
                                    </li>
        </Fragment>
    )
}
