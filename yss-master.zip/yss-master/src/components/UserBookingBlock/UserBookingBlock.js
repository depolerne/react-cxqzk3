import React, { Fragment } from "react";

export class UserBookingBlock extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <Fragment>
        <div className="clearfix user-detail pointer-events-none">
          <div className="float-left">
            <p className="doc_name">
              {this.props.dr_name}
              <span className="doc_desgi">{this.props.Dr_type}</span>
            </p>
          </div>
          <div className="float-right">
            <p className="book_date">
              {this.props.booking_date}
              <span className="book_time">{this.props.time_slot}</span>
            </p>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default UserBookingBlock;
