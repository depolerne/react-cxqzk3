import React, { Fragment } from "react";
import { Link } from "react-router-dom";

class HowThisWorks extends React.Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    let body = document.body;
    body.className = "how_this_work";
  }

  render() {
    return (
      <Fragment>
        <div className="main-content yss-site--main__content content__homepage">
          <div className="main-site__content">
            <div className="site__top-banner md:flex md:flex-wrap w-full relative items-center"
            style={{
              backgroundImage: 'url(/images/new_yss/home-banner-bg.jpg)',
            }}>
              <div className="banner__contents relative z-20 w-11/12 mx-auto md:w-2/3">
                <div className="section__title banner__title mb-6">
                  <h1 className="text-white">Online Coaching</h1>
                </div>
                <div className="site__text">
                  <p>Online coaching for mental health, fitness, nutrition, addiction & much more…</p> 
                  <p>All online, via your webcam, in Soberlistic.</p>
                </div>
                <div className="btn banner__btn site__btn">
                  <a className="btn-blue" href="/find-your-coach">
                    Search Now
                  </a>
                </div>
              </div>
            </div>   
            
            <div className="section--wrapper wrapper--feed-section">
              <div className="section--width section--bg-style bg-white neg-t-margin">
                <div className="section--content">
                  <div className="section--feeds">
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/search-icon.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Search</p>
                        </div>
                        <div className="feed--text">
                          <p>Search through our experts to find the perfect person to help you on your journey, it’s never too early to begin.</p>
                        </div>
                      </div>
                    </div>
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/book-icon.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Book</p>
                        </div>
                        <div className="feed--text">
                          <p>Once you have found your perfect support it’s time to make a booking. Click ‘book now’ to book your first session.</p>
                        </div>
                      </div>
                    </div>
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/heart-icon.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Begin</p>
                        </div>
                        <div className="feed--text">
                          <p>The exciting part, start working with your new support in your very own safe space. We’re sure you will love the experience.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>  
            </div>

            <div className="section--wrapper wrapper--media-section">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--media">
                    <div className="media--body">
                      <div className="media--title section--title">
                        <h2>Do you need help with addiction recovery?</h2>
                      </div>
                      <div className="media--text">
                        <p>Online Recovery Coaching offers a way to provide support and guidance to those who are struggling with addictions.</p>
                        <p>Our experts have helped many individuals find hope again by providing them with one-on-one care through their own devices, in their safe space.</p>
                        <p>Search our experts, book an appointment and have your session through our amazing new platform.</p>
                      </div>
                      <div className="media--btn btn site__btn">
                        <a className="btn-blue" href="/find-your-coach">Search Now</a>
                      </div>
                    </div>
                    <div className="media--item">
                      <img src="/images/new_yss/media-1.jpg" />
                    </div>
                  </div>
                </div>
              </div>  
            </div> 

            <div className="section--wrapper wrapper--feed-section feed--section-style--1 section--bg-style grey--light__exbg">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--title">
                    <h2>How we can help</h2>
                  </div>
                  <div className="section--text">
                    <p>Recovery from addiction is so much more than stopping using a substance. Soberlistic is a holistic approach that means providing support that looks at the whole person, not just their symptoms.</p>
                  </div>
                  <div className="section--feeds">
                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-1.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Recovery Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>Everyone needs help from time to time, and it really does help to talk to a professional.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>

                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-2.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Fitness Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>Fitness plays a huge part in mental health, and we know how har it can be to get motivated.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-3.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Nutritional Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>Good nutrition can create an amazing change both physically and emotionally.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--item">
                        <img src="/images/new_yss/feed-4.jpg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Wellness Coaching</p>
                        </div>
                        <div className="feed--text">
                          <p>We have wellness experts ready to help you, from yoga to meditation.</p>
                        </div>
                        <div className="feed--btn">
                          <a href="/find-your-coach">Search Now</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="section--wrapper wrapper--media-section">
              <div className="section--width">
                <div className="section--content">
                  <div className="blockquote--section section--media">
                    <div className="media--body">
                      <blockquote>
                        <span className="quote__icon">
                          <img src="/images/new_yss/5.svg" />
                        </span>
                        <p>Our coaches will provide accountability, support and guidance as well as help to create an action plan for healthy living...</p>
                        <figcaption>– Soberlistic</figcaption>
                      </blockquote>
                    </div>
                    <div className="media--item">
                      <figure>
                        <img src="/images/new_yss/media-2.jpg" />
                      </figure>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="section--wrapper wrapper--feed-section feed--section-style--2 section--bg-style grey--light__exbg">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--title">
                    <h2>Our experience is how we help</h2>
                  </div>
                  <div className="section--text">
                    <p>Experiential knowledge is when you are taught something from people who know the subject which comes from a person’s personal experiences, in conjunction with professional training.</p>
                  </div>
                  <div className="section--feeds">
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/4.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Experiential <br/> Knowledge</p>
                        </div>
                        <div className="feed--text">
                          <p>Our coaches have ‘lived experience’ which helps them understand & help</p>
                        </div>
                      </div>
                    </div>

                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/3.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Worldwide <br /> Coaches</p>
                        </div>
                        <div className="feed--text">
                          <p>Coaches from all over the world helping with diversity to give you the best support</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/2.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>Affordable <br /> Support</p>
                        </div>
                        <div className="feed--text">
                          <p>You control the cost by having as many sessions as you need in Soberlistic</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="section--feed-item">
                      <div className="feed--icon">
                        <img src="/images/new_yss/1.svg" />
                      </div>
                      <div className="feed--body">
                        <div className="feed--title">
                          <p>24/7 <br /> Sessions</p>
                        </div>
                        <div className="feed--text">
                          <p>We have coaches in several countries working in different time zones</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="btn site__btn">
                    <a className="btn-blue" href="/find-your-coach">
                      Search Now
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="section--wrapper wrapper--media-section">
              <div className="section--width">
                <div className="section--content">
                  <div className="section--media">
                    <div className="media--body">
                      <div className="media--title section--title max-w-34">
                        <h2>Connection will create change</h2>
                      </div>
                      <div className="media--text">
                        <p>A survey of more than 17,000 people in the United States found that 80% had no one to talk to about personal problems.</p>
                        <p>Forty-two percent said they didn’t have anyone they could discuss important issues with or ask for support.</p>
                        <p>More than 50% of those surveyed said they had no one to help them celebrate life’s victories. Begin your journey today with soberlistic and find the very best coaches who will help you find true happiness.</p>
                      </div>
                      <div className="media--btn btn site__btn">
                        <a className="btn-blue" href="/find-your-coach">Search Now</a>
                      </div>
                    </div>
                    <div className="media--item">
                      <img src="/images/new_yss/media-3.jpg" />
                    </div>
                  </div>
                </div>
              </div>  
            </div> 

          </div>
        </div>
      </Fragment>
    );
  }
}

export default HowThisWorks;
