import React, { Fragment } from "react";
import { Link } from "react-router-dom";

export class BookingTab extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <Fragment>
        <div className="clearfix user-detail pointer-events-none">
          <div className="svg_user_icon">
          <img src='images/profile_black_icon.svg' className="w-4"/>  
          </div>
          <div className="float-left">
            <p>{this.props.user_name}</p>
          </div>
          <div className="float-right lowercase">
            <Link to="#">{this.props.slot_time}</Link>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default BookingTab;