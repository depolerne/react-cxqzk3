import React, { Fragment } from "react";
import ModalBody from "../Modals/ModalBody";
import { actions } from "../../routes/SearchNow/modules/SearchNow";
import { connect } from "react-redux";
import ReactStars from "react-rating-stars-component";
import { Link } from "react-router-dom";

class ClusterModal extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    let { selectedCluster } = this.props.searchNowState;
    return (
      <Fragment>
        <ModalBody closeEvent={() => this.props.setClusterModal(false)}>
          {selectedCluster.map((item) => (
            <Link to={`/listing/${item.id}`} key={item.id}>
            <div className="max-w-md mr-4 bg-white justify-between rounded-xl shadow-md space-y-2 flex items-center sm:space-y-0">
              <div className="space-y-2 text-left">
                <div className="space-y-0.5 leading-6">
                 <p className="text-lg text-black font-semibold">
                    {item.listing_name}
                  </p>                  
                  <div className='flex map-star-ratings'>
                    <ReactStars
                      size={5}
                      edit={false}
                      isHalf={true}
                      value={parseFloat(item.avg_rating).toFixed(2)}
                      />
                    {/* {item.avg_rating ? (<h1 className='text-yellow-600 font-bold text-xl my-auto'>{'('+(parseFloat(item.avg_rating).toFixed(1))+')'}</h1>)
                    : <h1 className='text-gray-600 font-bold text-sm leading-none my-auto'>{'('+0+')'}</h1>} */}
                  </div>
                  <p className="font-medium map-text-cate">
                    {item.listing_category.category_name}
                  </p>
                  <p className="font-medium">{item.location}</p>
                </div>
              </div>
              <div className="mapmodal__image">
                <img
                className="block mx-auto h-24 rounded-full sm:mx-0 sm:flex-shrink-0"
                src={
                  item.cover_img
                  ? __IMG_URL__ + item.cover_img
                  : "/images/dark_user_icon.svg"
                }
                alt="Woman's Face"
                />
              </div>
            </div>
          </Link>
          ))}
        </ModalBody>
      </Fragment>
      );
    }
  }
  
  const mapStateToProps = (state) => ({
    selectState: state.selectState,
    searchNowState: state.searchNowState,
  });
  
  export default connect(mapStateToProps, actions)(ClusterModal);
