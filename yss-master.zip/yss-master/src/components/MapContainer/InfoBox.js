import React, { Fragment } from "react";
import ReactStars from "react-rating-stars-component";
import { BrowserRouter, Link } from "react-router-dom";

export class InfoBox extends React.Component {
  constructor(props) {
    super(props);
  }
  render() {
    const { data } = this.props;
    console.log(this.props);

    return (
      <Fragment>
        {data && (
          <div className="max-w-sm mx-auto bg-white rounded-xl shadow-md space-y-2 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
            <img
              className="block mx-auto h-24 rounded-full sm:mx-0 sm:flex-shrink-0"
              src={
                data.cover_img
                  ? __IMG_URL__ + data.cover_img
                  : "/images/dark_user_icon.svg"
              }
              alt="Woman's Face"
            />
            <div className="text-center space-y-2 sm:text-left">
              <div className="space-y-0.5 leading-6">
                <p className="text-lg text-black font-semibold">
                  {data.listing_name}
                </p>
                <p className="text-gray-700 font-medium">
                  {data.listing_category.category_name}
                </p>
                <p className="text-gray-700 font-medium">{data.location}</p>
                {<ReactStars
                  size={10}
                  edit={false}
                  isHalf={true}
                  value={parseFloat(data.avg_rating).toFixed(2)}
                />}
              </div>
          </div>
            </div>
        )}
      </Fragment>
    );
  }
}

export default InfoBox;
