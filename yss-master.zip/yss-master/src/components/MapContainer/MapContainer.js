import React, { Fragment } from "react";
import { actions } from "../../routes/SearchNow/modules/SearchNow";
import { connect } from "react-redux";
import mapStyle from "./mapStyles";
import mapSilverStyle from "./mapSilverStyle";
import { Link } from "react-router-dom";

export class MapContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errClass: "",
      selectedCluster: {},
      openCluster: false,
    };
    // window.initMap=window.initMap.bind(this);
  }

  componentDidMount() {
    let {
      listings: { data },
    } = this.props.searchNowState;
    var script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${__GOOGLE_MAP_KEY__}&callback=initMap`;
    script.async = true;

    var map;

    let $ = this;
    window.initMap = function () {
      map = new google.maps.Map(document.getElementById("map"), {
        center: new google.maps.LatLng(0, 0),
        zoom: 10,
        minZoom: 2.95,
        maxZoom:18,
        mapTypeControlOptions: mapStyle.mapStyle,
        backgroundColor: 'none',
        mapTypeId: 'roadmap',
        styles:mapSilverStyle.silver,
        streetViewControl: false,
      });

      var bounds = new google.maps.LatLngBounds();
      const markers = data.map((item) => {
        let marker = new google.maps.Marker({
          position: {
            lat: parseFloat(item.lattitude),
            lng: parseFloat(item.longitude),
          },
          info: item,
          icon: "images/Location.svg",
          map: map,
        });
        bounds.extend({
          lat: parseFloat(item.lattitude),
          lng: parseFloat(item.longitude),
        });
        map.fitBounds(bounds);
        marker.addListener("mouseover", () => {
          infowindow.setContent(`
          <div class="flex_popup justify-evenly mx-auto bg-white rounded-xl shadow-md space-y-2 sm:flex sm:items-center sm:space-y-0 sm:space-x-6">
            <div class="text-center space-y-2 sm:text-left">
              <div class="space-y-0.5 leading-6">
                <p class="text-lg text-black font-semibold">
                <a href="/listing/${item.id}/${item.slug_url}" key="${item.id}">${item.listing_name}</a>
                </p>
                <p class="font-medium map-text-cate">
                <a href="/listing/${item.id}/${item.slug_url}" key="${item.id}">${ (item.listing_category) ? item.listing_category.category_name : ""}</a>
                </p>
                <p class="font-medium">${item.location}</p>
              </div>
            </div>
            <a href="/listing/${item.id}/${item.slug_url}" key="${item.id}">
            <img
            class="block mx-auto rounded-full sm:mx-0 sm:flex-shrink-0"
            src=${
              item.cover_img
                ? __IMG_URL__ + item.cover_img
                : "/images/dark_user_icon.svg"
            }
            alt="${item.listing_name}"
            /></a>
          </div>`);
          infowindow.open({
            anchor: marker,
            map,
            shouldFocus: false,
          });
        });

        marker.addListener("mouseout", () => {
          //infowindow.close();
        });
        return marker;
      });

      const infowindow = new google.maps.InfoWindow({
        content: ``,
      });

      google.maps.event.addListener(map, "dragend", function () {
        if (bounds.contains(map.getCenter())) return;

        // We're out of bounds - Move the map back within the bounds

        var c = map.getCenter(),
          x = c.lng(),
          y = c.lat(),
          maxX = bounds.getNorthEast().lng(),
          maxY = bounds.getNorthEast().lat(),
          minX = bounds.getSouthWest().lng(),
          minY = bounds.getSouthWest().lat();

        if (x < minX) x = minX;
        if (x > maxX) x = maxX;
        if (y < minY) y = minY;
        if (y > maxY) y = maxY;

        map.setCenter(new google.maps.LatLng(y, x));
      });

      let markerCluster = new MarkerClusterer(map, markers, {
        imagePath:
          "images/m"
      });

      markerCluster.setStyles(markerCluster.getStyles().map(function (style) {
          style.textColor = '#fff';
          return style;
      }));

      let clusters = [];
      google.maps.event.addListener(
        markerCluster,
        "clusterclick",
        function (cluster) {
          console.log(cluster);
          Object.keys(cluster.markerClusterer_.markersCluster_).map((i) => {
            if (cluster.markerClusterer_.prevZoom_ == 18) {
              clusters.push(data[i - 1]);
              $.props.setClusterModal(true);
              $.props.setModalClustersData(clusters);
            }
          });
          clusters = [];
        }
      );
    };
    document.head.appendChild(script);
  }

  render() {
    return (
      <Fragment>
        <div id="map"></div>
      </Fragment>
    );
  }
}

// export default GoogleApiWrapper({apiKey: __GOOGLE_MAP_KEY__})(MapContainer);

const mapStateToProps = (state) => ({
  selectState: state.selectState,
  CDashboardState: state.CDashboardState,
  NotificationState: state.NotificationState,
  searchNowState: state.searchNowState,
});

export default connect(mapStateToProps, actions)(MapContainer);
