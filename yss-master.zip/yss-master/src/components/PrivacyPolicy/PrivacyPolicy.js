import React, { Fragment } from "react";
import { Link } from "react-router-dom";

class PrivacyPolicy extends React.Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    let body = document.body;
    body.className = "privacy-policy";
  }

  render() {
    return (
      <Fragment>
        {" "}
        <div className="main-content yss-site--main__content">
          <div className="main-site__content">
            {/* <div
              className="main__top-banner"
              style={{
                backgroundImage: "url(/images/inspiration_banner-img.jpg)",
              }}
            >
              <div className="main_banner__wrapper inspiration__content page__content text-center">
                <div className="banner__title">What we do</div>
              </div>
            </div> */}
            <div className="page__content">
              {/* <div className="listing-other-details lg:flex">
                <div className="w-full lg:w-2/3 lg:pr-4">
                  <div className="information_block listing__description">
                    <div className="blog__text">
                      <div className="section--title">
                        <h2>Privacy Policy</h2>
                      </div>
                      <div className="blog__desc">
                        <p>What we do</p>
                      </div>
                      <div className="blog__btn mt-6">
                        <Link
                          to="/blog"
                          className="w-32 bg_blue text-white p-3 text-center inline-block"
                        >
                          Read More
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              </div> */}
              <div className="section--wrapper">
                <div className="section--width">
                  <div className="information_block block--para--lists">
                    <div className="block--title">
                      <h2>Privacy Policy</h2>
                    </div>
                    <div className="block--text">
                      <p><a href="https://soberlistic.com/">www.soberlistic.com</a> (the "Site") is owned and operated by Adam Jowett. Adam Jowett is the data controller and can be contacted at:</p>
                      <p className="no-margin-top"><a href="mailto:adamjowett.yss@gmail.com">adamjowett.yss@gmail.com</a> <br /> <a href="tel:07923361301">07923 361301</a> <br /> Flat 20, Manor Glade Court, Higher Warberry Road</p>
                      <p>
                        <span className="font-semibold">Purpose</span>
                        The purpose of this privacy policy (this "Privacy Policy") is to inform users of our Site of the following:
                      </p>
                      <ol>
                        <li>The personal data we will collect;</li>
                        <li>Use of collected data;</li>
                        <li>Who has access to the data collected;</li>
                        <li>The rights of Site users; and</li>
                        <li>The Site's cookie policy.</li>
                      </ol>
                      <p>This Privacy Policy applies in addition to the terms and conditions of our Site.</p>
                      <p>
                        <span className="font-semibold">GDPR</span>
                        For users in the European Union, we adhere to the Regulation (EU) 2016/679 of the European Parliament and of the Council of 27 April 2016, known as the General Data Protection Regulation (the "GDPR"). For users in the United Kingdom, we adhere to the GDPR as enshrined in the Data Protection Act 2018.
                      </p>
                      <p>
                        <span className="font-semibold">Consent</span>
                        By using our Site users agree that they consent to:
                      </p>
                      <ol>
                        <li>The conditions set out in this Privacy Policy.</li>
                      </ol>
                      <p>When the legal basis for us processing your personal data is that you have provided your consent to that processing, you may withdraw your consent at any time. If you withdraw your consent, it will not make processing which we completed before you withdrew your consent unlawful. You can withdraw your consent by: Yes by contacting the data protection officer.</p>
                      <p>
                        <span className="font-semibold">Legal Basis for Processing</span>
                        We collect and process personal data about users in the EU only when we have a legal basis for doing so under Article 6 of the GDPR.
                      </p>
                      <p>We rely on the following legal bases to collect and process the personal data of users in the EU:</p>
                      <ol>
                        <li>Users have provided their consent to the processing of their data for one or more specific purposes;</li>
                        <li>Processing of user personal data is necessary for us or a third pary to pursue a legitimate interest. Our legitimate interest is not overriden by the interests or fundamenal rights and freedoms of users. Our legitimate interest(s) are: To deliver online coaching services; and</li>
                        <li>Processing of user personal data is necessary for us to take, at the request of a user, steps before entering a contract or for the performance of a contract to which a user is a party. If a user does not provide the the personal data necessary to perform a contract the consequences are as follows: We cannot deliver coaching sessions.</li>
                      </ol>
                      <p>
                        <span className="font-semibold">Personal Data We Collect</span>
                        We only collect data that helps us achieve the purpose set out in this Privacy Policy. We will not collect any additional data beyond the data listed below without notifying you first.
                      </p>
                      <p>
                        <span className="mt-12">Data Collected Automatically</span>
                        When you visit and use our Site, we may automatically collect and store the following information:
                        <ol>
                          <li>IP address;</li>
                          <li>Location</li>
                          <li>Hardware and software details;</li>
                          <li>Clicked links; and</li>
                          <li>Content viewed.</li>
                        </ol>
                      </p>
                      <p>
                        <span>Data Collected in a Non-Automatic Way</span>
                        We may also collect the following data when you perform certain functions on our Site:
                        <ol>
                          <li>First and last name; and</li>
                          <li>Email address.</li>
                        </ol>
                      </p>
                      <p>This data may be collected using the following methods:
                        <ol>
                          <li>Creating an account.</li>
                        </ol>
                      </p>
                      <p>
                        <span className="font-semibold">How We Use Personal Data</span>
                        Data collected on our Site will only be used for the purposes specified in this Privacy Policy or indicated on the relevant pages of our Site. We will not use your data beyond what we disclose in this Privacy Policy.
                      </p>
                      <p>The data we collect automatically is used for the following purposes:
                        <ol>
                          <li>Google Analytics.</li>
                        </ol>
                      </p>
                      <p>The data we collect when the user performs certain functions may be used for the following purposes:
                        <ol>
                          <li>Only for account management and notifications relating to website.</li>
                        </ol>
                      </p>
                      <p>
                        <span className="font-semibold">Who We Share Personal Data With</span>
                        <span>Employees</span>
                        We may disclose user data to any member of our organisation who reasonably needs access to user data to achieve the purposes set out in this Privacy Policy.
                        <span className="mt-6">Other Disclosures</span>
                        We will not sell or share your data with other third parties, except in the following cases:
                        <ol>
                          <li>If the law requires it;</li>
                          <li>If it is required for any legal proceeding;</li>
                          <li>To prove or protect our legal rights; and</li>
                          <li>To buyers or potential buyers of this company in the event that we seek to sell the company.</li>
                        </ol>
                        If you follow hyperlinks from our Site to another Site, please note that we are not responsible and have no control over their privacy policies and practices.
                      </p>
                      <p>
                        <span className="font-semibold">How Long We Store Personal Data</span>
                        User data will be stored until the purpose the data was collected for has been achieved. <br />
                        You will be notified if your data is kept for longer than this period.
                      </p>
                      <p>
                        <span className="font-semibold">How We Protect Your Personal Data</span>
                        In order to protect your security, we use the strongest available browser encryption and store all of our data on servers in secure facilities. All data is only accessible to our employees. Our employees are bound by strict confidentiality agreements and a breach of this agreement would result in the employee's termination.
                      </p>
                      <p>While we take all reasonable precautions to ensure that user data is secure and that users are protected, there always remains the risk of harm. The Internet as a whole can be insecure at times and therefore we are unable to guarantee the security of user data beyond what is reasonably practical.</p>
                      <p>
                        <span className="font-semibold">Your Rights as a User</span>
                        Under the GDPR, you have the following rights:
                        <ol>
                          <li>Right to be informed;</li>
                          <li>Right of access;</li>
                          <li>Right to rectification;</li>
                          <li>Right to erasure;</li>
                          <li>Right to restrict processing;</li>
                          <li>Right to data portability; and</li>
                          <li>Right to object.</li>
                        </ol>
                      </p>
                      <p>
                        <span className="font-semibold">Children</span>
                        The minimum age to use our website is 18 years of age. We do not knowingly collect or use personal data from children under 16 years of age. If we learn that we have collected personal data from a child under 16 years of age, the personal data will be deleted as soon as possible. If a child under 16 years of age has provided us with personal data their parent or guardian may contact our data protection officer.
                      </p>
                      <p>
                        <span className="font-semibold">How to Access, Modify, Delete, or Challenge the Data Collected</span>
                        If you would like to know if we have collected your personal data, how we have used your personal data, if we have disclosed your personal data and to who we disclosed your personal data, if you would like your data to be deleted or modified in any way, or if you would like to exercise any of your other rights under the GDPR, please contact our data protection officer here:
                      </p>
                      <address>
                          Adam Jowett <br />
                          <a href="mailto:adamjowett.yss@gmail.com">adamjowett.yss@gmail.com</a> <br />
                          <a href="tel:07923361301">07923 361301</a> <br />
                          Flat 20, Manor Glade Court, Higher Warberry Road
                      </address>
                      <p>
                        <span className="font-semibold">Do Not Track Notice</span>
                        Do Not Track ("DNT") is a privacy preference that you can set in certain web browsers. We do not track the users of our Site over time and across third party websites and therefore do not respond to browser-initiated DNT signals.
                      </p>
                      <p>
                        <span className="font-semibold">Cookie Policy</span>
                        A cookie is a small file, stored on a user's hard drive by a website. Its purpose is to collect data relating to the user's browsing habits. You can choose to be notified each time a cookie is transmitted. You can also choose to disable cookies entirely in your internet browser, but this may decrease the quality of your user experience.
                      </p>
                      <p>We use the following types of cookies on our Site:</p>
                      <ol>
                        <li>
                          <span>Functional cookies</span>
                          Functional cookies are used to remember the selections you make on our Site so that your selections are saved for your next visits; and
                        </li>
                        <li>
                          <span>Analytical cookies</span>
                          Analytical cookies allow us to improve the design and functionality of our Site by collecting data on how you access our Site, for example data on the content you access, how long you stay on our Site, etc.
                        </li>
                      </ol>
                      <p>
                        <span className="font-semibold">Modifications</span>
                        This Privacy Policy may be amended from time to time in order to maintain compliance with the law and to reflect any changes to our data collection process. When we amend this Privacy Policy we will update the "Effective Date" at the top of this Privacy Policy. We recommend that our users periodically review our Privacy Policy to ensure that they are notified of any updates. If necessary, we may notify users by email of changes to this Privacy Policy.
                      </p>
                      <p>
                        <span className="font-semibold">Complaints</span>
                        If you have any complaints about how we process your personal data, please contact us through the contact methods listed in the <em>Contact Information</em> section so that we can, where possible, resolve the issue. If you feel we have not addressed your concern in a satisfactory manner you may contact a supervisory authority. You also have the right to directly make a complaint to a supervisory authority. You can lodge a complaint with a supervisory authority by contacting the Information Commissioner's Office in the UK.
                      </p>
                      <p>
                        <span className="font-semibold">Contact Information</span>
                        If you have any questions, concerns or complaints, you can contact our data protection officer, Adam Jowett, at:
                        <address className="mt-8">
                          <a href="mailto:adamjowett.yss@gmail.com">adamjowett.yss@gmail.com</a> <br />
                          <a href="tel:07923361301">07923 361301</a> <br />
                          Flat 20, Manor Glade Court, Higher Warberry Road
                        </address>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default PrivacyPolicy;
